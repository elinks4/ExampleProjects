﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpoonFeedPlayer : MonoBehaviour
{


    public Player player;
    public DataBank bank;

    public bool okToFeed = false;

    public void spoonfeedingTime()
    {
    //    Debug.Log("Comes to spoonfeeding : " + player.characterIDsPlayerHasList.Count.ToString());


        for (int i = 0; i < player.characterIDsPlayerHasList.Count; i++)
        {

            Character charat = bank.changeCharacter(player.characterIDsPlayerHasList[i], player.charaFormsPlayerHasList, player.charaThatPlayerHasLevels, player.charaSkillThatPlayerHasLevels);


            player.gettingBackChara(charat);
        }

        for(int i = 0; i < player.dopingsIDsPlayerHas.Count; i++)
        {
            Doping dope = bank.changeDoping(player.dopingsIDsPlayerHas[i], player.levelsDopingshave);

            player.gettingBackDoping(dope);
        }

        player.LevelUpStatNums();


        bank.dataBankNotComplete = false;
        okToFeed = false;
    }


   


    // Start is called before the first frame update
    void Start()
    {
    }





    // Update is called once per frame
    void Update()
    {
        if(bank.dataBankNotComplete == true && okToFeed == true)
        {
            Debug.Log("Comes okay to spoonfeed UPDate ");

            spoonfeedingTime();

        }
    }
}
