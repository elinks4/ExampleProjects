﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChooseOne : MonoBehaviour
{

    public ChooserMAnager mAnager;

    public Character chosenCharacter;
    public Doping chosenDoping;
    public bool charaOrNot;
    public bool charaScreenOrNot = false;
   public int choNr;

    public CharaScreenManager scmanage;


    // Start is called before the first frame update
    void Start()
    {
        mAnager = FindObjectOfType<ChooserMAnager>();

       if(chosenCharacter != null)
        {
           //  Debug.Log("Chosen Character: " + chosenCharacter._name);

            gameObject.GetComponent<Image>().sprite = chosenCharacter.basicSprite;

        }
       else if(chosenDoping != null)
        {
            gameObject.GetComponent<Image>().sprite = chosenDoping._sprite;

        }


    }


    public void chooseThisOne()
    {
        if (charaOrNot)
        {
            if(charaScreenOrNot == false)
            {
        //        Debug.Log("Clicked character is " + chosenCharacter._name);

                mAnager.setChara(chosenCharacter);
            }
           else if (charaScreenOrNot)
            {
                scmanage = FindObjectOfType<CharaScreenManager>();
                scmanage.setChara(chosenCharacter);
            }
        }
        else
        {
            if (charaScreenOrNot == false)
            {

                if (choNr == 4 || choNr == 5 || choNr == 6)
                {
                    mAnager.setAlfaDope(chosenDoping);

                }
                else
                {
                    mAnager.setNeutralDope(chosenDoping);
                }

            }
            else if (charaScreenOrNot)
            {
                scmanage = FindObjectOfType<CharaScreenManager>();
                scmanage.setDope(chosenDoping);
            }

        }
    }


    public void unEquip()
    {
       // Debug.Log("Clicked UNEQUIP " + chosenCharacter._name);

        mAnager.selectiveunEquip();
    }


    // Update is called once per frame
    void Update()
    {
        
    }

  
}
