﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



[System.Serializable]
public class Dialogue 
{

    public string name;

   // public List<int> picPlace;

    public List<int> charaNum;


    public List<int> picNum;


    public int backGPic = 0;

    [TextArea(3, 20)]
    public string[] sentences;

}
