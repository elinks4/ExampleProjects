﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleSEquence 
{
    // Start is called before the first frame update

    public List<Enemy> _enemies = new List<Enemy>();
    public int lootGold;
    public int battleLevel;
    public int _battleID;
    public Sprite backG1;
    public Sprite backG2;
    public int isBossfight;

  


    public BattleSEquence(int battleID, int battleL, List<Enemy> enemys, int loot, Sprite bg1, Sprite bg2, int bossF)
    {
        _enemies = enemys;
        lootGold = loot;
        battleLevel = battleL;
        _battleID = battleID;

        backG1 = bg1;
        backG2 = bg2;

        isBossfight = bossF;

        //      Debug.Log("GET ENEMY num " + enemys.Count.ToString() + " enemies number " + _enemies.Count.ToString());

    }



    public Enemy getEnemy(int num)
    {

        Debug.Log("GET ENEMY num " + num.ToString() + " enemies number " + _enemies.Count.ToString());


        return _enemies[num];




    }


    public int countEnemyNum()
    {
       // Debug.Log("GET ENEMY num "  + " enemies number " + _enemies.Count.ToString());


        return _enemies.Count;
    }


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
