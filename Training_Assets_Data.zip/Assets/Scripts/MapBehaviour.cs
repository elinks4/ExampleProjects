﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class MapBehaviour : MonoBehaviour
{



    public Image storyMAp;
    public Image extraMAp;

    public DontDestroyThis DdestroyThis;
    public Player playerOne;

    public List<PlaceButtonPresss> storyButtons = new List<PlaceButtonPresss>();
    public List<PlaceButtonPresss> extraButtons = new List<PlaceButtonPresss>();


    private int phase;
    private int extraDone;

    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;

        phase = playerOne.phaseLevel;
        extraDone = playerOne.extraQDone;
        


        if (DdestroyThis.StoryOrExtra == 2)
        {
            storyMAp.gameObject.SetActive(false);
            extraMAp.gameObject.SetActive(true);

        }
        else
        {
            extraMAp.gameObject.SetActive(false);
            storyMAp.gameObject.SetActive(true);

        }

        startingCheck();
    }


    public void startingCheck()
    {
        int lv = phase - 1;

        for(int i = 0; i < storyButtons.Count; i++)
        {
            if(storyButtons[i].ID <= lv)
            {
                storyButtons[i].changeSpriteToDone();
                storyButtons[i].canGoThere = false;
             //   if(can)

            }
            else if(storyButtons[i].ID > lv)
            {
                storyButtons[i].canGoThere = false;
            }
        }

        for(int i = 0; i < extraButtons.Count; i++)
        {
            if(extraButtons[i].ID < extraDone)
            {
                extraButtons[i].changeSpriteToDone();
            }
            else if(extraButtons[i].ID > extraDone)
            {
                extraButtons[i].canGoThere = false;

            }
        }

        extraButtons[extraDone].changeToCanGo();
        extraButtons[extraDone].canGoThere = true;

        storyButtons[lv].changeToCanGo();
        storyButtons[lv].canGoThere = true;


    }




    public void pressButton(GameObject button)
    {

        Debug.Log("Pressed button " + button.GetComponent<PlaceButtonPresss>().ID.ToString());

        if(button.GetComponent<PlaceButtonPresss>().StoryOrExtra == 1)
        {
            if (button.GetComponent<PlaceButtonPresss>().canGoThere)
            {
                DdestroyThis.whichBattleToDo = phase;
                DdestroyThis.StoryOrExtra = 1;
                if (button.GetComponent<PlaceButtonPresss>().firstTime)
                {
                    DdestroyThis.firstTimeInThisBattle = true;
                    button.GetComponent<PlaceButtonPresss>().firstTime = false;
                }
                SceneManager.LoadScene(5);
            }
          

        }
        else
        {
            if(playerOne.characterIDsPlayerHasList.Count >= 3)
            {
                if (button.GetComponent<PlaceButtonPresss>().canGoThere)
                {

                    DdestroyThis.whichBattleToDo = playerOne.farthestPhase + button.GetComponent<PlaceButtonPresss>().ID;
                    Debug.Log("Farthest place is " + playerOne.farthestPhase.ToString() + "whichBattle to do " + DdestroyThis.whichBattleToDo.ToString());
                    DdestroyThis.StoryOrExtra = 2;
                    if (button.GetComponent<PlaceButtonPresss>().firstTime)
                    {
                        DdestroyThis.firstTimeInThisBattle = true;
                        button.GetComponent<PlaceButtonPresss>().firstTime = false;
                    }
                    SceneManager.LoadScene(2);
                }

            }

          

        }
    }

    public void openExtraQuestsWindow()
    {
        storyMAp.gameObject.SetActive(false);
        extraMAp.gameObject.SetActive(true);

    }


    public void openStoryQuestWindow()
    {
        extraMAp.gameObject.SetActive(false);
        storyMAp.gameObject.SetActive(true);

    }



    public void toHomeScreen()
    {
        DdestroyThis.StoryOrExtra = -1;
        SceneManager.LoadScene(6);

    }




    // Update is called once per frame
    void Update()
    {
        
    }
}
