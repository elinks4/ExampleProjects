﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BattleResult : MonoBehaviour
{

    public Image chara1;
    public Image chara2;
    public Image chara3;


    private Player playerOne;

    public Character char1;
    public Character char2;
    public Character char3;

    public Enemy enem1;
    public Enemy enem2;
    public Enemy enem3;

    public int battlePhase;
    private DataBank bank;


    private BattleSEquence battle;


    private DontDestroyThis DdestroyThis;

    public Button toNext;

    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;
    public Text goldText;
    public Text gemText;

    public int bothGems;


    // Start is called before the first frame update
    void Start()
    {
        toNext.gameObject.SetActive(false);
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
        bank = DdestroyThis.bank;


        char1 = playerOne.returnPlayersCharacter(DdestroyThis.chL[0]);
        char2 = playerOne.returnPlayersCharacter(DdestroyThis.chL[1]);
        char3 = playerOne.returnPlayersCharacter(DdestroyThis.chL[2]);



        CharaForm charaF1 = char1.chosenForm;
        CharaForm charaF2 = char2.chosenForm;
        CharaForm charaF3 = char3.chosenForm;


        Debug.Log("chara form is " + charaF1.formName);

        chara1.sprite = charaF1.faceSprite;
        chara2.sprite = charaF2.faceSprite;
        chara3.sprite = charaF3.faceSprite;

        battlePhase = playerOne.phaseLevel;
        battle = bank.getBattle(battlePhase - 1);

        enem1 = battle.getEnemy(0);
        enem2 = battle.getEnemy(1);
        enem3 = battle.getEnemy(2);

        Spoils[] sp = new Spoils[enem1.spoils.Count];
        for(int i = 0; i < sp.Length; i++)
        {
            sp[i] = enem1.spoils[i];
        }
        Spoils[] sp2 = new Spoils[enem2.spoils.Count];
        for (int i = 0; i < sp2.Length; i++)
        {
            sp2[i] = enem2.spoils[i];
        }
        Spoils[] sp3 = new Spoils[enem3.spoils.Count];
        for (int i = 0; i < sp3.Length; i++)
        {
            sp3[i] = enem3.spoils[i];
        }

        playerOne.increaseSpoilToInventory(sp);
        playerOne.increaseSpoilToInventory(sp2);
        playerOne.increaseSpoilToInventory(sp3);

        playerOne.spoilsIDInventory.Sort();


        playerOne.goldPlayerHas += battle.lootGold;
   

        text1.text = "You got: " + battle.lootGold.ToString() + " Gold and ";

        if (DdestroyThis.firstTimeInThisBattle)
        {
            playerOne.mGems += 1;
            text1.text = "You got:" + battle.lootGold.ToString() + " Gold, 1 Gem and ";
            DdestroyThis.firstTimeInThisBattle = false;
        }

        checking(sp, enem1, text2);
        checking(sp2, enem2, text3);
        checking(sp3, enem3, text4);

        nullArrays(sp);
        nullArrays(sp2);
        nullArrays(sp3);

        markAsCleared();

        updateTexts();

        toNext.gameObject.SetActive(true);

    }


    public void checking(Spoils[] sps, Enemy ene, Text txt)
    {
        int n = 0;
        int n2 = 0;
        for (int i = 0; i < sps.Length; i++)
        {

            if(ene.spoils.Count >= 1)
            {
                if (ene.spoils[0]._ID == sps[i]._ID)
                {
                    n = n + 1;
                }
            }
            if (ene.spoils.Count >= 2)
            {
                if (ene.spoils[1]._ID == sps[i]._ID)
                {
                    n2 = n2 + 1;
                }
            }

            
        }

        if (ene.spoils.Count >= 2)
        {
            txt.text = ene.spoils[0]._name + ": " + n + ", " + ene.spoils[1]._name + ": " + n2;

        }
        else if(ene.spoils.Count >= 1)
        {
            txt.text = ene.spoils[0]._name + ": " + n;
        }
        else
        {
            txt.text = " ";
        }
    }


    public void nullArrays(Spoils[] array)
    {
        for(int i = 0; i < array.Length; i++)
        {
            array[i] = null;
        }
    }



    public void loadNext()
    {
        if(DdestroyThis.StoryOrExtra == 1)
        {
            Debug.Log("comes to check where to go After battle" + DdestroyThis.whereStoryStays.ToString());


            if (DdestroyThis.whereStoryStays > 0)
            {
                Debug.Log("comes inside IF " + DdestroyThis.whereStoryStays.ToString());
                SceneManager.LoadScene(5);

            }
            else
            {
               // playerOne.phaseLevel += 1;
                SceneManager.LoadScene(8);
            }
         
        }
        else
        {
          //  playerOne.extraQDone += 1;
            SceneManager.LoadScene(8);

        }


    }

    public void markAsCleared()
    {
        if (DdestroyThis.StoryOrExtra == 1)
        {
            Debug.Log("comes to check where to go After battle" + DdestroyThis.whereStoryStays.ToString());


            if (DdestroyThis.whereStoryStays > 0)
            {
                Debug.Log("comes inside IF " + DdestroyThis.whereStoryStays.ToString());
               

            }
            else
            {
                playerOne.phaseLevel += 1;
               
            }

        }
        else
        {
            playerOne.extraQDone += 1;
           

        }
    }



    public void updateTexts()
    {
        bothGems = playerOne.mGems + playerOne.kGems;
        gemText.text = bothGems.ToString();

        goldText.text = playerOne.goldPlayerHas.ToString();
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
