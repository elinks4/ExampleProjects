﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character 
{

    //take off Monobehaviour???

    public Sprite basicSprite;


    public int _charaID;

    public string _name;

    public float _level;


    public int form_posessed;

    public int _stars;

    public List<CharaForm> Cforms = new List<CharaForm>();

    public CharaForm chosenForm;

   
    

    
  

    public Character(int id, string namer, int stars, Sprite basicPic, CharaForm neutral)
    {
        _charaID = id;
        _name = namer;
        _stars = stars;
        basicSprite = basicPic;
        form_posessed++;
        Cforms.Add(neutral);
        chosenForm = neutral;
        float num = (float)id + 0.01f;
        _level = num;

       

      //  Debug.Log("num is " + num.ToString() + "level is " + _level.ToString());
    }

    public void giveNewForm(CharaForm forma)
    {
        Cforms.Add(forma);
        form_posessed++;

    }



    public List<CharaForm> giveForms()
    {
        return Cforms;
    }


    public void levelUpStats()
    {
        float nr = _level;
   //     Debug.Log("Level up stats nr is " + nr.ToString());
       int LevelN = new System.Version(nr.ToString()).Minor;

        if(LevelN != 0.01)
        {
            for(int i = 0; i < Cforms.Count; i++)
            {
                Cforms[i].levelUPSTATS(LevelN);
            }
        }

    }

    public void levelUpOneLevel()
    {
      //  _level = _level + 0.01f;

        int majorpart = new System.Version(_level.ToString()).Major;
        int minorpart = new System.Version(_level.ToString()).Minor;
        int trye1 = minorpart + 1;


        //easier += 1;
        float nm1 = (float)_charaID + 0.1f;
        float nm2 = (float)_charaID + 0.2f;
        float nm3 = (float)_charaID + 0.3f;
        float nm4 = (float)_charaID + 0.4f;
        float nm5 = (float)_charaID + 0.5f;
        float nm6 = (float)_charaID + 0.6f;
        float nm7 = (float)_charaID + 0.7f;
        float nm8 = (float)_charaID + 0.8f;


        Debug.Log("charaid + level " + nm1.ToString());

        if (nm1 == _level)
        {
            Debug.Log("Comes in charaid + level " + nm1.ToString());
            trye1 = 11;
        }
        else if(nm2 == _level)
        {
            trye1 = 21;

        }
        else if (nm3 == _level)
        {
            trye1 = 31;

        }
        else if (nm4 == _level)
        {
            trye1 = 41;

        }
        else if (nm5 == _level)
        {
            trye1 = 51;

        }
        else if (nm6 == _level)
        {
            trye1 = 61;

        }
        else if (nm7 == _level)
        {
            trye1 = 71;

        }
        else if (nm8 == _level)
        {
            trye1 = 81;

        }
      

        float trye2 = majorpart + ((float)trye1 / 100);
        _level = trye2;

        levelUpStats();

        Debug.Log("majorpart is " + majorpart.ToString() + " minor part is " + minorpart.ToString() + " try1 is " + trye1.ToString() + " try2 is " + trye2.ToString() + " Level is " + _level.ToString());

    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
