﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



[System.Serializable]
public class PlayerData
{
    public int playerID;
    public int playerlevel;
    public int[] charasHaven;
    public float[] charaFormsHaven;
    public float[] charaFormsSkillLevels;
    public int[] dopingIdsthatPlayerHas;
    public float[] dopingLevels;
    public float[] charaLevels;
    public int playerPhaseLevel;
    public int EQDone;
    public string playerN;
    public bool firstTime;
    public int[] spoilsPlayerHas;
    public int[] itemsPlayerHas;
    public int gold;
    public int mGems;
    public int kGems;
    public int[] treasureIDs;
    public int farthestPlace;
    public int RouteOfStory;
    public PlayerData(Player player)
    {
        playerID = player.playerID;
        playerlevel = player.level;

        charasHaven = new int[player.characterIDsPlayerHasList.Count];

        for(int i = 0; i < player.characterIDsPlayerHasList.Count; i++)
        {
            charasHaven[i] = player.characterIDsPlayerHasList[i];
        }

        charaFormsHaven = new float[player.charaFormsPlayerHasList.Count];

        for (int i = 0; i < player.charaFormsPlayerHasList.Count; i++)
        {

            charaFormsHaven[i] = player.charaFormsPlayerHasList[i];


        }
        charaFormsSkillLevels = new float[player.charaSkillThatPlayerHasLevels.Count];

        for (int i = 0; i < player.charaSkillThatPlayerHasLevels.Count; i++)
        {
         
                    charaFormsSkillLevels[i] = player.charaSkillThatPlayerHasLevels[i];

                
        }

        charaLevels = new float[player.characterIDsPlayerHasList.Count];
        for(int i = 0; i < player.charactersPlayerHasList.Count; i++)
        {
            
            charaLevels[i] = player.charactersPlayerHasList[i]._level;
        }

        dopingLevels = new float[player.levelsDopingshave.Count];
        dopingIdsthatPlayerHas = new int[player.dopingsIDsPlayerHas.Count];
        for (int i = 0; i < player.dopingsIDsPlayerHas.Count; i++)
        {
            dopingLevels[i] = player.levelsDopingshave[i];
            dopingIdsthatPlayerHas[i] = player.dopingsIDsPlayerHas[i];

        }
        spoilsPlayerHas = new int[player.spoilsIDInventory.Count];
        for(int i = 0; i < player.spoilsIDInventory.Count; i++)
        {
            spoilsPlayerHas[i] = player.spoilsIDInventory[i];
        }

        itemsPlayerHas = new int[player.itemIDInventory.Count];
        for (int i = 0; i < player.itemIDInventory.Count; i++)
        {
            itemsPlayerHas[i] = player.itemIDInventory[i];
        }
        treasureIDs = new int[player.TreasureStuffIDs.Count];
        for(int i = 0; i < player.TreasureStuffIDs.Count; i++)
        {
            treasureIDs[i] = player.TreasureStuffIDs[i];
        }

        firstTime = player.firtsTime;

        playerPhaseLevel = player.phaseLevel;

        playerN = player.playerName;

        gold = player.goldPlayerHas;
        mGems = player.mGems;
        kGems = player.kGems;
        farthestPlace = player.farthestPhase;
        RouteOfStory = player.storyRoute;

        EQDone = player.extraQDone;
    }


    



}
