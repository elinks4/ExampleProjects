﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharaForm 
{


    //take off Monobehaviour???


    //public Sprite formSprite;
   public Sprite formSprite;
    public Sprite faceSprite;
    public Sprite fullBody;

    public float formID;
    public string formName;
    public int _hp;
    public int _element;
    public int _att;
    public int _deff;


    public int changing_hp;
    public int changing_att;
    public int changing_def;


    public int hpdbufTurn = 0;
    public int strdbufTurn = 0;
    public int defdbufTurn = 0;

    public int strbTurn = 0;
    public int defbTurn = 0;

    public List<Skill> skills = new List<Skill>();

    private int[] hpLevels;
    private int[] attLevels;
    private int[] defLevels;



    public CharaForm(float id, string name, Sprite formS, Sprite faceP, Sprite fullB, int formHP, int att, int def, int element, Skill sk1, Skill sk2, Skill sk3, Skill ougi, int[] hpchanges, int[] attchanges, int[] defchanges)
    {
        
         formID = id;
        formName = name;
        formSprite = formS;
        faceSprite = faceP;
        fullBody = fullB;
        _element = element;
        skills.Add(sk1);
        skills.Add(sk2);
        skills.Add(sk3);
        skills.Add(ougi);

        _hp = formHP;
        _att = att;
        _deff = def;

        changing_hp = formHP;
        changing_att = att;
        changing_def = def;

        hpLevels = hpchanges;
        attLevels = attchanges;
        defLevels = defchanges;

    }
            

    public void levelUPSTATS(int lv)
    {


        _hp = _hp + hpLevels[lv]; 
        _att = _att + attLevels[lv];
        _deff = _deff + defLevels[lv];

  //      Debug.Log("lv is " + lv.ToString() + " HP is " + _hp.ToString() + " ATT is " + _att.ToString() + " DEF is " + _deff.ToString());
    }
 

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
