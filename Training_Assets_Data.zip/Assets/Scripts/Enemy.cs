﻿using UnityEngine;
using System.Collections.Generic;

public class Enemy
{

    public int _enemy_id;
    public int _hp;
    public string _name;
    public int baseAtt;
    public int baseDef;

    public int[] levelChanges;


    public Sprite _enemySprite;

    public List<Spoils> spoils = new List<Spoils>();

    public Enemy(int id, int hp, string nm, int bAtt, int bDef, Sprite enem, int[] changes)
    {
        _hp = hp;
        _enemy_id = id;
        _name = nm;
        baseAtt = bAtt;
        baseDef = bDef;
        _enemySprite = enem;

        levelChanges = changes;
    }

    public void inputSpoils(Spoils spoil)
    {
        spoils.Add(spoil);
    }

  

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
