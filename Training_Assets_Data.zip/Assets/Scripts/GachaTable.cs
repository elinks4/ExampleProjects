﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GachaTable : MonoBehaviour
{

   public Player player;
    public DataBank bank;


    //most frequent -> least frequent
    //Neutral doping -> Alfa doping -> character
    public int[] table = { 60, 30, 10 };

    public int[] star4NormalCharatable = { 3 };
    public int[] star5NormalCharatable = { 1, 2 };
    public int[] star4PickUpCharatable = { 3 };
    public int[] star5PickUpCharatable = { 0 };

    public int[] wishList = new int[10];
    public List<int> wishL = new List<int>();
   

    public int[] dopingNeutralGetList = { 0 };
    public int[] dopingAlfaGetList = { 1 };


    public int total;
    public int randomN;

    public int tenpullPity = 0;
    public int hundredpullPity = 0;

    private int backNr;


    public Button template;
    public GridLayoutGroup grid;
    public List<Button> buttonsToDestroy = new List<Button>();

    public GameObject panel;


    public Text gemText;
    public Text goldText;
    public int bothGems;


    // Start is called before the first frame update
    void Start()
    {
        //total 100

        //if randomN is <= 60 you get first

        //if randomN = 61
        //is 61 <= 60
        //no = ??
        //61 - 60 = 1
        //1 <= 30?
        // yes = you get second

        //randomN = 92
        //92 <= 60?
        //92 - 60 = 32
        //32 <= 30?
        //32 - 30 = 2
        //2 <= 10?
        //you get third


        foreach(var item in table)
        {
            total += item;
        }


        Debug.Log("databank contact test " + bank.charaBank.Count.ToString() + " and player contact test " + player.charactersPlayerHasList.Count.ToString());

        updateTexts();

    }


    public void clearCharas()
    {
        player.characterDeleteForTesting();
    }



    public int rollOne()
    {


      

        randomN = Random.Range(0, total);

        
 
       //     Debug.Log("Comes to random PULL random num: " + randomN.ToString());

        foreach(var weight in table)
        {
            if(randomN <= weight)
            {
                backNr = weight;
          //      Debug.Log("Comes to randomNr <= weight: " + backNr.ToString());

            }
            else if(randomN > weight)
            {
         //       Debug.Log("Comes to else: " + randomN.ToString());

                randomN -= weight;
            }
        }



        return backNr;
    }



    public int rollTenPullPityChara()
    {
        randomN = Random.Range(0, total);



        if (randomN <= 75)
        {
            backNr = table[1];
          
        }
        else
        {
            backNr = table[2];
        }


        return backNr;

    }



    public void rollOnePull()
    {
        bothGems = player.mGems + player.kGems;
        if (bothGems >= 1)
        {

            panel.SetActive(true);
            for (int i = 0; i < buttonsToDestroy.Count; i++)
            {
                Destroy(buttonsToDestroy[i].gameObject);
            }

            buttonsToDestroy.Clear();



            if (tenpullPity < 10 && hundredpullPity < 100)
            {
                //   Debug.Log("Comes to random PULL random num: " + randomN.ToString());



                //     wishList[i] = rollOne();
                wishL.Add(rollOne());
                tenpullPity++;
                hundredpullPity++;



            }
            else if (tenpullPity == 10 && hundredpullPity < 100)
            {

                Debug.Log("Came to Tenn Pull Pity random num: " + randomN.ToString());



                //    wishList[i] = rollTenPullPityChara();
                wishL.Add(rollTenPullPityChara());

                tenpullPity = 0;
                hundredpullPity++;


            }
            else if (hundredpullPity == 100)
            {

                //   wishList[i] = table[3];
                wishL.Add(table[2]);
                Debug.Log("Came to HUNDRED PULL PITY Award: " + table[2].ToString());
                tenpullPity = 0;
                hundredpullPity = 0;

            }

            for (int i = 0; i < wishL.Count; i++)
            {

                //get stuff from databank and spoonfeed player

                if (wishL[i] == 60)
                {

                    randomN = Random.Range(0, dopingNeutralGetList.Length);
                    //   Debug.Log("random num: " + randomN.ToString());

                    //    Debug.Log("Neutral doping table lenght : " + dopingNeutralGetList.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + dopingNeutralGetList[randomN].ToString());
                    player.gettingNewDoping(bank.getDoping(dopingNeutralGetList[randomN]));

                    Button newB = Instantiate(template) as Button;
                    newB.transform.SetParent(grid.transform, false);

                    newB.GetComponent<Image>().sprite = bank.getDoping(dopingNeutralGetList[randomN])._sprite;
                    buttonsToDestroy.Add(newB);

                }
                else if (wishL[i] == 30)
                {
                    randomN = Random.Range(0, dopingAlfaGetList.Length);
                    //     Debug.Log("random num: " + randomN.ToString());

                    //   Debug.Log("Alfa doping table lenght : " + dopingAlfaGetList.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + dopingAlfaGetList[randomN].ToString());
                    player.gettingNewDoping(bank.getDoping(dopingAlfaGetList[randomN]));
                    Button newB = Instantiate(template) as Button;
                    newB.transform.SetParent(grid.transform, false);

                    newB.GetComponent<Image>().sprite = bank.getDoping(dopingAlfaGetList[randomN])._sprite;
                    buttonsToDestroy.Add(newB);

                }
                else if (wishL[i] == 10)
                {
                    randomN = Random.Range(0, total);
                    //   Debug.Log("random num: " + randomN.ToString());

                    if (randomN <= 75)
                    {

                        randomN = Random.Range(0, total);

                        if (randomN <= 75)
                        {
                            randomN = Random.Range(0, star4PickUpCharatable.Length);
                            //     Debug.Log("4 star pickup chara table lenght : " + star4PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star4PickUpCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star4PickUpCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star4PickUpCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }
                        else
                        {
                            randomN = Random.Range(0, star4NormalCharatable.Length);
                            //     Debug.Log("4 star normal chara table lenght : " + star4NormalCharatable.Length.ToString() + " random N : " + randomN.ToString() + " number from table : " + star4NormalCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star4NormalCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star4NormalCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }


                    }
                    else
                    {

                        randomN = Random.Range(0, total);

                        if (randomN <= 75)
                        {
                            randomN = Random.Range(0, star5PickUpCharatable.Length);
                            //    Debug.Log("5 star picup chara table lenght : " + star5PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star5PickUpCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star5PickUpCharatable[randomN]));


                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star5PickUpCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);


                        }
                        else
                        {
                            randomN = Random.Range(0, star5NormalCharatable.Length);
                            //       Debug.Log("5 star normal chara table lenght : " + star5PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star5NormalCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star5NormalCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star5NormalCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }

                    }

                }

            }


            wishL.Clear();

            if(player.mGems > 0)
            {
                player.mGems -= 1;
            }
            else
            {
                player.kGems -= 1;
            }

            updateTexts();
        }

    }



    public void closeGachaPanel()
    {
        for (int i = 0; i < buttonsToDestroy.Count; i++)
        {
            Destroy(buttonsToDestroy[i].gameObject);
        }

        buttonsToDestroy.Clear();
        wishL.Clear();

        panel.SetActive(false);


    }

    public void rollTen()
    {

        bothGems = player.mGems + player.kGems;
        if (bothGems >= 10)
        {

            panel.SetActive(true);

            for (int i = 0; i < buttonsToDestroy.Count; i++)
            {
                Destroy(buttonsToDestroy[i].gameObject);
            }

            buttonsToDestroy.Clear();

            for (int i = 0; i < 10; i++)
            {



                if (tenpullPity < 10 && hundredpullPity < 100)
                {
                    //   Debug.Log("Comes to random PULL random num: " + randomN.ToString());



                    //     wishList[i] = rollOne();
                    wishL.Add(rollOne());
                    tenpullPity++;
                    hundredpullPity++;



                }
                else if (tenpullPity == 10 && hundredpullPity < 100)
                {

                    Debug.Log("Came to Tenn Pull Pity random num: " + randomN.ToString());



                    //    wishList[i] = rollTenPullPityChara();
                    wishL.Add(rollTenPullPityChara());

                    tenpullPity = 0;
                    hundredpullPity++;


                }
                else if (hundredpullPity == 100)
                {

                    //   wishList[i] = table[3];
                    wishL.Add(table[2]);
                    Debug.Log("Came to HUNDRED PULL PITY Award: " + table[2].ToString());
                    tenpullPity = 0;
                    hundredpullPity = 0;

                }


            }


            //   Debug.Log("CONTofWL" + wishL[0].ToString() + " , " + wishL[1].ToString() + " , " + wishL[2].ToString() + " , " + wishL[3].ToString() + " , " + wishL[4].ToString() + " , " + wishL[5].ToString() + " , " + wishL[6].ToString() + " , " + wishL[7].ToString() + " , " + wishL[8].ToString());

            for (int i = 0; i < wishL.Count; i++)
            {

                //get stuff from databank and spoonfeed player

                if (wishL[i] == 60)
                {

                    randomN = Random.Range(0, dopingNeutralGetList.Length);
                    //   Debug.Log("random num: " + randomN.ToString());

                    //    Debug.Log("Neutral doping table lenght : " + dopingNeutralGetList.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + dopingNeutralGetList[randomN].ToString());
                    player.gettingNewDoping(bank.getDoping(dopingNeutralGetList[randomN]));

                    Button newB = Instantiate(template) as Button;
                    newB.transform.SetParent(grid.transform, false);

                    newB.GetComponent<Image>().sprite = bank.getDoping(dopingNeutralGetList[randomN])._sprite;
                    buttonsToDestroy.Add(newB);

                }
                else if (wishL[i] == 30)
                {
                    randomN = Random.Range(0, dopingAlfaGetList.Length);
                    //     Debug.Log("random num: " + randomN.ToString());

                    //   Debug.Log("Alfa doping table lenght : " + dopingAlfaGetList.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + dopingAlfaGetList[randomN].ToString());
                    player.gettingNewDoping(bank.getDoping(dopingAlfaGetList[randomN]));
                    Button newB = Instantiate(template) as Button;
                    newB.transform.SetParent(grid.transform, false);

                    newB.GetComponent<Image>().sprite = bank.getDoping(dopingAlfaGetList[randomN])._sprite;
                    buttonsToDestroy.Add(newB);

                }
                else if (wishL[i] == 10)
                {
                    randomN = Random.Range(0, total);
                    //   Debug.Log("random num: " + randomN.ToString());

                    if (randomN <= 75)
                    {

                        randomN = Random.Range(0, total);

                        if (randomN <= 75)
                        {
                            randomN = Random.Range(0, star4PickUpCharatable.Length);
                            //     Debug.Log("4 star pickup chara table lenght : " + star4PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star4PickUpCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star4PickUpCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star4PickUpCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }
                        else
                        {
                            randomN = Random.Range(0, star4NormalCharatable.Length);
                            //     Debug.Log("4 star normal chara table lenght : " + star4NormalCharatable.Length.ToString() + " random N : " + randomN.ToString() + " number from table : " + star4NormalCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star4NormalCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star4NormalCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }


                    }
                    else
                    {

                        randomN = Random.Range(0, total);

                        if (randomN <= 75)
                        {
                            randomN = Random.Range(0, star5PickUpCharatable.Length);
                            //    Debug.Log("5 star picup chara table lenght : " + star5PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star5PickUpCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star5PickUpCharatable[randomN]));


                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star5PickUpCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);


                        }
                        else
                        {
                            randomN = Random.Range(0, star5NormalCharatable.Length);
                            //       Debug.Log("5 star normal chara table lenght : " + star5PickUpCharatable.Length.ToString() + "random N : " + randomN.ToString() + " number from table : " + star5NormalCharatable[randomN].ToString());
                            player.gettingNewChara(bank.getCharacter(star5NormalCharatable[randomN]));

                            Button newB = Instantiate(template) as Button;
                            newB.transform.SetParent(grid.transform, false);

                            newB.GetComponent<Image>().sprite = bank.getCharacter(star5NormalCharatable[randomN]).basicSprite;
                            buttonsToDestroy.Add(newB);

                        }

                    }

                }

            }


            wishL.Clear();


            if (player.mGems >= 10)
            {
                player.mGems -= 10;
            }
            else if(player.kGems >= 10)
            {
                if(player.mGems >= 1)
                {
                    int lessen = player.mGems;
                    int o = 10 - lessen;
                    player.mGems -= lessen;
                    player.kGems -= o;
                }
                else
                {
                    player.kGems -= 10;

                }
            }
            else
            {
                int lessen = player.mGems;
                

                int o = 10 - lessen;
                player.mGems -= lessen;
                player.kGems -= o;
                
            }

            updateTexts();
        }
            
    }



    public void nextStage()
    {
        SceneManager.LoadScene(6);

    }



    public void updateTexts()
    {
        bothGems = player.mGems + player.kGems;
        gemText.text = bothGems.ToString();

        goldText.text = player.goldPlayerHas.ToString();
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
