﻿using UnityEngine;
using UnityEngine.UI;

public class TouchingAttack : MonoBehaviour
{

    public Skill skill;
    public GameObject model;
    public BattleProgram battle;
   // public AnimHelper aniHel;

    private int att;
    private int def;
    private int heal;
    private int strenght;

    // Start is called before the first frame update
    void Start()
    {

    }

    



    public void skillSet(Skill sk, GameObject md)
    {
        skill = sk;
        model = md;

        if(skill._is_Ougi == false)
        {
            gameObject.GetComponent<Image>().sprite = skill.skillSprite;

        }
    }

    public void attack()
    {

    //    float n = skill._skill_level;
      //  float y = n * 10;


     //   int skillLevelPart = new System.Version(y.ToString()).Minor;


      //  float f = (skillLevelPart / 10);
    //    int l = (int)f;
    /*
        att = (int)skill._power * l + model.GetComponent<FighterCharacterChanges>().changing_att;
        def = (int)skill._power * l + model.GetComponent<FighterCharacterChanges>().changing_def;
        heal = (int)skill._power * l + 1000;
        strenght = (int)skill._power * l + 500;

        */

        att = (int)skill._power + model.GetComponent<FighterCharacterChanges>().changing_att;
   //     Debug.Log("skill power " + skill._power.ToString() + " changing attack " + model.GetComponent<FighterCharacterChanges>().changing_att.ToString());
        def = (int)skill._power + model.GetComponent<FighterCharacterChanges>().changing_def;
        heal = (int)skill._power  + 1000;
        strenght = (int)skill._power + 500;

          Debug.Log("skill : " + skill._skill_name + " has ATTACK (Without enemy DEF) of " + att.ToString());



        if (battle.canPlay)
        {


            if (skill._is_Ougi == false)
            {

                if (skill.ZAorOSorTB == 1)
                {
                    buffAll();
                    debuffAll();
                  
                    Debug.Log("skill hurts one enemy " + skill._skill_name);

                    battle.hurtOneEnemy(att, skill.animNRO);

                }

                if (skill.ZAorOSorTB == 2)
                {
                    buffAll();
                    debuffAll();
                
                    Debug.Log("skill hurts all enemy " + skill._skill_name);

                    battle.hurtThreeEnemy(att, skill.animNRO);


                }

                if (skill.ZAorOSorTB == 3)
                {
                   
                    
                    buffAll();
                    debuffAll();

                }

                if (skill.ZAorOSorTB == 4)
                {
                   

                    buffAll();
                    debuffAll();

                }


                battle.increaseAttackNRO();

               // Debug.Log("Character " + model.GetComponent<FighterCharacterChanges>().formName + " used skill " + skill._skill_name + "attack nro increased to " + battle.attackingNro.ToString());


            }
            else
            {
                if (battle.canOugi)
                {
                    if (skill.ZAorOSorTB == 1)
                    {
                        buffAll();
                        debuffAll();
                       
                        battle.hurtOneEnemy(att, skill.animNRO);

                    }

                    if (skill.ZAorOSorTB == 2)
                    {
                        buffAll();
                        debuffAll();

                  

                        battle.hurtThreeEnemy(att, skill.animNRO);


                    }

                    if (skill.ZAorOSorTB == 3)
                    {
                        buffAll();
                        debuffAll();
                 

                    }

                    if (skill.ZAorOSorTB == 4)
                    {
                        buffAll();
                        debuffAll();
               

                    }
           



                    battle.increaseAttackNRO();
                    battle.raiseOugiGage(0);
                    Debug.Log("Character " + model.GetComponent<FighterCharacterChanges>().formName + " used skill " + skill._skill_name + "attack nro increased to " + battle.attackingNro.ToString());

                }
            }



        }
    }


    private void buffAll()
    {

      

            if(skill.ZAorOSorTB == 1)
            {
                if (skill._buff == 1)
                {
                    battle.healOneC(heal, skill._buff_debuff_turns);
                Debug.Log("skill heals one " + skill._skill_name);
            }
                if (skill._buff == 2)
                {
                    battle.strenghtOneC(strenght, skill._buff_debuff_turns);
                Debug.Log("skill buffs strenght for one " + skill._skill_name);
            }
                if (skill._buff == 3)
                {
                    battle.defenceOneC(def, skill._buff_debuff_turns);
                Debug.Log("skill buffs defence for one " + skill._skill_name);
            }
            }

            if(skill.ZAorOSorTB == 2)
            {

                if (skill._buff == 1)
                {
                    battle.healThreeC(heal, skill._buff_debuff_turns);
                Debug.Log("skill heals all " + skill._skill_name);
            }
                if (skill._buff == 2)
                {
                    battle.strenghtThreeC(strenght, skill._buff_debuff_turns);
                Debug.Log("skill buffs strenght for ALL " + skill._skill_name);

            }
            if (skill._buff == 3)
                {
                    battle.defenceThreeC(def, skill._buff_debuff_turns);
                Debug.Log("skill buffs defence for all " + skill._skill_name);

            }

        }

        if (skill.ZAorOSorTB == 3)
        {
            if (skill._buff == 1)
            {
                battle.healOneC(heal, skill._buff_debuff_turns);
                Debug.Log("skill heals one " + skill._skill_name);

            }
            if (skill._buff == 2)
            {
                battle.strenghtOneC(strenght, skill._buff_debuff_turns);
                Debug.Log("skill buffs strenght for one " + skill._skill_name);

            }
            if (skill._buff == 3)
            {
                battle.defenceOneC(def, skill._buff_debuff_turns);
                Debug.Log("skill buffs defence for one " + skill._skill_name);

            }
        }

        if (skill.ZAorOSorTB == 4)
        {

            if (skill._buff == 1)
            {
                battle.healThreeC(heal, skill._buff_debuff_turns);
                Debug.Log("skill heals all " + skill._skill_name);

            }
            if (skill._buff == 2)
            {
                battle.strenghtThreeC(strenght, skill._buff_debuff_turns);
                Debug.Log("skill buffs strenght for all " + skill._skill_name);

            }
            if (skill._buff == 3)
            {
                battle.defenceThreeC(def, skill._buff_debuff_turns);
                Debug.Log("skill buffs defence for all " + skill._skill_name);

            }

        }
      
    }

    private void debuffAll()
    {
      
        if (skill.ZAorOSorTB == 1)
        {
            if (skill._debuff == 1)
            {
             //   battle.hpDebufOneEnemy(heal, skill._buff_debuff_turns);
            //    Debug.Log("skill DEbuffs heal for one ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 2)
            {
                battle.strDebufOneEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs STR for one ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 3)
            {
                battle.defDebufOneEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs DEF for one ENEMY " + skill._skill_name);

            }
        }

  
          
        
        if (skill.ZAorOSorTB == 2)
        {
            if (skill._debuff == 1)
            {
             //   battle.hpDebufThreeEnemy(heal, skill._buff_debuff_turns);
            //    Debug.Log("skill DEbuffs heal for all ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 2)
            {
                battle.strDebufThreeEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs STR for all ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 3)
            {
                battle.defDebufThreeEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs DEF for all ENEMY " + skill._skill_name);

            }
        }


        


        if (skill.ZAorOSorTB == 3)
        {
            if (skill._debuff == 1)
            {
              //  battle.hpDebufOneEnemy(heal, skill._buff_debuff_turns);
             //   Debug.Log("skill DEbuffs heal for one ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 2)
            {
                battle.strDebufOneEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs STR for one ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 3)
            {
                battle.defDebufOneEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs DEF for one ENEMY " + skill._skill_name);

            }
        }


        if (skill.ZAorOSorTB == 4)
        {
            if (skill._debuff == 1)
            {
             //   battle.hpDebufThreeEnemy(heal, skill._buff_debuff_turns);
             //   Debug.Log("skill DEbuffs heal for all ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 2)
            {
                battle.strDebufThreeEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs STR for all ENEMY " + skill._skill_name);

            }

            if (skill._debuff == 3)
            {
                battle.defDebufThreeEnemy(strenght, skill._buff_debuff_turns);
                Debug.Log("skill DEbuffs DEF for all ENEMY " + skill._skill_name);

            }
        }

      
    }

   

    // Update is called once per frame
    void Update()
    {

    }
}
