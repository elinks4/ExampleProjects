﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TreasureBoxItems : MonoBehaviour
{


    public Text text1;
    public Text text2;

    public int treasureClass;

    public TreasureBoxManager manager;

    public void treasureMeasure(int nro)
    {
        treasureClass = nro;

        text1.text = "Player gets: ";


        if (nro == 0)
        {
            text2.text = "10000 Gold";
        }
        else if(nro == 1)
        {
            text2.text = "1 health potion";

        }
        else if (nro == 2)
        {
            text2.text = "1 character [Allen] ";

        }
        else if (nro == 3)
        {
            text2.text = "1 character [Rixa] ";

        }
        else if (nro == 4)
        {
            text2.text = "20 Gems ";

        }
    }


    public void pushItemInBox()
    {
        manager.giveItemfromTreasure(treasureClass);
    }


    // Start is called before the first frame update
    void Start()
    {
        manager = FindObjectOfType<TreasureBoxManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
