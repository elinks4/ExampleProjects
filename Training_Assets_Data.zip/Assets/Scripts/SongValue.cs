﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SongValue 
{


    public int songNum;
    public int whenToPlay;

    public SongValue(int when, int songN)
    {
        songNum = songN;
        whenToPlay = when;
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
