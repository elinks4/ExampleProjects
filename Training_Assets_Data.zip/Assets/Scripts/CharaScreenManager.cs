﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class CharaScreenManager : MonoBehaviour
{
    public DontDestroyThis DdestroyThis;
    public Player playerOne;
    ChooseOne chooseOne;
    public int theNum;
    public Button prefabbutton;
    public GameObject panel;
    public Button[] Charabuttons;
    public List<Button> buttonsList = new List<Button>();
    public List<Button> toDestroyPrefabs = new List<Button>();
    public Character[] chosenCharactersList = new Character[3];
    public GridLayoutGroup grid;
    public int ChosenCharaNUM;
    public void instantiateCharaButton(int num, int count)
    {
        theNum = count;
        panel.SetActive(true);




        for (int i = 0; i < playerOne.charactersPlayerHasList.Count; i++)
        {




            Button H = createB(num, true, i);
            destOrSave(H);




        }
    }


    public void destOrSave(Button button)
    {

        int thing = 0;

        for (int i = 0; i < buttonsList.Count; i++)
        {
            if (button.GetComponent<ChooseOne>().chosenCharacter._charaID == buttonsList[i].GetComponent<ChooseOne>().chosenCharacter._charaID)
            {

                thing = 1;
            }
        }

     

        if (thing == 1)
        {
            Destroy(button.gameObject);
        }
        else
        {
            toDestroyPrefabs.Add(button);
            buttonsList.Add(button);
            //   Debug.Log("button has character " + button.GetComponent<ChooseOne>().chosenCharacter._name);

        }

    }



    public Button createB(int nro, bool charaOrN, int count)
    {
        Button newB = Instantiate(prefabbutton) as Button;
        newB.GetComponent<ChooseOne>().choNr = nro;

        if (charaOrN)
        {
            newB.GetComponent<ChooseOne>().chosenCharacter = playerOne.charactersPlayerHasList[count];
            newB.GetComponent<ChooseOne>().charaScreenOrNot = true;
        }
        else
        {
            newB.GetComponent<ChooseOne>().chosenDoping = playerOne.dopingsPlayerHas[count];
            newB.GetComponent<ChooseOne>().charaScreenOrNot = true;

        }

        newB.GetComponent<ChooseOne>().charaOrNot = charaOrN;
        newB.transform.SetParent(grid.transform, false);

        return newB;

    }

    public void instantiateDopingButton(int num, int count)
    {
    

            Debug.Log("comes to instantiate Alfa doping");

            theNum = num;
            for (int i = 0; i < playerOne.dopingsPlayerHas.Count; i++)
            {

              
                    Debug.Log("Unnatural doping num is " + playerOne.dopingsPlayerHas[i]._Unnatural_Doping.ToString());

                    Button H = createB(count, false, i);
                    toDestroyPrefabs.Add(H);
                



            }


        panel.SetActive(true);




    }


    public void startFirstCharacterChoosing()
    {

        instantiateCharaButton(1, 1);

    }

    public void startFirstDopeChoosing()
    {

        instantiateDopingButton(4, 4);


    }

    public void setDope(Doping dope)
    {
       
    

        // Button temp;

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
            Destroy(toDestroyPrefabs[i].gameObject);

        }

        theNum = 0;

        toDestroyPrefabs.Clear();

        DdestroyThis.dopingScreenDope = dope._dopingID;

        panel.SetActive(false);

        SceneManager.LoadScene(9);


    }
    public void setChara(Character chara)
    {

        //  Debug.Log("Comes to set Character");


    
            
            
            

  

        //  Button temp;

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
         

            Destroy(toDestroyPrefabs[i].gameObject);

     
        }


        theNum = 0;

        toDestroyPrefabs.Clear();
        buttonsList.Clear();

        DdestroyThis.charaScreenChara = chara._charaID; 


        panel.SetActive(false);

        SceneManager.LoadScene(9);




    }


    public void goBack()
    {

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {


            Destroy(toDestroyPrefabs[i].gameObject);


        }


        theNum = 0;

        toDestroyPrefabs.Clear();
        buttonsList.Clear();


        panel.SetActive(false);

        DdestroyThis.whichCorD = -1;
        DdestroyThis.charaScreenChara = -1;
        DdestroyThis.dopingScreenDope = -1;


        SceneManager.LoadScene(6);
    }



    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
        toDestroyPrefabs.Clear();

        if(DdestroyThis.whichCorD == 1)
        {
            startFirstCharacterChoosing();
        }
        else if(DdestroyThis.whichCorD == 2)
        {
            startFirstDopeChoosing();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
