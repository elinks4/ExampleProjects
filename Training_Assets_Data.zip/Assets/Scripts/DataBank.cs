﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DataBank : MonoBehaviour
{

    public Sprite[] battleSprites;
    public Sprite[] pictureSprites;
    public Sprite[] dopingSprites;
    public Sprite[] enemySprites;
    public Sprite[] faceSprites;
    public Sprite[] bodySprites;
    public Sprite[] spoilSprites;
    public Sprite[] skillSprites;
    public Sprite[] backGSprites;
    public Sprite[] itemSprites;



    // public var Mylist : List.<Character> = new List.<Character>(0)

    public List<Character> charaBank = new List<Character>();
    public List<CharaForm> formBank = new List<CharaForm>();
    public List<Skill> skillBank = new List<Skill>();
    public List<Doping> dopingBank = new List<Doping>();
    public List<Enemy> enemyBank = new List<Enemy>();
    public List<BattleSEquence> battleBank = new List<BattleSEquence>();

    public List<Spoils> spoilsBank = new List<Spoils>();
    public List<Item> itemBank = new List<Item>();

    public bool dataBankNotComplete = false;

    private void Awake()
    {

  

    }


    public void createAll()
    {



        //All Skills in existence
        //Attack one P = 100
        //Attack two P = 75
        //Attack three P = 50
        //give health/str/def to one 300
        //give health/str/def to two 200
        //give health/str/def to three 100
        //Ougi = 500
        //no buffs = 0;
        //this and second = 1;
        //this and two turns = 2
        //this and three turns = 3

        //skill = 0.111f == 0 = charaid / 1 = form id / 1 = skill number / 1 = skill level


        //skillBank.Add(new Skill(, "", 1, false, 100, ));

        //skill : id, name, level, ougi, power,   give health, give str, give deff,   give hp debuff, give str debuff, give def debuff,   att one, att two, att three, save one, save two, save three,  turns


        //    Skill n = new Skill(0, "Oz first skill", 1, false, 100, false, false, false, false, false, false, true, false, false, false, false, false, 0);
        //    Debug.Log("N's name " + n._skill_name);
        //    skillBank.Add(n);
        //    Debug.Log(skillBank.Count.ToString());
        //    Debug.Log(skillBank[0]._skill_name.ToString());

        //  skillBank.Add(new Skill(0.1f, "Oz first skill", 0.11f, false, 100, ));

        float[] levelspow = {11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };

        //Oz
        skillBank.Add(new Skill(0.1f, "Oz first skill",  0.11f, false, 20, 0, 0, 1, 0, levelspow, 1));
        skillBank.Add(new Skill(0.2f, "Oz second skill", 0.21f, false, 10, 0, 0, 2, 0, levelspow, 4)); 
        skillBank.Add(new Skill(0.3f, "Oz third skill",  0.31f, false, 10, 1, 1, 2, 3, levelspow, 5));
        skillBank.Add(new Skill(0.4f, "Oz fourth skill", 0.41f, true, 50, 0, 3, 2, 2, levelspow, 6));

        skillBank[0].giveSkillSprite(skillSprites[3]);
        skillBank[1].giveSkillSprite(skillSprites[2]);
        skillBank[2].giveSkillSprite(skillSprites[4]);



        //Frederica
        skillBank.Add(new Skill(1.1f, "Frederica first  skill", 1.11f, false, 10, 0, 0, 2, 0, levelspow, 22));
        skillBank.Add(new Skill(1.2f, "Frederica second skill", 1.21f, false, 10, 0, 0, 2, 0, levelspow, 23));
        skillBank.Add(new Skill(1.3f, "Frederica third  skill", 1.31f, false, 20, 2, 0, 3, 3, levelspow, 24));
        skillBank.Add(new Skill(1.4f, "Frederica fourth skill", 1.41f, true, 50, 0, 0, 2, 0, levelspow, 25));

        skillBank[4].giveSkillSprite(skillSprites[6]);
        skillBank[5].giveSkillSprite(skillSprites[7]);
        skillBank[6].giveSkillSprite(skillSprites[8]);




        //Lucardo
        skillBank.Add(new Skill(2.1f, "Lucardo first  skill", 2.11f, false, 20, 0, 0, 1, 0, levelspow, 18));
        skillBank.Add(new Skill(2.2f, "Lucardo second skill", 2.21f, false, 10, 0, 0, 2, 0, levelspow, 19));
        skillBank.Add(new Skill(2.3f, "Lucardo third  skill", 2.31f, false, 20, 3, 0, 4, 3, levelspow, 20));
        skillBank.Add(new Skill(2.4f, "Lucardo fourth skill", 2.41f, true, 50, 3, 0, 4, 3, levelspow, 21));

        skillBank[8].giveSkillSprite(skillSprites[15]);
        skillBank[9].giveSkillSprite(skillSprites[16]);
        skillBank[10].giveSkillSprite(skillSprites[17]);


        //Necessity
        skillBank.Add(new Skill(3.1f, "Necessity first  skill", 3.11f, false, 20, 0, 0, 1, 0, levelspow, 14));
        skillBank.Add(new Skill(3.2f, "Necessity second skill", 3.21f, false, 10, 0, 0, 2, 0, levelspow, 15));
        skillBank.Add(new Skill(3.3f, "Necessity third  skill", 3.31f, false, 20, 3, 0, 4, 3, levelspow, 16));
        skillBank.Add(new Skill(3.4f, "Necessity fourth skill", 3.41f, true, 50, 0, 2, 1, 3, levelspow, 17));

        skillBank[12].giveSkillSprite(skillSprites[5]);
        skillBank[13].giveSkillSprite(skillSprites[9]);
        skillBank[14].giveSkillSprite(skillSprites[10]);



        //Allen
        skillBank.Add(new Skill(4.1f, "Allen first  skill", 4.11f, false, 10, 0, 0, 2, 0, levelspow, 10));
        skillBank.Add(new Skill(4.2f, "Allen second skill", 4.21f, false, 20, 0, 0, 1, 0, levelspow, 11));
        skillBank.Add(new Skill(4.3f, "Allen third  skill", 4.31f, false, 20, 2, 0, 4, 3, levelspow, 12));
        skillBank.Add(new Skill(4.4f, "Allen fourth skill", 4.41f, true, 50, 1, 2, 2, 2, levelspow, 13));

        skillBank[16].giveSkillSprite(skillSprites[12]);
        skillBank[17].giveSkillSprite(skillSprites[13]);
        skillBank[18].giveSkillSprite(skillSprites[14]);




        //Rixa
        skillBank.Add(new Skill(5.1f, "Rixa first  skill", 5.11f, false, 20, 0, 0, 1, 0, levelspow, 0));
        skillBank.Add(new Skill(5.2f, "Rixa second skill", 5.21f, false, 20, 1, 1, 2, 2, levelspow, 7));
        skillBank.Add(new Skill(5.3f, "Rixa third  skill", 5.31f, false, 20, 0, 2, 2, 3, levelspow, 8));
        skillBank.Add(new Skill(5.4f, "Rixa fourth skill", 5.41f, true, 50, 0, 0, 1, 0, levelspow, 9));


        skillBank[20].giveSkillSprite(skillSprites[0]);
        skillBank[21].giveSkillSprite(skillSprites[1]);
        skillBank[22].giveSkillSprite(skillSprites[11]);




        // Debug.Log(skillBank[7]._skill_name.ToString());

        //All forms in existence
        //element 0 = Darkness
        //element 1 = Light
        //element 2 = Fire
        //element 3 = Water
        //element 4 = Wind
        //element 5 = Earth

        // formBank.Add(new CharaForm());


        //forms : form id, name, battle sprite, HP, ATT, DEF, element id, skill 1, skill 2, skill 3, skill 4 (ougi)  
        //   List<Sprite> temp = new List<Sprite>();
        //   List<Sprite> temp2 = new List<Sprite>();
        //  List<Sprite> temp3 = new List<Sprite>();

        //  temp.Add(battleSprites[0]);
        //  temp2.Add(faceSprites[0]);
        //  temp3.Add(bodySprites[0]);


        int[] hpArray = gettingChangingArray(2);
        int[] attArray = gettingChangingArray(5);
        int[] defArray = gettingChangingArray(1);

        formBank.Add(new CharaForm(0.1f, "Oz Neutral", battleSprites[0], faceSprites[0], bodySprites[0], 1000, 50, 50, 0, skillBank[0], skillBank[1], skillBank[2], skillBank[3], hpArray, attArray, defArray));
        //   temp.Clear();
        //   temp2.Clear();
        // temp3.Clear();

        //   temp.Add(battleSprites[1]);
        //    temp2.Add(faceSprites[1]);
        //    temp3.Add(bodySprites[1]);
        hpArray = gettingChangingArray(3);
        attArray = gettingChangingArray(3);
        defArray = gettingChangingArray(2);

        formBank.Add(new CharaForm(1.1f, "Frederica Neutral", battleSprites[1], faceSprites[1], bodySprites[1], 900, 70, 40, 2, skillBank[4], skillBank[5], skillBank[6], skillBank[7], hpArray, attArray, defArray));
        //   temp.Clear();
        //    temp2.Clear();
        //    temp3.Clear();

        //     temp.Add(battleSprites[2]);
        //    temp2.Add(faceSprites[2]);
        //    temp3.Add(bodySprites[2]);
        hpArray = gettingChangingArray(2);
        attArray = gettingChangingArray(2);
        defArray = gettingChangingArray(4);

        formBank.Add(new CharaForm(2.1f, "Lucardo Neutral", battleSprites[2], faceSprites[2], bodySprites[2], 1100, 40, 80, 4, skillBank[8], skillBank[9], skillBank[10], skillBank[11], hpArray, attArray, defArray));
        //     temp.Clear();
        //     temp2.Clear();
        //     temp3.Clear();

        //    temp.Add(battleSprites[3]);
        //   temp2.Add(faceSprites[3]);
        //    temp3.Add(bodySprites[3]);
        hpArray = gettingChangingArray(1);
        attArray = gettingChangingArray(6);
        defArray = gettingChangingArray(1);

        formBank.Add(new CharaForm(3.1f, "Necessity Neutral", battleSprites[3], faceSprites[3], bodySprites[3], 900, 80, 40, 5, skillBank[12], skillBank[13], skillBank[14], skillBank[15], hpArray, attArray, defArray));
        //   temp.Clear();
        //   temp2.Clear();
        //    temp3.Clear();


        //    temp.Add(battleSprites[4]);
        //    temp2.Add(faceSprites[4]);
        //    temp3.Add(bodySprites[4]);
        hpArray = gettingChangingArray(5);
        attArray = gettingChangingArray(2);
        defArray = gettingChangingArray(1);

        formBank.Add(new CharaForm(4.1f, "Allen Neutral", battleSprites[4], faceSprites[4], bodySprites[4], 1000, 90, 30, 6, skillBank[16], skillBank[17], skillBank[18], skillBank[19], hpArray, attArray, defArray));
        //     temp.Clear();
        //     temp2.Clear();
        //     temp3.Clear();


        //    temp.Add(battleSprites[5]);
        //    temp2.Add(faceSprites[5]);
        //   temp3.Add(bodySprites[5]);
        hpArray = gettingChangingArray(1);
        attArray = gettingChangingArray(2);
        defArray = gettingChangingArray(5);

        formBank.Add(new CharaForm(5.1f, "Rixa Neutral", battleSprites[5], faceSprites[5], bodySprites[5], 800, 100, 40, 6, skillBank[20], skillBank[21], skillBank[22], skillBank[23], hpArray, attArray, defArray));

    //    temp.Clear();
   //     temp2.Clear();
  //      temp3.Clear();


        Debug.Log("battle sprites count " + battleSprites.Length.ToString());



        //character needs more forms than one, one goes as battle sprite to form
        //All Characters in existence

        // charaBank.Add(new Character(, "", , pictureSprites[], formBank[]));


        // characters : chara id, name, normal sprite, neutral form

        charaBank.Add(new Character(0, "Oz", 5, pictureSprites[0], formBank[0]));
        charaBank.Add(new Character(1, "Frederica", 5, pictureSprites[1], formBank[1]));
        charaBank.Add(new Character(2, "Lucardo", 5, pictureSprites[2], formBank[2]));
        charaBank.Add(new Character(3, "Necessity", 4, pictureSprites[3], formBank[3]));
        charaBank.Add(new Character(4, "Allen", 5, pictureSprites[4], formBank[4]));
        charaBank.Add(new Character(5, "Rixa", 4, pictureSprites[5], formBank[5]));


        //  Debug.Log(charaBank[1]._name.ToString());



        //Doping : dopingID, unnaturalDoping, desc
        dopingBank.Add(new Doping(0, "Force Upper", 0, "Neutral force upper", 1, dopingSprites[1]));
        dopingBank.Add(new Doping(1, "Vampiric Tendency - Group Alfa - part 1", 1, "Unnatural form change for Oz and Frederica", 2, dopingSprites[3]));
        dopingBank.Add(new Doping(-2, "Fluke", -1, "Empty", 0, dopingSprites[0]));




        //SpoilsBank
        spoilsBank.Add(new Spoils(0, "Rabbit Paw", "Paw of a rabbit. Breakthrough material", spoilSprites[0]));
        spoilsBank.Add(new Spoils(1, "Eye Drop", "Drops of eyes. Breakthrough material", spoilSprites[1]));


        //Item Bank
        itemBank.Add(new Item(0, "level Upper", "Levels character up", itemSprites[0]));
        itemBank.Add(new Item(1, "Healing Potion", "Levels character up", itemSprites[1]));
        itemBank[1].setEffect(0, 1000);



        int[] levelArray = gettingArrayForEnemy(2);
        //Enemies
        enemyBank.Add(new Enemy(0, 1000, "K_Rabbit", 70, 70, enemySprites[0], levelArray));

        levelArray = gettingArrayForEnemy(3);

        enemyBank.Add(new Enemy(1, 900, "K_Eye", 90, 80, enemySprites[1], levelArray));

        levelArray = gettingArrayForEnemy(4);
        enemyBank.Add(new Enemy(2, 800, "K_Green_One", 90, 90, enemySprites[2], levelArray));

        levelArray = gettingArrayForEnemy(4);
        enemyBank.Add(new Enemy(3, 1000, "K_Snake", 80, 80, enemySprites[3], levelArray));
        levelArray = gettingArrayForEnemy(5);

        enemyBank.Add(new Enemy(4, 2000, "Boss5a", 90, 80, enemySprites[4], levelArray));
        enemyBank.Add(new Enemy(5, 2000, "Boss5a", 90, 80, enemySprites[4], levelArray));
        enemyBank.Add(new Enemy(6, 2000, "Boss5b", 80, 90, enemySprites[5], levelArray));



        enemyBank[0].inputSpoils(spoilsBank[0]);
        enemyBank[1].inputSpoils(spoilsBank[1]);
        enemyBank[2].inputSpoils(spoilsBank[1]);
        enemyBank[3].inputSpoils(spoilsBank[1]);
        enemyBank[4].inputSpoils(spoilsBank[0]);
        enemyBank[5].inputSpoils(spoilsBank[0]);
        enemyBank[6].inputSpoils(spoilsBank[0]);



        //    Debug.Log("enemies added " + enemyBank.Count.ToString());

        //Battles
        List<Enemy> temporali = new List<Enemy>();
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[0]);

        battleBank.Add(new BattleSEquence(0, 1, temporali, 100, backGSprites[1], backGSprites[0], 0));
        temporali.Clear();
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[1]);
        temporali.Add(enemyBank[1]);
     //   Debug.Log("temporal " + temporali.Count.ToString());

        battleBank.Add(new BattleSEquence(1, 1, temporali, 100, backGSprites[2], backGSprites[0], 0));
        // temporali.Clear();

        //   Debug.Log("enemies added 2 " + battleBank[0]._enemies.Count.ToString() + " " + battleBank[0]._battleID.ToString());
        // Debug.Log("enemies added 3 " + enemyBank.Count.ToString() + " " + battleBank[0].countEnemyNum().ToString());


        temporali.Clear();
        temporali.Add(enemyBank[1]);
        temporali.Add(enemyBank[1]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(2, 2, temporali, 100, backGSprites[3], backGSprites[0], 0));


        temporali.Clear();
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[1]);
        temporali.Add(enemyBank[0]);
        battleBank.Add(new BattleSEquence(3, 2, temporali, 100, backGSprites[2], backGSprites[0], 0));



        temporali.Clear();
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(4, 2, temporali, 100, backGSprites[1], backGSprites[0], 0));


        temporali.Clear();
        temporali.Add(enemyBank[6]);
        Debug.Log("Enemy in ARRAY 5 is " + enemyBank[6]._name);

        // temporali.Add(enemyBank[2]);
        // temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(5, 4, temporali, 100, backGSprites[5], backGSprites[6], 1));

        temporali.Clear();
        temporali.Add(enemyBank[6]);
        Debug.Log("Enemy in ARRAY 6 is " + enemyBank[6]._name);
       // temporali.Add(enemyBank[2]);
       // temporali.Add(enemyBank[2]);
        battleBank.Add(new BattleSEquence(6, 5, temporali, 100, backGSprites[7], backGSprites[8], 1));

        temporali.Clear();
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[3]);
        battleBank.Add(new BattleSEquence(7, 6, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(8, 2, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(9, 4, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[0]);
        battleBank.Add(new BattleSEquence(10, 6, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[3]);
        battleBank.Add(new BattleSEquence(11, 8, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(12, 10, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[0]);
        temporali.Add(enemyBank[2]);
        battleBank.Add(new BattleSEquence(13, 12, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(14, 14, temporali, 100, backGSprites[1], backGSprites[0], 0));

        temporali.Clear();
        temporali.Add(enemyBank[3]);
        temporali.Add(enemyBank[2]);
        temporali.Add(enemyBank[1]);
        battleBank.Add(new BattleSEquence(15, 16, temporali, 100, backGSprites[1], backGSprites[0], 0));

        dataBankNotComplete = true;


      //  Debug.Log(" comes to end charabank count " + charaBank.Count.ToString());






    }

    public int[] gettingChangingArray(int n)
    {

        int[] array = new int[90];

        array[0] = n;

        for(int i = 0; i < array.Length; i++)
        {
            if(i != 0)
            {
                array[i] = array[i - 1] + 5;
            }
        }

        return array;
    }

    public int[] gettingArrayForEnemy(int n)
    {

        int[] array = new int[50];

        array[0] = n;

        for (int i = 0; i < array.Length; i++)
        {
            if (i != 0)
            {
                array[i] = array[i - 1] + 5;
            }
        }

        return array;
    }



    public void deleteAll()
    {
        skillBank.Clear();
        formBank.Clear();
        charaBank.Clear();
        dopingBank.Clear();
        enemyBank.Clear();
    }


    public Character getCharacter(int id)
    {
        int o = -2;
     //   Debug.Log(" o : " + o.ToString() + "charabank count " + charaBank.Count.ToString());


        for (int i = 0; i < charaBank.Count; i++)
        {
           // Debug.Log("goes to loop : " + o.ToString());


            if (charaBank[i]._charaID == id)
            {
                o = i;
             //   Debug.Log(" o : " + o.ToString());
            }
        }


        //    Debug.Log("databank gets id : " + id.ToString() + "charabank " + charaBank[id]._name + " o : " + o.ToString());
        return charaBank[o];
    }

    public Enemy getEnemy(int id)
    {

        int o = -2;


        for (int i = 0; i < enemyBank.Count; i++)
        {
          


            if (enemyBank[i]._enemy_id == id)
            {
                o = i;
            }
        }


        return enemyBank[o];




    }
    public BattleSEquence getBattle(int id)
    {

        int o = -2;

        Debug.Log("BATTLE bank " + " " + battleBank.Count.ToString() + " gotten id is " + id.ToString());

        for (int i = 0; i < battleBank.Count; i++)
        {



            if (battleBank[i]._battleID == id)
            {
                o = i;
            }
        }

        Debug.Log("Getting BATTLE " + o.ToString() + " " + battleBank[0].battleLevel.ToString());
        if(battleBank == null)
        {
            Debug.Log("BATTLE BANK IS NULL ");

        }

        return battleBank[o];




    }


    public CharaForm getForm(float id)
    {
        int o = -2;

      for(int i = 0; i < formBank.Count; i++)
        {
            if(formBank[i].formID == id)
            {
                o = i;
            }
        }


        return formBank[o];

    }

    
    public Doping getDoping(int id)
    {
        return dopingBank[id];
    }







    Character charara;

    public Character changeCharacter(int char_id, List<float> form_id, List<float> charaLevel, List<float> skillLevels)
    {

              

     //   Debug.Log("chara bank count id " + charaBank.Count.ToString() + " char ID is " + char_id.ToString() + " form id count is " + form_id.Count.ToString() + " chara Levels count " + charaLevel.Count.ToString() + " skill Levels count " + skillLevels.Count.ToString());

        for (int i = 0; i < charaBank.Count; i++)
        {

          //  Debug.Log("comes to loop  " + i.ToString());

            if (charaBank[i]._charaID == char_id)
            {
                charara = charaBank[i];
         //       Debug.Log("chara is  " + charara._name);

            }
        }

        for(int i = 0; i < form_id.Count; i++)
        {

          //  Debug.Log("form id " + form_id[i].ToString());

              int ChariD = new System.Version(form_id[i].ToString()).Major;
          //  Debug.Log("int ID major : " + ChariD.ToString());

            if (charara.Cforms[0].formID != form_id[i] && charara._charaID == ChariD) // this shows index error 
            {
                for(int j = 0; j < formBank.Count; j++)
                {
                    if(form_id[i] == formBank[j].formID)
                    {
                        charara.Cforms.Add(formBank[j]);

                    }
                }
            }
            else
            {

            }
        }


        foreach(var level in charaLevel)
        {
            float[] idLv = test2(level);
            int id = (int)idLv[0];

            if(charara._charaID == id)
            {
                charara._level = level;
            }
        }


     //   charara._level = charaLevel;

        foreach(var skill in skillLevels)
        {
            float[] IdLv = test(skill);
            float iid = IdLv[0];
            float llv = IdLv[1];

            for (int i = 0; i < charara.Cforms.Count; i++)
            {
                for(int j = 0; j < charara.Cforms[i].skills.Count; j++)
                {
                    if(charara.Cforms[i].skills[j]._skill_id == iid)
                    {
                        charara.Cforms[i].skills[j]._skill_level = llv;
                    }
                }
            }
        }


        return charara;
    }


    public float[] test(float n)
    {

        //   Debug.Log("start is " + n.ToString());

        float z = n * 10;

        float y = n * 10;

   //   Debug.Log("what n is " + n.ToString() + " what z is " + z.ToString());


        int skillidpart1 = new System.Version(n.ToString()).Major;
        int skillIDpart2 = new System.Version(z.ToString()).Major;



        int skillLevelPart = new System.Version(y.ToString()).Minor;


    //   Debug.Log("why not work part 0 : skillDpart2 : " + skillIDpart2.ToString() + "skillIDpart 1 : " + skillidpart1.ToString());


        float the = (float)skillidpart1;
     //   Debug.Log("why not work  " + the.ToString());

        float hel = (float)skillIDpart2 / 10;
        int thi = new System.Version(hel.ToString()).Minor;
     //   Debug.Log("does this work " + thi.ToString());
        float xx = (float)thi / 10;

        float f = the + xx;


     //   Debug.Log("skill id part " + f.ToString());
     //   Debug.Log("skill Level part " + skillLevelPart.ToString());

        float muu = (float)skillLevelPart;

        float[] result = { f, n};

        return result;
    }



    public float[] test2(float n)
    {


      //  Debug.Log("start is " + n.ToString());



        int charaID = new System.Version(n.ToString()).Major;



        int charaLevel = new System.Version(n.ToString()).Minor;

    //    Debug.Log("skill ID " + charaID.ToString() + " skill level " + charaLevel);



        float muu = (float)charaID;

        float[] result = { muu, n };

        return result;
    }

    Doping change;

    public Doping changeDoping(int id, List<float> levels)
    {


        for (int i = 0; i < dopingBank.Count; i++)
        {
            if (dopingBank[i]._dopingID == id)
            {
                change = dopingBank[i];
            }
        }


        foreach (var level in levels)
        {
            float[] idLv = test2(level);
            int idn = (int)idLv[0];

            if (change._dopingID == idn)
            {
                change._dope_level = level;
            }
        }


        return change;


    }

    public List<Item> getItems(List<int> itemIDs)
    {
        List<Item> returnables = new List<Item>();

        for(int i = 0; i < itemIDs.Count; i++)
        {
            for(int j = 0; j < itemBank.Count; j++)
            {
                if (itemIDs[i] == itemBank[j]._itemId)
                {
                    returnables.Add(itemBank[j]);
                }

            }
        }


        return returnables;

    }


    // Start is called before the first frame update
    void Start()
    {



}

// Update is called once per frame
void Update()
    {
        
    }
}
