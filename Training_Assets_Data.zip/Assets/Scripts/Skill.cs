﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class Skill 
{

    //take off Monobehaviour???



    public float _skill_id;
    public string _skill_name;
    public float _skill_level;
    public bool _is_Ougi;
    public float _power;

    public int _buff;
    public int _debuff;

    public int ZAorOSorTB;

    public int _buff_debuff_turns;

    public Sprite skillSprite;

    private float[] powerLevels;

    public int animNRO;

    public Skill(float skID, string skNa, float skLV, bool isOugi, float pov, int buf_0is0_1isHP_2isSTR_3isDEF, int debuf_0is0_1isHP_2isSTR_3isDEF, int oneIsA1Enemy_twoIsA3Enemy_threeIsS1Ally_fourIsS3Ally, int BDturns, float[] powerchanges, int aniNRO)
    {

        _skill_id = skID;
        _skill_name = skNa;
        _skill_level = (float)skLV;
        _is_Ougi = isOugi;
        _power = pov;
        _buff = buf_0is0_1isHP_2isSTR_3isDEF;
        _debuff = debuf_0is0_1isHP_2isSTR_3isDEF;
        ZAorOSorTB = oneIsA1Enemy_twoIsA3Enemy_threeIsS1Ally_fourIsS3Ally;
        _buff_debuff_turns = BDturns;
        animNRO = aniNRO;
        powerLevels = powerchanges;

    }

    public void giveLevelup(float lv)
    {
        _skill_level = (float)lv;
        int majorpart = new System.Version(lv.ToString()).Major;

        _power = _power + powerLevels[majorpart];

        Debug.Log("skill " + _skill_name + " has " + _power.ToString() + " power at level " + _skill_level.ToString());
    }

    public void levelUPOnce()
    {
          int majorpart = new System.Version(_skill_level.ToString()).Major;
        int minorpart = new System.Version(_skill_level.ToString()).Minor;
        int trye1 = minorpart + 1;
        float trye2 = majorpart + ((float)trye1 / 100);
        _skill_level = trye2;
        _power = _power * (float)_skill_level;
    }

    public void giveSkillSprite(Sprite sp)
    {
        skillSprite = sp;
    }



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
