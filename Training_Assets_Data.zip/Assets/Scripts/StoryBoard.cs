﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StoryBoard : MonoBehaviour
{

    public Image BackGround;
    public Image charaIma;
    public Image charaIma2;
    public Image charaIma3;

    public InputField field;

    public Text nameText;
    public Text storyText;

    public Button storyButton;

    public Sprite[] mcSprites;
    public Sprite[] bgSprites;

    private string namePos;

    public Sprite ret;

    public int phaseNum;

    public GameObject Qpanel;
    public Button ansButton1;
    public Button ansButton2;
    public Text QpaText;

    private Player playerOne;
    private DontDestroyThis DdestroyThis;

   public DialogueTrigger trigger;
   public Scenery storyScenes;

    public AudioSource audioSo;

    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
       // trigger = FindObjectOfType<DialogueTrigger>();

        charaIma.gameObject.SetActive(false);
        charaIma2.gameObject.SetActive(false);
        charaIma3.gameObject.SetActive(false);

        phaseNum = playerOne.phaseLevel;

        // storyScenes = FindObjectOfType<Scenery>();

        


        field.gameObject.SetActive(false);

        

        if(DdestroyThis.whereStoryStays <= 0)
        {

            trigger.triggerDialogue(phaseNum, playerOne.storyRoute);

        }
        else
        {

            trigger.triggerContinue(phaseNum, DdestroyThis.whereStoryStays, playerOne.storyRoute);
        }
    }


    public void setName(string name)
    {
        nameText.text = name;
    }

    public void setSentence(string dia)
    {
        storyText.text = dia;
    }


    public void setPic2(List<int> placeNR, List<int> picNR)
    {

     //   charaIma.gameObject.SetActive(true);
     //   charaIma2.gameObject.SetActive(true);
     //   charaIma3.gameObject.SetActive(true);


        for (int i = 0; i < placeNR.Count; i++)
        {
            if(i == 0 && placeNR[i] == 0)
            {
                charaIma.gameObject.SetActive(false);

            }
           else if (i == 1 && placeNR[i] == 0)
            {
                charaIma2.gameObject.SetActive(false);

            }
           else if (i == 2 && placeNR[i] == 0)
            {
                charaIma3.gameObject.SetActive(false);

            }
           else if (i == 0 && placeNR[i] != 0)
            {
                getSprite(placeNR[i], picNR[i]);
                charaIma.sprite = ret;
                charaIma.gameObject.SetActive(true);

            }
          else  if(i == 1 && placeNR[i] != 0)
            {
                getSprite(placeNR[i], picNR[i]);
                charaIma2.sprite = ret;
                charaIma2.gameObject.SetActive(true);
            }
           else  if (i == 2 && placeNR[i] != 0)
            {
                getSprite(placeNR[i], picNR[i]);
                charaIma3.sprite = ret;
                charaIma3.gameObject.SetActive(true);
            }
        }


    }


    /*

    public void setPic(int imaNum, int[] charaNum, int[] picNum)
    {
        Debug.Log("ima num is " + imaNum.ToString());
        charaIma.gameObject.SetActive(true);
        charaIma2.gameObject.SetActive(true);
        charaIma3.gameObject.SetActive(true);


        //only left
        if (imaNum == 1)
        {
            getSprite(charaNum, picNum);

            charaIma.sprite = ret[0];
            charaIma2.sprite = ret[1];
            charaIma3.sprite = ret[2];


            charaIma.gameObject.SetActive(true);
            charaIma3.gameObject.SetActive(false);
            charaIma2.gameObject.SetActive(false);

        }
        //only right
        else if(imaNum == 2)
        {
            getSprite(charaNum, picNum);
            charaIma3.sprite = ret[0];
            charaIma2.sprite = ret[1];
            charaIma.sprite = ret[2];

            charaIma3.gameObject.SetActive(true);
            charaIma.gameObject.SetActive(false);
            charaIma2.gameObject.SetActive(false);
        }
        //only middle
        else if(imaNum == 0)
        {
            getSprite(charaNum, picNum);
            charaIma2.sprite = ret[0];
            charaIma3.sprite = ret[1];
            charaIma.sprite = ret[2];

            charaIma2.gameObject.SetActive(true);
            charaIma3.gameObject.SetActive(false);
            charaIma.gameObject.SetActive(false);
        }
        //left pic save middle
        else if(imaNum == 3)
        {
            getSprite(charaNum, picNum);
            charaIma.gameObject.SetActive(true);
            charaIma.sprite = ret[0]; 
            charaIma3.gameObject.SetActive(false);
        }
        //right pic save middle
        else if (imaNum == 4)
        {
            getSprite(charaNum, picNum);
            charaIma3.gameObject.SetActive(true);
            charaIma3.sprite = ret[0]; 
            charaIma.gameObject.SetActive(false);
        }
        //middle pic save left
        else if (imaNum == 5)
        {
            getSprite(charaNum, picNum);
            charaIma2.gameObject.SetActive(true);
            charaIma2.sprite = ret[0]; 
            charaIma3.gameObject.SetActive(false);
        }
        //right pic save left 
        else if(imaNum == 6)
        {
            getSprite(charaNum, picNum);
            charaIma2.gameObject.SetActive(true);
            charaIma3.sprite = ret[0]; 
            charaIma.gameObject.SetActive(false);
        }
        else
        {
            charaIma2.gameObject.SetActive(false);
            charaIma.gameObject.SetActive(false);
            charaIma3.gameObject.SetActive(false);

        }

    }

    */



    public void openInputField()
    {
        field.gameObject.SetActive(true);
        storyButton.gameObject.SetActive(false);
    }

    public void getText(string tex)
    {
        namePos = tex;
    }


    public void makeFinalName()
    {
        if(namePos == null)
        {
            namePos = "Allen";

        }
        if (namePos == "")
        {
            namePos = "Allen";
        }
        playerOne.nameChange(namePos);
        field.gameObject.SetActive(false);
        storyButton.gameObject.SetActive(true);

        storyScenes.continueStory();
    }





    public void getSprite(int charaNum, int picNum)
    {

        Debug.Log("Chara Num is " + charaNum.ToString() + " pic Num " + picNum.ToString());
        if(charaNum == 1)
        {
            //Mc
          ret = mcSprites[picNum];
        }
        if(charaNum == 2)
        {
            ret = mcSprites[picNum];

        }
        else
        {
            ret = mcSprites[picNum];

        }
    }


    public void makeQuestion(string que, string q1, string q2)
    {
        storyButton.gameObject.SetActive(false);


        Qpanel.gameObject.SetActive(true);
        QpaText.text = que;

        ansButton1.GetComponentInChildren<Text>().text = q1;
        ansButton2.GetComponentInChildren<Text>().text = q2;


    }

    public void setBGPic(int nro)
    {
        if(nro != 0)
        {
            nro = nro - 1;
            BackGround.sprite = bgSprites[nro];

        }
    }


    public void answerQ1()
    {
        storyScenes.list.ANR = 1;
        Qpanel.gameObject.SetActive(false);
        storyScenes.afterQue1();

    }

    public void answerQ2()
    {
        storyScenes.list.ANR = 2;
        Qpanel.gameObject.SetActive(false);
        storyScenes.afterQue2();
    }


    public void stayNumber(int nr)
    {
        DdestroyThis.whereStoryStays = nr;
        DdestroyThis.whichBattleToDo = playerOne.phaseLevel;
        DdestroyThis.StoryOrExtra = 1;
        SceneManager.LoadScene(2);
      

    }

    public void goOnWithStory()
    {
        playerOne.phaseLevel += 1;
        SceneManager.LoadScene(8);

    }

    public void afterChoosingRoute(int route)
    {
        playerOne.storyRoute = route;
        storyButton.gameObject.SetActive(true);
        playerOne.phaseLevel += 1;

        SceneManager.LoadScene(8);

    }

    public void afterChoosingRoute2(int route)
    {
        playerOne.storyRoute = route;
        storyButton.gameObject.SetActive(true);
        playerOne.phaseLevel += 1;

        SceneManager.LoadScene(8);

    }


    public void readLine(int lineplus)
    {

    }

    public void setDDto0()
    {
        DdestroyThis.whereStoryStays = 0;
        DdestroyThis.whichBattleToDo = -1;
        DdestroyThis.StoryOrExtra = -1;

    }


    public void storyClear()
    {
        playerOne.phaseLevel++;
        SceneManager.LoadScene(8);

    }


    public void givePlayerName(string name)
    {
        playerOne.playerName = name;
    }

    public void setSong(int nro)
    {

        audioSo.clip = DdestroyThis.audioM.getSong(nro);
        audioSo.Play();

    }

    public void checkSoundComings(int round, List<SongValue> values)
    {
        Debug.Log("Comes to checking Sound with round of " + round.ToString() + " and values count of " +values.Count.ToString());

        if (values.Count != 0)
        {

            for (int i = 0; i < values.Count; i++)
            {
                if (round == values[i].whenToPlay)
                {
                    setSong(values[i].songNum);
                }
            }

        }
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
