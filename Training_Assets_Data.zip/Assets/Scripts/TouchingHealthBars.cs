﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TouchingHealthBars : MonoBehaviour
{

    public BattleProgram battle;
    public Image border;
    public Text text;
    public Slider slider;
    public int maxHP;
    public bool isChosen = false;
    public bool isChosen2 = false;
    public int codeNum;



    public void setOugi(float energy)
    {

        if (energy != 0 && energy != 1)
        {
            int majorpart = new System.Version(energy.ToString()).Major;
            int minorpart = new System.Version(energy.ToString()).Minor;
            int trye1 = minorpart + 1;

     //       Debug.Log("energy charge " + trye1.ToString());

            float trye2 = majorpart + ((float)trye1 / 100);
            energy = trye2;
            slider.value += energy;

        }
        else
        {
            slider.value += energy;

        }

        if (slider.value >= 1)
        {
            battle.canOugi = true;
        }

        setOugiText(slider.value);
    }

    public void nullOugi()
    {
        slider.value = 0;
        setOugiText(slider.value);

    }

    public void setOugiText(float val)
    {

     //   Debug.Log("value is " + val.ToString());




        text.text = val.ToString() + " /  100 %";

        if (val != 0 && val != 1)
        {
            float res = val * 100;
            int res2 = (int)res; 
       //     Debug.Log("result is " + res2.ToString());

          //  int majorpart = new System.Version(res.ToString()).Major;

          //  int minorpart = new System.Version(val.ToString()).Minor;
            text.text = res2.ToString() + " /  100 %";

        }
        else if(val == 1)
        {
            text.text =  "100 /  100 %";

        }
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void setHealth(int health)
    {
        slider.value = health;
        text.text = health.ToString() + " / " + maxHP.ToString();

    }

    public void startHealth(int hp)
    {
        slider.maxValue = hp;
        slider.value = hp;
        maxHP = hp;
        text.text = hp.ToString() + " / " + maxHP.ToString();
    }


   public void unColorBorder()
    {
        border.color = Color.clear;
    }

    public void colorBorderBlue()
    {
        border.color = Color.blue;

    }

    public void colorBred()
    {
        border.color = Color.red;

    }

    public void colorBYellow()
    {
        border.color = Color.yellow;

    }

    public void colorBgray()
    {
        border.color = Color.gray;

    }

    public void colorBwhite()
    {
        border.color = Color.white;

    }




    public void onTouch()
    {

        if(isChosen == false)
        {
            isChosen = true;
            colorBorderBlue();
            battle.showOtherTwoColors(codeNum);

        }
        else if (isChosen)
        {
          
        }


      
    }

    public void onTouch2()
    {
        if (isChosen2 == false)
        {
            isChosen2 = true;
            colorBorderBlue();
            battle.showOtherTwoColors(codeNum);
            


        }
        else if (isChosen2)
        {
         //   isChosen2 = false;
         //   unColorBorder();
          //  battle.showOtherTwoColors();

        }
    }
}
