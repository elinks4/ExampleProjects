﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DontDestroyThis : MonoBehaviour
{

    public Player player;
    public DataBank bank;
    public SpoonFeedPlayer spoon;


    public AudioManager audioM;
      public bool firstTimeH = true;

    public List<int> chL = new List<int>();
    public int[] dopingsAlfaUsed = {-1, -1, -1};
    public int[] dopingsNeutralUsed = { -1, -1, -1 };
    public int charaScreenChara;
    public int dopingScreenDope;
    public int whichCorD;
    public int whichBattleToDo;
    public int StoryOrExtra;
    public int whereStoryStays;
    public bool fistTimeToHome;
    public bool firstTimeInThisBattle;
  //  public int storyRoute;
    private void Awake()
    {
        DontDestroyOnLoad(gameObject);


        if (player.firtsTime == false)
        {
            player.LoadPlayer();
            bank.deleteAll();

            bank.createAll();
            charaScreenChara = -1;
            dopingScreenDope = -1;
            whichCorD = -1;
            StoryOrExtra = -1;

            if (player.loadComplete == true)
            {
       //         Debug.Log("Comes to Start play load complete");

                //  yield return new WaitForEndOfFrame();
              
                    Debug.Log("load complete");

                if (bank.dataBankNotComplete)
                {
                    spoon.spoonfeedingTime();
                }

                player.loadComplete = false;
                    SceneManager.LoadScene(6);

                

              



            }

        }
        else if(player.firtsTime)
        {
            Debug.Log("comes to first time");
            player.characterDeleteForTesting();
            bank.deleteAll();
            bank.createAll();
            player.phaseLevel = 1;
            player.farthestPhase = 7;
            charaScreenChara = -1;
            dopingScreenDope = -1;
            whichCorD = -1;
            player.playerName = null;
            player.extraQDone = 0;
            fistTimeToHome = true;
            player.goldPlayerHas = 0;
            player.mGems = 0;
            player.kGems = 0;
            player.TreasureStuffIDs.Clear();
            player.storyRoute = 0;
            // firstTimeH = false;
            SceneManager.LoadScene(6);
        }

        player.firtsTime = false;
    }


    void Start()
    {

       


    }

    // Update is called once per frame
    void Update()
    {
        
    }



    void OnApplicationQuit()
    {
        Debug.Log("Application ending after " + Time.time + " seconds");
        bank.dataBankNotComplete = false;
        player.SavePlayer();
    }

}
