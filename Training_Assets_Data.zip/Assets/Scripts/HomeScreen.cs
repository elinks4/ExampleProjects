﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class HomeScreen : MonoBehaviour
{


   public Sprite[] tutorialSprites;

  private  DontDestroyThis dDestroy;


    private Player playerOne;
    public AudioSource audioSo;

    public TreasureBoxManager boxManager;

    public Text goldText;
    public Text gemText;

    public int bothGems;

    public Image image;

    private int nextSp;

    public void toGacha()
    {
        SceneManager.LoadScene(1);

    }

    public void toStory()
    {
        if(playerOne.phaseLevel <= 1)
        {
            SceneManager.LoadScene(5);

        }
        else
        {
            SceneManager.LoadScene(8);

        }

    }


    public void toCharas()
    {
        dDestroy.whichCorD = 1;
        SceneManager.LoadScene(7);

    }

    public void toDopes()
    {
        dDestroy.whichCorD = 2;
        SceneManager.LoadScene(7);

    }

    public void firstTimeToHomeScreen()
    {
        Debug.Log("First Time Bonus Given");
        giveStuffToBox(0);
        giveStuffToBox(1);
        giveStuffToBox(2);
        giveStuffToBox(3);
        giveStuffToBox(4);

        
    }

    public void giveStuffToBox(int id)
    {
     
        playerOne.TreasureStuffIDs.Add(id);

        playerOne.TreasureStuffIDs.Sort();

    }


    public void openTreasureBox()
    {
        boxManager.instantiateItemButton();
    }


    public void giveThingsfromTreasureBox(int numOfGiven)
    {

        if(numOfGiven == 0)
        {
            playerOne.goldPlayerHas += 10000;


        }
        else if(numOfGiven == 1)
        {
            playerOne.gettingNewItem(1);
        }
        else if(numOfGiven == 2)
        {
            playerOne.gettingNewChara(dDestroy.bank.getCharacter(4));

        }
        else if (numOfGiven == 3)
        {
            playerOne.gettingNewChara(dDestroy.bank.getCharacter(5));

        }
        else if(numOfGiven == 4)
        {
            playerOne.mGems += 20;
        }

        updateTexts();

     
    }


    public void updateTexts()
    {
        bothGems = playerOne.mGems + playerOne.kGems;
        gemText.text = bothGems.ToString();

        goldText.text = playerOne.goldPlayerHas.ToString();
    }


    // Start is called before the first frame update
    void Start()
    {
        dDestroy = FindObjectOfType<DontDestroyThis>();
        playerOne = dDestroy.player;
        if (dDestroy.fistTimeToHome == true)
        {
            firstTimeToHomeScreen();
            dDestroy.fistTimeToHome = false;

        }

   
        updateTexts();

        nextSp = 0;
        image.sprite = tutorialSprites[nextSp];


        // = dDestroy.audioM;

        audioSo.clip = dDestroy.audioM.getSong(2);
        audioSo.Play();
        


    }


    public void nextSprite()
    {
        nextSp += 1;
        if(nextSp < tutorialSprites.Length)
        {
            image.sprite = tutorialSprites[nextSp];

        }
        else
        {
            nextSp = 0;
            image.sprite = tutorialSprites[nextSp];

        }
    }


  

    // Update is called once per frame
    void Update()
    {
        
    }
}
