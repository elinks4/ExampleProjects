﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FighterCharacterChanges : MonoBehaviour
{

    public Slider sliderC;
    public Sprite formSprite;
    public Sprite faceSprite;
    public Sprite bodySprite;

    public Sprite nullimage;

    public bool canBeAttacked = true;

   

    public float _level;

    public float _charaID;

    public string formName;
    public int _hp;
    public int _element;
    public int _att;
    public int _deff;


    public int changing_hp;
    public int changing_att;
    public int changing_def;


    public int hpdbufTurn1 = 0;
    public int hpdbufTurn2 = 0;
    public int hpdbufTurn3 = 0;
    public int hpdbufTurn4 = 0;


    public int strdbufTurn1 = 0;
    public int strdbufTurn2 = 0;
    public int strdbufTurn3 = 0;
    public int strdbufTurn4 = 0;


    public int defdbufTurn1 = 0;
    public int defdbufTurn2 = 0;
    public int defdbufTurn3 = 0;
    public int defdbufTurn4 = 0;


    public int healTurn1 = 0;
    public int healTurn2 = 0;
    public int healTurn3 = 0;
    public int healTurn4 = 0;


    public int defD1 = 0;
    public int defD2 = 0;
    public int defD3 = 0;
    public int defD4 = 0;


    public int strD1 = 0;
    public int strD2 = 0;
    public int strD3 = 0;
    public int strD4 = 0;




    public int strbTurn1 = 0;
    public int strbTurn2 = 0;
    public int strbTurn3 = 0;
    public int strbTurn4 = 0;


    public int defbTurn1 = 0;
    public int defbTurn2 = 0;
    public int defbTurn3 = 0;
    public int defbTurn4 = 0;


    public int bufHeal1 = 0;
    public int bufHeal2 = 0;
    public int bufHeal3 = 0;
    public int bufHeal4 = 0;


    public int strP1 = 0;
    public int strP2 = 0;
    public int strP3 = 0;
    public int strP4 = 0;


    public int defP1 = 0;
    public int defP2 = 0;
    public int defP3 = 0;
    public int defP4 = 0;


    private int hp_deduf_hurt1 = 0;
    private int hp_deduf_hurt2 = 0;
    private int hp_deduf_hurt3 = 0;
    private int hp_deduf_hurt4 = 0;




    public List<Skill> skills = new List<Skill>();



    public void giveCharatoFight(Character charar)
    {

        CharaForm chara = charar.chosenForm;

        _charaID = charar._charaID;


        formName = chara.formName;
        formSprite = chara.formSprite;
        _element = chara._element;
        faceSprite = chara.faceSprite;
        bodySprite = chara.fullBody;
        skills = chara.skills;

     

        _hp = charar.chosenForm._hp;
        _att = charar.chosenForm._att;
        _deff = charar.chosenForm._deff;

        changing_hp = _hp;
        changing_att = _att;
        changing_def = _deff;

        gameObject.GetComponent<Image>().sprite = formSprite;
        


        sliderC.GetComponent<TouchingHealthBars>().startHealth(changing_hp);

   //     Debug.Log("chara name " + formName + " has healthbar of " + sliderC.GetComponent<TouchingHealthBars>().maxHP.ToString());


        hpdbufTurn1 = 0;
        hpdbufTurn2 = 0;
        hpdbufTurn3 = 0;
        hpdbufTurn4 = 0;


        strdbufTurn1 = 0;
        strdbufTurn2 = 0;
        strdbufTurn3 = 0;
        strdbufTurn4 = 0;


        defdbufTurn1 = 0;
        defdbufTurn2 = 0;
        defdbufTurn3 = 0;
        defdbufTurn4 = 0;


        healTurn1 = 0;
        healTurn2 = 0;
        healTurn3 = 0;
        healTurn4 = 0;




        strbTurn1 = 0;
        strbTurn2 = 0;
        strbTurn3 = 0;
        strbTurn4 = 0;


        defbTurn1 = 0;
        defbTurn2 = 0;
        defbTurn3 = 0;
        defbTurn4 = 0;



        bufHeal1 = 0;
        bufHeal2 = 0;
        bufHeal3 = 0;
        bufHeal4 = 0;


        strP1 = 0;
        strP2 = 0;
        strP3 = 0;
        strP4 = 0;


        defP1 = 0;
        defP2 = 0;
        defP3 = 0;
        defP4 = 0;


        hp_deduf_hurt1 = 0;
        hp_deduf_hurt2 = 0;
        hp_deduf_hurt3 = 0;
        hp_deduf_hurt4 = 0;



        Color coli = gameObject.GetComponent<Image>().color;
        coli.a = 255;

        gameObject.GetComponent<Image>().color = coli;
    }


    public void lessenTurns()
    {
        if (hpdbufTurn1 >= 1)
        {
            hpdbufTurn1 -= 1;
            changing_hp = changing_hp - hp_deduf_hurt1;

        }
        if (hpdbufTurn2 >= 1)
        {
            hpdbufTurn2 -= 1;
            changing_hp = changing_hp - hp_deduf_hurt2;

        }
        if (hpdbufTurn3 >= 1)
        {
            hpdbufTurn3 -= 1;
            changing_hp = changing_hp - hp_deduf_hurt3;

        }
        if (hpdbufTurn4 >= 1)
        {
            hpdbufTurn4 -= 1;
            changing_hp = changing_hp - hp_deduf_hurt4;

        }





        if (healTurn1 >= 1)
        {
            healTurn1 -= 1;
            if(changing_hp < _hp)
            changing_hp = changing_hp + bufHeal1;

            if (changing_hp > _hp)
                changing_hp = _hp;

        }
        if (healTurn2 >= 1)
        {
            healTurn2 -= 1;
            if (changing_hp < _hp)
                changing_hp = changing_hp + bufHeal2;

            if (changing_hp > _hp)
                changing_hp = _hp;

        }
        if (healTurn3 >= 1)
        {
            healTurn3 -= 1;
            if (changing_hp < _hp)
                changing_hp = changing_hp + bufHeal3;

            if (changing_hp > _hp)
                changing_hp = _hp;

        }
        if (healTurn4 >= 1)
        {
            healTurn4 -= 1;
            if (changing_hp < _hp)
                changing_hp = changing_hp + bufHeal4;

            if (changing_hp > _hp)
                changing_hp = _hp;

        }
        else if (hpdbufTurn1 == 0)
        {
           // changing_hp = _hp;
        }






        if (strbTurn1 >= 1)
        {
            strbTurn1 -= 1;
        }
        else if (strbTurn1 == 0)
        {
            changing_att = changing_att - strP1;
            strP1 = 0;

        }
        if (strbTurn2 >= 1)
        {
            strbTurn2 -= 1;
        }
        else if (strbTurn2 == 0)
        {
            changing_att = changing_att - strP2;
            strP2 = 0;

        }
        if (strbTurn3 >= 1)
        {
            strbTurn3 -= 1;
        }
        else if (strbTurn3 == 0)
        {
            changing_att = changing_att - strP3;
            strP3 = 0;

        }
        if (strbTurn4 >= 1)
        {
            strbTurn4 -= 1;
        }
        else if (strbTurn4 == 0)
        {
            changing_att = changing_att - strP4;
            strP4 = 0;

        }



        if (defbTurn1 >= 1)
        {
            defbTurn1 -= 1;
        }
        else if (defbTurn1 == 0)
        {
            changing_def = changing_def - defP1;
            defP1 = 0;

        }
        if (defbTurn2 >= 1)
        {
            defbTurn2 -= 1;
        }
        else if (defbTurn2 == 0)
        {
            changing_def = changing_def - defP2;
            defP2 = 0;

        }
        if (defbTurn3 >= 1)
        {
            defbTurn3 -= 1;
        }
        else if (defbTurn3 == 0)
        {
            changing_def = changing_def - defP3;
            defP3 = 0;

        }
        if (defbTurn4 >= 1)
        {
            defbTurn4 -= 1;
        }
        else if (defbTurn4 == 0)
        {
            changing_def = changing_def - defP4;
            defP4 = 0;

        }





        if (defdbufTurn1 >= 1)
        {
            defdbufTurn1 -= 1;
        }
        else if (defdbufTurn1 == 0)
        {
            changing_def = changing_def + defD1;
            defD1 = 0;
        }

        if (defdbufTurn2 >= 1)
        {
            defdbufTurn2 -= 1;
        }
        else if (defdbufTurn2 == 0)
        {
            changing_def = changing_def + defD2;
            defD2 = 0;
        }
        if (defdbufTurn3 >= 1)
        {
            defdbufTurn3 -= 1;
        }
        else if (defdbufTurn3 == 0)
        {
            changing_def = changing_def + defD3;
            defD3 = 0;
        }
        if (defdbufTurn4 >= 1)
        {
            defdbufTurn4 -= 1;
        }
        else if (defdbufTurn4 == 0)
        {
            changing_def = changing_def + defD4;
            defD4 = 0;
        }






        if (strdbufTurn1 >= 1)
        {
            strdbufTurn1 -= 1;
        }
        else if (strdbufTurn1 == 0)
        {
            changing_att = changing_att + strP1;
            strP1 = 0;
        }
        if (strdbufTurn2 >= 1)
        {
            strdbufTurn2 -= 1;
        }
        else if (strdbufTurn2 == 0)
        {
            changing_att = changing_att + strP2;
            strP2 = 0;
        }
        if (strdbufTurn3 >= 1)
        {
            strdbufTurn3 -= 1;
        }
        else if (strdbufTurn3 == 0)
        {
            changing_att = changing_att + strP3;
            strP3 = 0;
        }
        if (strdbufTurn4 >= 1)
        {
            strdbufTurn4 -= 1;
        }
        else if (strdbufTurn4 == 0)
        {
            changing_att = changing_att + strP4;
            strP4 = 0;
        }
    }










    public void takeHeal(int heal, int turn)
    {
        if(bufHeal1 == 0)
        {
            bufHeal1 = heal;
            healTurn1 = turn;

            if(changing_hp < _hp)
                changing_hp = changing_hp + heal;
        }
        else if(bufHeal2 == 0)
        {
            bufHeal2 = heal;
            healTurn2 = turn;

            if (changing_hp < _hp)
                changing_hp = changing_hp + heal;
        }
        else if (bufHeal3 == 0)
        {
            bufHeal3 = heal;
            healTurn3 = turn;

            if (changing_hp < _hp)
                changing_hp = changing_hp + heal;
        }
        else if (bufHeal4 == 0)
        {
            bufHeal4 = heal;
            healTurn4 = turn;

            if (changing_hp < _hp)
                changing_hp = changing_hp + heal;
        }

        if (changing_hp > _hp)
            changing_hp = _hp;


        sliderC.GetComponent<TouchingHealthBars>().setHealth(changing_hp);


    }




    public void takeStreghtening(int str, int turn)
    {
        Debug.Log("Character " + formName + " has STR BEFORE BUFF is " + changing_att.ToString());

        int newplus = (changing_att + str) / 2;


        if (strP1 == 0)
        {
            strP1 = newplus;
            strbTurn1 = turn;
            changing_att = changing_att + newplus;

        }
       else if (strP2 == 0)
        {
            strP2 = newplus;
            strbTurn2 = turn;
            changing_att = changing_att + newplus;

        }
        else if (strP3 == 0)
        {
            strP3 = newplus;
            strbTurn3 = turn;
            changing_att = changing_att + newplus;

        }
        else if (strP4 == 0)
        {
            strP4 = newplus;
            strbTurn4 = turn;
            changing_att = changing_att + newplus;

        }

        Debug.Log("Character " + formName + " has gotten BUFF on STR, new STR is " + changing_att.ToString());

    }




    public void takeDefensing(int def, int turn)
    {
        Debug.Log("Character " + formName + " has DEF BEFORE BUFF is " + changing_def.ToString());

        int newplus = (changing_def + def) / 2;

        if (defP1 == 0)
        {
            defP1 = newplus;
            defbTurn1 = turn;
            changing_def = changing_def + newplus;
        }
       else if (defP2 == 0)
        {
            defP2 = newplus;
            defbTurn2 = turn;
            changing_def = changing_def + newplus;
        }
        else if (defP3 == 0)
        {
            defP3 = newplus;
            defbTurn3 = turn;
            changing_def = changing_def + newplus;
        }
        else if (defP4 == 0)
        {
            defP4 = newplus;
            defbTurn4 = turn;
            changing_def = changing_def + newplus;
        }


        Debug.Log("Character " + formName + " has gotten BUFF on DEF, new DEF is " + changing_def.ToString());
    }





    public void takeHP_DEBuff(int attack, int turn)
    {
        if(hp_deduf_hurt1 == 0)
        {
            hp_deduf_hurt1 = attack;
            hpdbufTurn1 = turn;
            changing_hp = changing_hp - attack;
        }
       else if (hp_deduf_hurt2 == 0)
        {
            hp_deduf_hurt2 = attack;
            hpdbufTurn2 = turn;
            changing_hp = changing_hp - attack;
        }
        else if (hp_deduf_hurt3 == 0)
        {
            hp_deduf_hurt3 = attack;
            hpdbufTurn3 = turn;
            changing_hp = changing_hp - attack;
        }
        else if (hp_deduf_hurt4 == 0)
        {
            hp_deduf_hurt4 = attack;
            hpdbufTurn4 = turn;
            changing_hp = changing_hp - attack;
        }


        sliderC.GetComponent<TouchingHealthBars>().setHealth(changing_hp);
    }







    public void takeSTR_DEBuff(int attack, int turn)
    {
        if(strD1 == 0)
        {
            strD1 = attack;
            strdbufTurn1 = turn;
            changing_att = changing_att - attack;

        }
       else if (strD2 == 0)
        {
            strD2 = attack;
            strdbufTurn2 = turn;
            changing_att = changing_att - attack;

        }
        else if (strD3 == 0)
        {
            strD3 = attack;
            strdbufTurn3 = turn;
            changing_att = changing_att - attack;

        }
        else if (strD4 == 0)
        {
            strD4 = attack;
            strdbufTurn4 = turn;
            changing_att = changing_att - attack;

        }
    }









    public void takeDEF_DEBuff(int attack, int turn)
    {
        if(defD1 == 0)
        {
            defD1 = attack;
            defdbufTurn1 = turn;
            changing_def = changing_def - attack;

        }
       else if (defD2 == 0)
        {
            defD2 = attack;
            defdbufTurn2 = turn;
            changing_def = changing_def - attack;

        }
        else if (defD3 == 0)
        {
            defD3 = attack;
            defdbufTurn3 = turn;
            changing_def = changing_def - attack;

        }
        else if (defD4 == 0)
        {
            defD4 = attack;
            defdbufTurn4 = turn;
            changing_def = changing_def - attack;

        }
    }





    public int takeAttack(int attack)
    {
        if (canBeAttacked)
        {

            // int ndef = new System.Version(im.ToString()).Major;
            int damage;

            if (attack >= changing_def)
            {
                //damage = attack / changing_def * 100;
                damage = Mathf.Max(1, (attack - changing_def));
              

            }
            else
            {
                //damage = changing_def / attack * 100;
                // damage = Mathf.Max(1, (attack - changing_def));
                damage = attack - changing_def;
                damage = Mathf.Clamp(damage, 1, int.MaxValue);
            }
            //   int damage = attack * (100 / increasedDef);

            Debug.Log("CHARACTER HP is " + changing_hp.ToString() + " Damage to Character is " + damage.ToString());


            //   Debug.Log("Character damage is " + damage.ToString() + " CHARACTER HP is " + changing_hp.ToString());
            if (damage >= changing_hp)
            {
                changing_hp = 0;
                canBeAttacked = false;
                Debug.Log("CHARACTER HP is INSIDE IF " + changing_hp.ToString());


                

                if (canBeAttacked)
                {
                    Debug.Log("CHARACTER CanBeAttacked NOT WORKING ");

                }
            }
            else
            {
                changing_hp = changing_hp - damage;
             //   Debug.Log("CHARACTER HP is " + changing_hp.ToString());
            }
        }
        else
        {
            changing_hp = 0;
            Debug.Log("CHARACTER HP is zero " + changing_hp.ToString());


        }

        if (changing_hp <= 0)
        {

            gameObject.GetComponent<Image>().sprite = nullimage;
            Color coli = gameObject.GetComponent<Image>().color;
            coli.a = 0;

            gameObject.GetComponent<Image>().color = coli;

        }

        sliderC.GetComponent<TouchingHealthBars>().setHealth(changing_hp);

        return changing_hp;

        
    }



}
