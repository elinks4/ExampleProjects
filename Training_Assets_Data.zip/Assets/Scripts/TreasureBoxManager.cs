﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class TreasureBoxManager : MonoBehaviour
{

    public HomeScreen home;
    public DontDestroyThis DdestroyThis;
    public Player playerOne;
    public Button prefabbutton;
    public GameObject panel;
    public List<Button> buttonsList = new List<Button>();
    public List<Button> toDestroyPrefabs = new List<Button>();
    public GridLayoutGroup grid;

    public List<int> ToTreasureStuffIDs = new List<int>();
    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
        toDestroyPrefabs.Clear();
      
    }


    // Update is called once per frame
    void Update()
    {
        
    }


    public void giveStuffToBox2(int id)
    {

        playerOne.TreasureStuffIDs.Add(id);

        playerOne.TreasureStuffIDs.Sort();

    }



    public void instantiateItemButton()
    {
        
        panel.SetActive(true);




        for (int i = 0; i < playerOne.TreasureStuffIDs.Count; i++)
        {




            Button H = createB(playerOne.TreasureStuffIDs[i], i);

            toDestroyPrefabs.Add(H);
            buttonsList.Add(H);

        }
    }




    public Button createB(int nro, int count)
    {
        Button newB = Instantiate(prefabbutton) as Button;




        newB.GetComponent<TreasureBoxItems>().treasureMeasure(nro);






        newB.transform.SetParent(grid.transform, false);

        return newB;

    }






    public void giveItemfromTreasure(int nro)
    {

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {

            if (toDestroyPrefabs[i].GetComponent<TreasureBoxItems>().treasureClass == nro)
            {
                buttonsList.RemoveAt(i);
                Destroy(toDestroyPrefabs[i].gameObject);
                toDestroyPrefabs.RemoveAt(i);

                Debug.Log("NRO is " + nro.ToString() + " I is " + i.ToString());
            }


        }
        for(int i = 0; i < playerOne.TreasureStuffIDs.Count; i++)
        {
            if (playerOne.TreasureStuffIDs[i] == nro)
            {
                playerOne.TreasureStuffIDs.RemoveAt(i);
            }
        }


        home.giveThingsfromTreasureBox(nro);


    }



    public void goBack()
    {

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {


            Destroy(toDestroyPrefabs[i].gameObject);


        }


      

        toDestroyPrefabs.Clear();
        buttonsList.Clear();


        panel.SetActive(false);




    }

}
