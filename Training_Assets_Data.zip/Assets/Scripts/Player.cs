﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Player : MonoBehaviour
{

   // public DataBank dataBank;

    public int level;
    public int playerID;
    public int phaseLevel;
    public int farthestPhase;
    public string playerName;
    public int extraQDone;
    public int goldPlayerHas;
    public int mGems;
    public int kGems;

    public List<Character> charactersPlayerHasList = new List<Character>();
    public List<int> characterIDsPlayerHasList = new List<int>();
    public List<float> charaFormsPlayerHasList = new List<float>();

    public List<float> charaSkillThatPlayerHasLevels = new List<float>();
   public List<float> charaThatPlayerHasLevels = new List<float>();

    public List<Doping> dopingsPlayerHas = new List<Doping>();
    public List<int> dopingsIDsPlayerHas = new List<int>();

    public List<float> levelsDopingshave = new List<float>();

    public bool firtsTime = true;

    public bool loadComplete = false;


    public List<int> spoilsIDInventory = new List<int>();


    public List<int> itemIDInventory = new List<int>();

    public List<int> TreasureStuffIDs = new List<int>();

    public int storyRoute;


    //get new character(from gacha)
    public void gettingNewChara(Character chara)
    {
      
       

        if (charactersPlayerHasList.Count > 0)
        {
          //  Debug.Log("player has more than null : " + chara._charaID.ToString() + " with character count : " + charactersPlayerHasList.Count.ToString());


            if (checkCharactersIDs(chara._charaID) == false)
            {
               // Character chara = dataBank.getCharacter(charaId);

                charactersPlayerHasList.Add(chara);
                characterIDsPlayerHasList.Add(chara._charaID);

                float num = chara._charaID + 0.01f;
                charaThatPlayerHasLevels.Add(num);

                characterIDsPlayerHasList.Sort();//OrderBy(x => x.GetComponent<Character>()._charaID).ToList();
                charaThatPlayerHasLevels.Sort();

                charaFormsPlayerHasList.Add(chara.Cforms[0].formID);
          //      Debug.Log("Added character FORM : " + chara.Cforms[0].formName);

                charaFormsPlayerHasList.Sort();

               
       //         Debug.Log("Added character LEVEl : " + charaThatPlayerHasLevels.Count.ToString());


                for (int i = 0; i < chara.Cforms[0].skills.Count; i++)
                {
                    charaSkillThatPlayerHasLevels.Add(chara.Cforms[0].skills[i]._skill_level);

                }


                charaSkillThatPlayerHasLevels.Sort();

             //   Debug.Log("Added character : " + chara._name);

            }
            else
            {
               // Debug.Log("has character already");
            }


        }
        else
        {
         //   Debug.Log("player goes to NULL : " + chara._charaID.ToString());



           // Character chara = dataBank.getCharacter(charaId);

            charactersPlayerHasList.Add(chara);
            characterIDsPlayerHasList.Add(chara._charaID);

               characterIDsPlayerHasList.Sort();//.OrderBy(x => x.GetComponent<Character>()._charaID).ToList();


            charaFormsPlayerHasList.Add(chara.Cforms[0].formID);
        //    Debug.Log("Added character FORM : " + chara.Cforms[0].formName);

            charaFormsPlayerHasList.Sort();


            float n = chara._charaID + 0.01f;

             charaThatPlayerHasLevels.Add(n);
            charaThatPlayerHasLevels.Sort();


            //     Debug.Log("Added character LEVEl : " + charaThatPlayerHasLevels.Count.ToString());


            for (int i = 0; i < chara.Cforms[0].skills.Count; i++)
            {
                charaSkillThatPlayerHasLevels.Add(chara.Cforms[0].skills[i]._skill_level);

            }

            charaSkillThatPlayerHasLevels.Sort();

            //    Debug.Log("Added character : " + chara._name);
        }



    }

    public void nameChange(string name)
    {
        playerName = name;
    }

    
    public void gettingBackChara(Character chara)
    {
        if (charactersPlayerHasList.Count > 0)
        {
            if (checkCharactersIDs(chara._charaID) == false)
            {
                charactersPlayerHasList.Add(chara);
              //  Debug.Log("Returned character : " + chara._name);

            }
        }
        else
        {
            charactersPlayerHasList.Add(chara);
        //    Debug.Log("Returned character : " + chara._name);

        }

    }

    
    public void LevelUpStatNums()
    {
        for(int i = 0; i < charactersPlayerHasList.Count; i++)
        {
            charactersPlayerHasList[i].levelUpStats();
        }

        for (int i = 0; i < charaSkillThatPlayerHasLevels.Count; i++)
        {
            int nr = new System.Version(charaSkillThatPlayerHasLevels[i].ToString()).Major;
            int num = new System.Version(charaSkillThatPlayerHasLevels[i].ToString()).Minor;
       //     Debug.Log("num is " + num.ToString());

            float numV2 = (float)num / 10;
        //    Debug.Log("num is " + num.ToString() + " numV2 is " + numV2.ToString());

            int numV3 = new System.Version(numV2.ToString()).Major;
            int numV4 = new System.Version(numV2.ToString()).Minor;
        //    Debug.Log("num is " + num.ToString() + " numV2 is " + numV2.ToString() + " numV3 is " + numV3.ToString());

            float nmm = (float)numV4 / 100;

         //   Debug.Log("num is " + num.ToString() + " numV2 is " + numV2.ToString() + " numV3 is " + numV3.ToString() + " nmm is " + nmm.ToString());
            if (nmm != 0.01f)
            {

                for (int j = 0; j < charactersPlayerHasList.Count; j++)
                {
                    if (nr == charactersPlayerHasList[j]._charaID)
                    {
                        for (int k = 0; k < charactersPlayerHasList[j].Cforms.Count; k++)
                        {
                            for (int m = 0; m < charactersPlayerHasList[j].Cforms[k].skills.Count; m++)
                            {
                                int nrr = new System.Version(charactersPlayerHasList[j].Cforms[k].skills[m]._skill_id.ToString()).Minor;
                                if (nrr == numV3)
                                {
                                    charactersPlayerHasList[j].Cforms[k].skills[m].giveLevelup(charaSkillThatPlayerHasLevels[i]);
                                    Debug.Log("Found pair lv is nrr " + nrr.ToString() + " numV3 is " + numV3.ToString() + " original is " + charaSkillThatPlayerHasLevels[i].ToString());

                                }
                            }

                        }
                    }
                }

            }
        }
    }


    public void levelUpSkillInfo(float lv)
    {
      



        for (int i = 0; i < charaSkillThatPlayerHasLevels.Count; i++)
        {
            

           // Debug.Log(" lv is " + lv.ToString()  + " original is " + charaSkillThatPlayerHasLevels[i].ToString() );

            if(lv == charaSkillThatPlayerHasLevels[i])
            {
                Debug.Log("Found pair lv is " + lv.ToString() + " original is " + charaSkillThatPlayerHasLevels[i].ToString());

                float ski = charaSkillThatPlayerHasLevels[i];
                int majorpart = new System.Version(ski.ToString()).Major;
                int minorpart = new System.Version(ski.ToString()).Minor;
                int trye1 = minorpart + 1;
                float trye2 = majorpart + ((float)trye1 / 100);

                charaSkillThatPlayerHasLevels[i] = trye2;
                Debug.Log("ski is " + ski.ToString() + "Changed is " + charaSkillThatPlayerHasLevels[i].ToString());

            }
        }

    }

    public void gettingNewItem(int iteID)
    {

        itemIDInventory.Add(iteID);
        itemIDInventory.Sort();

    }


    public void gettingBackDoping(Doping dope)
    {
        if (dopingsPlayerHas.Count > 0)
        {
            if (checkDopingIDs(dope._dopingID) == false)
            {
                dopingsPlayerHas.Add(dope);
             
         //       Debug.Log("Returned doping  : " + dope._name);

            }
        }
        else
        {
            dopingsPlayerHas.Add(dope);
          //  Debug.Log("Returned doping  : " + dope._name);
        }


    }



    //get when you equip doping that gives your character this form
    //This needs to be made again
    public void gettingNewForm(float forma)
    {

       // CharaForm forma = dataBank.getForm(formaID);
      
       
            if (checkCharaForms(forma) == false)
            {
                addFormToCharacter(forma);
            Debug.Log("Added character form : " + forma.ToString());

        }
    }





    public void gettingNewDoping(Doping dope)
    {

        if (checkDopingIDs(dope._dopingID) == false)
        {
          //  Doping dope = dataBank.getDoping(dopeID);
            dopingsPlayerHas.Add(dope);
            dopingsIDsPlayerHas.Add(dope._dopingID);
            levelsDopingshave.Add(dope._dope_level);
            dopingsIDsPlayerHas.Sort();
            levelsDopingshave.Sort();
        }
        else
        {
            for(int i = 0; i < dopingsPlayerHas.Count; i++)
            {
              int  DLevel = new System.Version(dopingsPlayerHas[i]._dope_level.ToString()).Minor;

                if (dopingsPlayerHas[i]._dopingID == dope._dopingID && DLevel < 5)
                {
                    dopingsPlayerHas[i].levelUpDOpeOnce();
                  
                    for(int j = 0; j < levelsDopingshave.Count; j++)
                    {
                     //   Debug.Log("Levels Dopings Have: " + levelsDopingshave[j]);
                        float idLv = test2(levelsDopingshave[j]);
                        int idn = (int)idLv;

                        if(dopingsPlayerHas[i]._dopingID == idn)
                        {
                            //levelsDopingshave[j] += 0.1f;
                            int majorpart = new System.Version(levelsDopingshave[j].ToString()).Major;

                            int minorpart = new System.Version(levelsDopingshave[j].ToString()).Minor;
                            int trye1 = minorpart + 1;
                            float trye2 = majorpart + ((float)trye1 / 100);
                            levelsDopingshave[j] = trye2;
                               Debug.Log("Levels Dopings Have: " + levelsDopingshave[j]);

                        }
                    }
                  

                 //   Debug.Log("dopelevel increased by one : " + dopingsPlayerHas[i]._name);
                }
            }
        }


    }


    


    public float test2(float n)
    {


      //  Debug.Log("start is " + n.ToString());

        int charaID;
        int charaLevel;
        string version = n.ToString();
        int dashIndex = n.ToString().IndexOf("-");
        if (dashIndex > -1)
        {
         //   Debug.Log("does this work It comes here");
            version = version.Substring(0, dashIndex);
            System.Version v = new System.Version(version);
            charaID = new System.Version(v.ToString()).Major;
            charaLevel = new System.Version(v.ToString()).Minor;

        }

        else
        {
            charaID = new System.Version(n.ToString()).Major;
            charaLevel = new System.Version(n.ToString()).Minor;

        }





        //  Debug.Log("skill ID " + charaID.ToString() + " skill level " + charaLevel);



        float muu = (float)charaID;

        float result = muu;

        return result;
    }



    public void giveAlreadyHavenCharacter()
    {

    }





    public void levelUpCharacterLV(int charaID)
    {

        for(int i = 0; i < charactersPlayerHasList.Count; i++)
        {
            if(charactersPlayerHasList[i]._charaID == charaID)
            {
                charactersPlayerHasList[i]._level++;

             //   float n = forma.formID;
              //  int ChariD = new System.Version(n.ToString()).Major;




                /*


                for(int j = 0; j < charaThatPlayerHasLevels.Count; j++)
                {
                    int ChariD = new System.Version(charaThatPlayerHasLevels[j].ToString()).Major;

                    if(ChariD == charaID)
                    {
                        charaThatPlayerHasLevels[j] += 0.1f;
                        Debug.Log("character level increased by one : " + charactersPlayerHasList[i]._name);

                    }
                }



                */
            }
        }

    }




    public void levelUpCharacterSkills(int chara_ID, int skill_id_or_placing)
    {

    }




  // public DontDestroyThis dontD;
    //after loading
    public void putThingsBackInOrder(int[] charaIDs, float[] charaFormIDs, float[] charaskills, float[] charaLevels, int[] dopingIDs, float[] dopingLevels, int[] spoils, int[] items, int[] treasureIDs)
    {

     //   Debug.Log("comes to load system, is stuff ok : " + charaIDs.Length.ToString());

        characterDeleteForTesting();


      //  Debug.Log("comes to load system, is stuff ok : " + charaIDs.Length.ToString());


        for (int i = 0; i < charaIDs.Length; i++)
        {
            // charactersPlayerHasList.Add(bank.getCharacter(charaIDs[i]));
            characterIDsPlayerHasList.Add(charaIDs[i]);
            characterIDsPlayerHasList.Sort();
        }

        for(int i = 0; i < charaFormIDs.Length; i++)
        {
            charaFormsPlayerHasList.Add(charaFormIDs[i]);
            charaFormsPlayerHasList.Sort();



          //  int ChariD = new System.Version(charaFormIDs[i].ToString()).Major;
       
        }

        for(int i = 0; i < charaskills.Length; i++)
        {
            charaSkillThatPlayerHasLevels.Add(charaskills[i]);
        }


        for (int i = 0; i < dopingIDs.Length; i++)
        {
            dopingsIDsPlayerHas.Add(dopingIDs[i]);
        }

        for (int i = 0; i < dopingLevels.Length; i++)
        {
            levelsDopingshave.Add(dopingLevels[i]);
        }
        for(int i = 0; i < charaLevels.Length; i++)
        {
            charaThatPlayerHasLevels.Add(charaLevels[i]);
            charaThatPlayerHasLevels.Sort();

        }
        for (int i = 0; i < spoils.Length; i++)
        {
            spoilsIDInventory.Add(spoils[i]);
        }

        for(int i = 0; i < items.Length; i++)
        {
            itemIDInventory.Add(items[i]);
        }
        for(int i = 0; i < treasureIDs.Length; i++)
        {
            TreasureStuffIDs.Add(treasureIDs[i]);
        }
        
        loadComplete = true;
    }


    public void levelingUpCharaLevelList(float id)
    {
        for (int i = 0; i < characterIDsPlayerHasList.Count; i++)
        {
            if (id == characterIDsPlayerHasList[i])
            {
                int majorpart = new System.Version(charaThatPlayerHasLevels[i].ToString()).Major;
                int minorpart = new System.Version(charaThatPlayerHasLevels[i].ToString()).Minor;
                int trye1 = minorpart + 1;

                //easier += 1;
                float nm1 = (float)id + 0.1f;
                float nm2 = (float)id + 0.2f;
                float nm3 = (float)id + 0.3f;
                float nm4 = (float)id + 0.4f;
                float nm5 = (float)id + 0.5f;
                float nm6 = (float)id + 0.6f;
                float nm7 = (float)id + 0.7f;
                float nm8 = (float)id + 0.8f;


                Debug.Log("charaid + level " + nm1.ToString());

                if (nm1 == charaThatPlayerHasLevels[i])
                {
                    Debug.Log("Comes in charaid + level " + nm1.ToString());
                    trye1 = 11;
                }
                else if (nm2 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 21;

                }
                else if (nm3 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 31;

                }
                else if (nm4 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 41;

                }
                else if (nm5 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 51;

                }
                else if (nm6 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 61;

                }
                else if (nm7 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 71;

                }
                else if (nm8 == charaThatPlayerHasLevels[i])
                {
                    trye1 = 81;

                }



                float trye2 = majorpart + ((float)trye1 / 100);
                charaThatPlayerHasLevels[i] = trye2;
               
               int charaLevelPart = new System.Version(charaThatPlayerHasLevels[i].ToString()).Minor;


                if(charaLevelPart > 90)
                {
                    Debug.Log("nr is " + charaThatPlayerHasLevels[i].ToString());
                }
            }
        }
    }



    public void characterDeleteForTesting()
    {
        charactersPlayerHasList.Clear();
        charaFormsPlayerHasList.Clear();
        charaSkillThatPlayerHasLevels.Clear();
        characterIDsPlayerHasList.Clear();
        charaThatPlayerHasLevels.Clear();
        dopingsPlayerHas.Clear();
        levelsDopingshave.Clear();
        dopingsIDsPlayerHas.Clear();
        spoilsIDInventory.Clear();
        itemIDInventory.Clear();
        TreasureStuffIDs.Clear();
     
       
        
      //  Debug.Log("cleared charas " + charactersPlayerHasList.Count.ToString());
    }






    //saving method

    public void SavePlayer()
    {
        SaveSystem.SavePlayer(this);
    }

    public void LoadPlayer()
    {
        PlayerData data = SaveSystem.LoadPlayer();

        level = data.playerlevel;
        playerID = data.playerID;
        firtsTime = data.firstTime;
        phaseLevel = data.playerPhaseLevel;
        playerName = data.playerN;
        extraQDone = data.EQDone;
        goldPlayerHas = data.gold;
        mGems = data.mGems;
        kGems = data.kGems;
        farthestPhase = data.farthestPlace;
        storyRoute = data.RouteOfStory;
        putThingsBackInOrder(data.charasHaven, data.charaFormsHaven, data.charaFormsSkillLevels, data.charaLevels, data.dopingIdsthatPlayerHas, data.dopingLevels, data.spoilsPlayerHas, data.itemsPlayerHas, data.treasureIDs);
    }






    //checks if player has characters

    public bool checkCharactersIDs(int id)
    {

        bool found = false;
 //       Debug.Log("comes to character checker with id : " + id.ToString());
    //    Debug.Log("comes to character checker with chara count : " + charactersPlayerHasList.Count.ToString());


        for (int i = 0; i < charactersPlayerHasList.Count; i++)
        {
     //       Debug.Log("comes to checker loop with loop : " + i.ToString());
          //  Debug.Log("character id : " + charactersPlayerHasList[i]._charaID.ToString());


            if (charactersPlayerHasList[i]._charaID == id)
            {
             //   Debug.Log("founds character with : " + charactersPlayerHasList[i]._charaID.ToString());

                found = true;
            }
        }

        if (found == false)
        {
            return false;

        }
        else
        {
            return true;

        }
    }






    //checks if player already has form
    public bool checkCharaForms(float forma)
    {

        bool found = false;


        for (int i = 0; i < charactersPlayerHasList.Count; i++)
        {
            for(int j = 0; j < charactersPlayerHasList[i].Cforms.Count; j++)
            {
                if(charactersPlayerHasList[i].Cforms[j].formID == forma)
                {
                    found = true;
                }
            }
        }
        if(found == false)
        {
          

            return false;
        }

        else 
        {
            return true;

        }
    }

    public bool checkDopingIDs(int id)
    {
        bool found = false;

        for(int i = 0; i < dopingsPlayerHas.Count; i++)
        {
            if(dopingsPlayerHas[i]._dopingID == id)
            {
                found = true;
            }
        }

        if(found == true)
        {
            return true;
        }
        else
        {
            return false;
        }

    }



    //adds character form 
    public void addFormToCharacter(float forma)
    {
       

       // float n = forma.formID;
      //  int ChariD = new System.Version(n.ToString()).Major;

        for (int i = 0; i < charactersPlayerHasList.Count; i++)
        {
            if(charactersPlayerHasList[i]._charaID == forma)
            {
                
              //  charactersPlayerHasList[i].giveNewForm(forma);

                charaFormsPlayerHasList.Add(forma);
               // charaFormsPlayerHasList.OrderBy(x => x.GetComponent<CharaForm>().formID).ToList();
            }
        }

  
    }

    public Character returnPlayersCharacter(int id)
    {

        int o = -2;


        for (int i = 0; i < charactersPlayerHasList.Count; i++)
        {



            if (charactersPlayerHasList[i]._charaID == id)
            {
                o = i;
            }
        }


        return charactersPlayerHasList[o];



    }

    public Doping returnPlayersDoping(int id)
    {
        int o = -2;


        for (int i = 0; i < dopingsPlayerHas.Count; i++)
        {



            if (dopingsPlayerHas[i]._dopingID == id)
            {
                o = i;
            }
        }


        return dopingsPlayerHas[o];


    }



    public void increasePhaseLevel()
    {

        phaseLevel = phaseLevel + 1;


    }


    public void increaseSpoilToInventory(Spoils[] spoil)
    {
        for(int i = 0; i < spoil.Length; i++)
        {
            spoilsIDInventory.Add(spoil[i]._ID);

        }
    }


    public void checkSpoilsInventory(DataBank bank)
    {
        List<int> intsL = new List<int>();
        int nums = 0;

        for(int i = 0; i < bank.spoilsBank.Count; i++)
        {
            for(int j = 0; j < spoilsIDInventory.Count; j++)
            {
                if(bank.spoilsBank[i]._ID == spoilsIDInventory[j])
                {
                    nums = nums + 1;
                }
            }

            intsL.Add(nums);
            nums = 0;
        }


    }





    private void Awake()
    {
        // dataBank = FindObjectOfType<DataBank>();
        //   dataBank = FindObjectOfType<DataBank>();
        //  dataBank = GetComponent<DataBank>();
      //dontD = FindObjectOfType<DontDestroyThis>();

    }


    // Update is called once per frame
    void Update()
    {
        
    }





}
