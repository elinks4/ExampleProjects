﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doping 
{
    //take off Monobehaviour???


    public int _dopingID;
    public string _name;
    public float _dope_level;
    public int _Unnatural_Doping;
    public string _desc;
    public Sprite _sprite;
    public int _effect;

    public Doping(int id, string namer, int unnaturalD, string desc, int effect, Sprite sp)
    {
        _dopingID = id;
        _name = namer;
        _Unnatural_Doping = unnaturalD;
        _desc = desc;
        _dope_level = (float)id + 0.1f;
        _sprite = sp;
        _effect = effect;
    }


    public void levelUpDOpeOnce()
    {

        int majorpart = new System.Version(_dope_level.ToString()).Major;
        int minorpart = new System.Version(_dope_level.ToString()).Minor;
        int trye1 = minorpart + 1;

        float trye2 = majorpart + ((float)trye1 / 100);
        _dope_level = trye2;
    }


    public int getPower()
    {
        int minorpart = new System.Version(_dope_level.ToString()).Minor;

        int returnable = 0;

        if (minorpart == 1)
        {
            returnable = 10;
        }
        else if(minorpart == 2)
        {
            returnable = 15;

        }
        else if (minorpart == 3)
        {
            returnable = 20;

        }
        else if (minorpart == 4)
        {
            returnable = 25;

        }
        else if (minorpart == 5)
        {
            returnable = 30;

        }
        else if (minorpart == 6)
        {
            returnable = 35;

        }
        else if (minorpart == 7)
        {
            returnable = 40;

        }
        else if (minorpart == 8)
        {
            returnable = 45;

        }
        else if (minorpart == 9)
        {
            returnable = 50;

        }
        else 
        {
            returnable = 55;

        }

        return returnable;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
