﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spoils 
{

    public string _name;
    public int _ID;
    public string _desc;
    public Sprite _image;

    public Spoils(int id, string name, string desc, Sprite im)
    {

        _name = name;
        _ID = id;
        _desc = desc;
        _image = im;
    }



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
