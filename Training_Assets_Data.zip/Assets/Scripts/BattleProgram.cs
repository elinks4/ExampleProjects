﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.Collections;

public class BattleProgram : MonoBehaviour
{

    public Image CharacterFace;


    public Image BackGImaUp;
    public Image BackGImaDown;


    public AnimHelper aniHel;

    public Sprite nullimage;


    public Character char1;
    public Character char2;
    public Character char3;

    public Doping dopingA1;
    public Doping dopingA2;
    public Doping dopingA3;
    public Doping dopingN1;
    public Doping dopingN2;
    public Doping dopingN3;

    public Slider sliderC1;
    public Slider sliderC2;
    public Slider sliderC3;



    public Button attack1;
    public Button attack2;
    public Button attack3;

    public Button Ougi;

    public Button itemCancel;


    public GameObject tryChara1;
    public GameObject tryChara2;
    public GameObject tryChara3;

    public GameObject charaChosen;

    public GameObject tryE1;
    public GameObject tryE2;
    public GameObject tryE3;

    public GameObject tryChosenE;


    private DontDestroyThis DdestroyThis;

    private Player playerOne;

    private DataBank bank;

    public int battlePhase;
    public int battleLevel;

    private BattleSEquence battle;

    public bool canPlay = false;


    public int attackingNro = 0;


    public Button toNextB;

    public GameObject show1;
    public GameObject show2;
    public GameObject show3;

    public Slider OugiGauge;

    public bool canOugi;

    public int winOrLose;

    public AudioSource audioSo;

    // Start is called before the first frame update
    void Start()
    {



        DdestroyThis = FindObjectOfType<DontDestroyThis>();


        toNextB.gameObject.SetActive(false);

        playerOne = DdestroyThis.player;
        bank = DdestroyThis.bank;

        battlePhase = DdestroyThis.whichBattleToDo;



        Debug.Log("battle Phase is " + battlePhase.ToString());
        Debug.Log("Farthest place is " + playerOne.farthestPhase.ToString() + "whichBattle to do " + DdestroyThis.whichBattleToDo.ToString());


        battle = bank.getBattle(battlePhase - 1);



        BackGImaUp.sprite = battle.backG1;
        BackGImaDown.sprite = battle.backG2;

        char1 = playerOne.returnPlayersCharacter(DdestroyThis.chL[0]);
        char2 = playerOne.returnPlayersCharacter(DdestroyThis.chL[1]);
        char3 = playerOne.returnPlayersCharacter(DdestroyThis.chL[2]);

        tryChara1.GetComponent<FighterCharacterChanges>().giveCharatoFight(char1);
        tryChara2.GetComponent<FighterCharacterChanges>().giveCharatoFight(char2);
        tryChara3.GetComponent<FighterCharacterChanges>().giveCharatoFight(char3);


        tryChara1.GetComponent<FighterCharacterChanges>().nullimage = nullimage;
        tryChara2.GetComponent<FighterCharacterChanges>().nullimage = nullimage;
        tryChara3.GetComponent<FighterCharacterChanges>().nullimage = nullimage;



        if (DdestroyThis.dopingsAlfaUsed[0] != -1)
        {
            dopingA1 = playerOne.returnPlayersDoping(DdestroyThis.dopingsAlfaUsed[0]);
        }
        if (DdestroyThis.dopingsAlfaUsed[1] != -1)
        {
            dopingA2 = playerOne.returnPlayersDoping(DdestroyThis.dopingsAlfaUsed[1]);
        }
        if (DdestroyThis.dopingsAlfaUsed[2] != -1)
        {
            dopingA3 = playerOne.returnPlayersDoping(DdestroyThis.dopingsAlfaUsed[2]);

        }


        if (DdestroyThis.dopingsNeutralUsed[0] != -1)
        {
            dopingN1 = playerOne.returnPlayersDoping(DdestroyThis.dopingsNeutralUsed[0]);

        }
        if (DdestroyThis.dopingsNeutralUsed[1] != -1)
        {
            dopingN2 = playerOne.returnPlayersDoping(DdestroyThis.dopingsNeutralUsed[1]);

        }
        if (DdestroyThis.dopingsNeutralUsed[2] != -1)
        {
            dopingN3 = playerOne.returnPlayersDoping(DdestroyThis.dopingsNeutralUsed[2]);

        }


        if(dopingN1 != null)
        {
            if (dopingN1._effect == 1)
            {
                tryChara1.GetComponent<FighterCharacterChanges>().changing_att += dopingN1.getPower();
            }
        }
        if(dopingN2 != null)
        {
            if (dopingN2._effect == 1)
            {
                tryChara2.GetComponent<FighterCharacterChanges>().changing_att += dopingN2.getPower();
            }
        }
        if(dopingN3 != null)
        {
            if (dopingN3._effect == 1)
            {
                tryChara3.GetComponent<FighterCharacterChanges>().changing_att += dopingN3.getPower();
            }


        }


        if(battle.isBossfight != 1)
        {
            tryE1.GetComponent<EnemyChanges>().giveEnem(battle.getEnemy(0));
            tryE2.GetComponent<EnemyChanges>().giveEnem(battle.getEnemy(1));
            tryE3.GetComponent<EnemyChanges>().giveEnem(battle.getEnemy(2));


            battleLevel = battle.battleLevel;

            tryE1.GetComponent<EnemyChanges>().increaseStrenghtByBattleLevel(battleLevel);
            tryE2.GetComponent<EnemyChanges>().increaseStrenghtByBattleLevel(battleLevel);
            tryE3.GetComponent<EnemyChanges>().increaseStrenghtByBattleLevel(battleLevel);


            tryE1.GetComponent<EnemyChanges>().nullimage = nullimage;
            tryE2.GetComponent<EnemyChanges>().nullimage = nullimage;
            tryE3.GetComponent<EnemyChanges>().nullimage = nullimage;


            audioSo.clip = DdestroyThis.audioM.getSong(7);
            audioSo.Play();

        }
        else
        {

            if (playerOne.storyRoute == 2)
            {
                battlePhase += 1;

                BackGImaUp.sprite = bank.backGSprites[7];
                BackGImaDown.sprite = bank.backGSprites[8];
            }
            else
            {

                BackGImaUp.sprite = battle.backG1;
                BackGImaDown.sprite = battle.backG2;
            }

            tryE1.GetComponent<EnemyChanges>().giveEnem(bank.getEnemy(battlePhase - 1));
            tryE1.GetComponent<EnemyChanges>().increaseStrenghtByBattleLevel(battleLevel);
            tryE1.GetComponent<EnemyChanges>().nullimage = nullimage;

            Debug.Log("Is Boss Battle and id is " + battle._battleID.ToString() + " Enemy name is " + battle._enemies[0]._name + " battle level is " + battle.battleLevel.ToString());

            tryE2.GetComponent<EnemyChanges>().nullimage = nullimage;
            tryE3.GetComponent<EnemyChanges>().nullimage = nullimage;

            tryE2.GetComponent<EnemyChanges>().notInthisBattle();
            tryE3.GetComponent<EnemyChanges>().notInthisBattle();

            audioSo.clip = DdestroyThis.audioM.getSong(6);
            audioSo.Play();
        }









        attack1.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[0], tryChara1);
        attack2.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[1], tryChara1);
        attack3.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[2], tryChara1);
        Ougi.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[3], tryChara1);




        attackingNro = 0;


     

        charaChosen = tryChara1;
        tryChosenE = tryE1;


        tryChosenE.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().onTouch();
        charaChosen.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().onTouch2();

        CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;




        OugiGauge.GetComponent<TouchingHealthBars>().setOugiText(0);
        canOugi = false;

        showPinpoint();




        canPlay = true;

    }

    public void raiseOugiGage(float val)
    {
        if(val == 0)
        {
            OugiGauge.GetComponent<TouchingHealthBars>().nullOugi();
            canOugi = false;

        }
        else
        {
            OugiGauge.GetComponent<TouchingHealthBars>().setOugi(val);
        }
    }

    public void showPinpoint()
    {
        if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            show1.SetActive(true);
            show2.SetActive(false);
            show3.SetActive(false);

        }
        else if (tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            show1.SetActive(false);
            show2.SetActive(true);
            show3.SetActive(false);
        }
        else if (tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            show1.SetActive(false);
            show2.SetActive(false);
            show3.SetActive(true);
        }
    }



    public void hurtOneEnemy(int attack, int skNRO)
    {

        Debug.Log("Skill NRO is " + skNRO.ToString());

        if (battle.isBossfight != 1)
        {

            if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
            {
                //chosenEnemy = enem1;
                // chosenEnemySprite.sprite = chosenEnemy._enemySprite;

                tryChosenE = tryE1;

                float im = tryChosenE.GetComponent<EnemyChanges>().takeAttack(attack);


                //  hurtEnemy(enem1, attack);

                aniHel.startOneAttAnim(1);

                //  sliderE1.GetComponent<TouchingHealthBars>().setHealth(chosenEnemy.changingHp);

                if (im <= 0)
                {

                    if (ifcanBeChosen(tryE1))
                    {

                    }
                    else if (ifcanBeChosen(tryE2))
                    {

                    }
                    else if (ifcanBeChosen(tryE3))
                    {

                    }
                    else
                    {
                        //gameend;
                        battleEnd(0);

                    }

                }
            }
            if (tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
            {
                tryChosenE = tryE2;

                float im = tryChosenE.GetComponent<EnemyChanges>().takeAttack(attack);
                aniHel.startOneAttAnim(2);


                if (im <= 0)
                {

                    if (ifcanBeChosen(tryE1))
                    {

                    }
                    else if (ifcanBeChosen(tryE2))
                    {

                    }
                    else if (ifcanBeChosen(tryE3))
                    {

                    }
                    else
                    {
                        //gameend;
                        battleEnd(0);


                    }

                }

            }
            if (tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
            {
                tryChosenE = tryE3;

                float im = tryChosenE.GetComponent<EnemyChanges>().takeAttack(attack);
                aniHel.startOneAttAnim(3);


                if (im <= 0)
                {

                    if (ifcanBeChosen(tryE1))
                    {

                    }
                    else if (ifcanBeChosen(tryE2))
                    {

                    }
                    else if (ifcanBeChosen(tryE3))
                    {

                    }
                    else
                    {
                        //gameend;
                        battleEnd(0);

                    }

                }

            }
        }
        else
        {

            if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
            {
                //chosenEnemy = enem1;
                // chosenEnemySprite.sprite = chosenEnemy._enemySprite;

                tryChosenE = tryE1;

                float im = tryChosenE.GetComponent<EnemyChanges>().takeAttack(attack);


                //  hurtEnemy(enem1, attack);

                aniHel.startOneAttAnim(1);

                //  sliderE1.GetComponent<TouchingHealthBars>().setHealth(chosenEnemy.changingHp);

                if (im <= 0)
                {

                    if (ifcanBeChosen(tryE1))
                    {

                    }              
                    else
                    {
                        //gameend;
                        battleEnd(0);

                    }

                }
            }
        }


        raiseOugiGage(0.05f);
    }

    public bool ifcanBeChosen(GameObject obje)
    {
        if (obje.GetComponent<EnemyChanges>().canBeAttacked)
        {

            tryChosenE = obje;

            tryChosenE.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = true;
            showOtherTwoColors(tryChosenE.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().codeNum);


            return true;
        }
        else
        {
            return false;
        }


    }




    public void hurtThreeEnemy(int attack, int skNRO)
    {
        //    Debug.Log("Skill NRO to MULTIPLE ENEMIES is " + skNRO.ToString());

        if (battle.isBossfight != 1)
        {

            float im1 = tryE1.GetComponent<EnemyChanges>().takeAttack(attack);
            float im2 = tryE2.GetComponent<EnemyChanges>().takeAttack(attack);
            float im3 = tryE3.GetComponent<EnemyChanges>().takeAttack(attack);

            aniHel.startThreeAttAnim();


            if (im1 <= 0)
            {
                if (ifcanBeChosen(tryE1))
                {

                }
                else if (ifcanBeChosen(tryE2))
                {

                }
                else if (ifcanBeChosen(tryE3))
                {

                }
                else
                {
                    //gameend;
                    battleEnd(0);


                }
            }
            if (im2 <= 0)
            {
                if (ifcanBeChosen(tryE1))
                {

                }
                else if (ifcanBeChosen(tryE2))
                {

                }
                else if (ifcanBeChosen(tryE3))
                {

                }
                else
                {
                    //gameend;
                    battleEnd(0);


                }
            }
            if (im3 <= 0)
            {
                if (ifcanBeChosen(tryE1))
                {

                }
                else if (ifcanBeChosen(tryE2))
                {

                }
                else if (ifcanBeChosen(tryE3))
                {

                }
                else
                {
                    //gameend;
                    battleEnd(0);


                }
            }

        }
        else
        {
            float im1 = tryE1.GetComponent<EnemyChanges>().takeAttack(attack);
            aniHel.startOneAttAnim(1);


            if (im1 <= 0)
            {
                if (ifcanBeChosen(tryE1))
                {

                }            
                else
                {
                    //gameend;
                    battleEnd(0);


                }
            }
        }

        raiseOugiGage(0.05f);
    }





    public void hpDebufOneEnemy(int attack, int turn)
    {

        if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE1.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);
        }
        if (tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE2.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);

        }
        if (tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE3.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);

        }
    }




    public void hpDebufThreeEnemy(int attack, int turn)
    {
        tryE1.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);
        tryE2.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);
        tryE3.GetComponent<EnemyChanges>().takeHP_DEBuff(attack, turn);

    }


    public void strDebufOneEnemy(int attack, int turn)
    {

        if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE1.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);

        }
        if (tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE2.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);

        }
        if (tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE3.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);

        }
    }




    public void strDebufThreeEnemy(int attack, int turn)
    {
        tryE1.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);
        tryE2.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);
        tryE3.GetComponent<EnemyChanges>().takeSTR_DEBuff(attack, turn);


    }


    public void defDebufOneEnemy(int attack, int turn)
    {

        if (tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE1.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);

        }
        if (tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE2.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);


        }
        if (tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen)
        {
            tryE3.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);

        }
    }



    public void defDebufThreeEnemy(int attack, int turn)
    {
        tryE1.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);
        tryE2.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);
        tryE3.GetComponent<EnemyChanges>().takeDEF_DEBuff(attack, turn);

    }




    public void healOneC(int heal, int turn)
    {
        if (tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara1.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);
            aniHel.startOneHelpAnim(1);
        }
        if (tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara2.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);
            aniHel.startOneHelpAnim(2);


        }
        if (tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara3.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);
            aniHel.startOneHelpAnim(3);


        }
    }
 

    public void healThreeC(int heal, int turn)
    {
        tryChara1.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);
        tryChara2.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);
        tryChara3.GetComponent<FighterCharacterChanges>().takeHeal(heal, turn);

        aniHel.startThreeHelpAnim();

    }


    public void strenghtOneC(int heal, int turn)
    {
        if (tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara1.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);
            aniHel.startOneHelpAnim(1);

        }
        if (tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
          
            tryChara2.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);
            aniHel.startOneHelpAnim(2);


        }
        if (tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara3.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);
            aniHel.startOneHelpAnim(3);


        }
    }





    public void strenghtThreeC(int heal, int turn)
    {
        tryChara1.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);
        tryChara2.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);
        tryChara3.GetComponent<FighterCharacterChanges>().takeStreghtening(heal, turn);

        aniHel.startThreeHelpAnim();
    }



    public void defenceOneC(int heal, int turn)
    {
        if (tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {           
            tryChara1.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);
            aniHel.startOneHelpAnim(1);

        }
        if (tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara2.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);
            aniHel.startOneHelpAnim(2);

        }
        if (tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2)
        {
            tryChara3.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);
            aniHel.startOneHelpAnim(3);

        }
    }
 

    public void defenceThreeC(int heal, int turn)
    {
        tryChara1.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);
        tryChara2.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);
        tryChara3.GetComponent<FighterCharacterChanges>().takeDefensing(heal, turn);

        aniHel.startThreeHelpAnim();
    }








    public void usedItem(int itemEffect, int value)
    {
        if(itemEffect == 0)
        {
            healOneC(value, 0);
        }
        else if(itemEffect == 1)
        {
            healThreeC(value, 0);
        }

    }













    public void showOtherTwoColors(int code)
    {

        if (battle.isBossfight != 1)
        {


            if (code == 4)
            {


                tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();
                tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();

                tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;
                tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;

            }
            else if (code == 5)
            {


                tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();
                tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();


                tryE3.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;
                tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;

            }
            else if (code == 6)
            {


                tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();
                tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().colorBYellow();

                tryE1.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;
                tryE2.GetComponent<EnemyChanges>().sliderE.GetComponent<TouchingHealthBars>().isChosen = false;

            }
            if (code == 1)
            {

                tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();
                tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();

                tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;
                tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;


            }
            else if (code == 2)
            {

                tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();
                tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();

                tryChara3.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;
                tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;

            }
            else if (code == 3)
            {

                tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();
                tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().colorBgray();

                tryChara1.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;
                tryChara2.GetComponent<FighterCharacterChanges>().sliderC.GetComponent<TouchingHealthBars>().isChosen2 = false;

            }

            else
            {
                //        Debug.Log("not chosen");
            }


        }

        showPinpoint();
    }





    
    public void enemyAttack()
    {

        Debug.Log("enemy attack ");
        int im1 = 1;
        int im2 = 1;
        int im3 = 1;


        int random = Random.Range(0, 3);

        if (random == 0)
        {
            Debug.Log("enemy ATTACKS 1");

            int att = tryE1.GetComponent<EnemyChanges>().changing_att;
           im1 = tryChara1.GetComponent<FighterCharacterChanges>().takeAttack(att);


        }
        if (random == 1)
        {
            Debug.Log("enemy ATTACKS 2");

            int att = tryE1.GetComponent<EnemyChanges>().changing_att;
            im2 = tryChara2.GetComponent<FighterCharacterChanges>().takeAttack(att);

           
        }
        if (random == 2)
        {
            Debug.Log("enemy ATTACKS 3");

            int att = tryE1.GetComponent<EnemyChanges>().changing_att;
            im3 = tryChara3.GetComponent<FighterCharacterChanges>().takeAttack(att);

        }


        random = Random.Range(0, 3);

        if (battle.isBossfight != 1)
        {

            if (random == 0)
            {
                int att = tryE2.GetComponent<EnemyChanges>().changing_att;
                im1 = tryChara1.GetComponent<FighterCharacterChanges>().takeAttack(att);


            }
            if (random == 1)
            {
                int att = tryE2.GetComponent<EnemyChanges>().changing_att;
                im2 = tryChara2.GetComponent<FighterCharacterChanges>().takeAttack(att);

            }
            if (random == 2)
            {
                int att = tryE2.GetComponent<EnemyChanges>().changing_att;
                im3 = tryChara3.GetComponent<FighterCharacterChanges>().takeAttack(att);
            }



            random = Random.Range(0, 3);

            if (random == 0)
            {
                int att = tryE3.GetComponent<EnemyChanges>().changing_att;
                im1 = tryChara1.GetComponent<FighterCharacterChanges>().takeAttack(att);


            }
            if (random == 1)
            {
                int att = tryE3.GetComponent<EnemyChanges>().changing_att;
                im2 = tryChara2.GetComponent<FighterCharacterChanges>().takeAttack(att);
            }
            if (random == 2)
            {
                int att = tryE3.GetComponent<EnemyChanges>().changing_att;
                im3 = tryChara3.GetComponent<FighterCharacterChanges>().takeAttack(att);
            }

        }

        if(tryChara1.GetComponent<FighterCharacterChanges>().changing_hp <= 0 && tryChara2.GetComponent<FighterCharacterChanges>().changing_hp <= 0 && tryChara3.GetComponent<FighterCharacterChanges>().changing_hp <= 0)
        {
            battleEnd(1);

        }

        if (im1 <= 0 && im2 <= 0 && im3 <= 0)
        {
            battleEnd(1);

        }

        raiseOugiGage(0.03f);
        endTurn();

    }







    public void endTurn()
    {
        attackingNro = 0;


        tryChara1.GetComponent<FighterCharacterChanges>().lessenTurns();
        tryChara2.GetComponent<FighterCharacterChanges>().lessenTurns();
        tryChara3.GetComponent<FighterCharacterChanges>().lessenTurns();


        

        tryE1.GetComponent<EnemyChanges>().lessenTurns();
        tryE2.GetComponent<EnemyChanges>().lessenTurns();
        tryE3.GetComponent<EnemyChanges>().lessenTurns();



   //     if (charaChosen == tryChara3)
       // {
            if (tryChara1.GetComponent<FighterCharacterChanges>().canBeAttacked)
            {
                charaChosen = tryChara1;
                CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;

                attack1.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[0], tryChara1);
                attack2.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[1], tryChara1);
                attack3.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[2], tryChara1);
                Ougi.GetComponent<TouchingAttack>().skillSet(tryChara1.GetComponent<FighterCharacterChanges>().skills[3], tryChara1);
            }
            else if (tryChara2.GetComponent<FighterCharacterChanges>().canBeAttacked)
            {
                charaChosen = tryChara2;
                CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;

                attack1.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[0], charaChosen);
                attack2.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[1], charaChosen);
                attack3.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[2], charaChosen);
                Ougi.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[3], charaChosen);
            }
            else
            {
                charaChosen = tryChara3;
                CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;

                attack1.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[0], charaChosen);
                attack2.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[1], charaChosen);
                attack3.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[2], charaChosen);
                Ougi.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[3], charaChosen);
            }
         

      //  }


        canPlay = true;

    }





    public void increaseAttackNRO()
    {
        attackingNro += 1;
        if (attackingNro > 2)
        {
            canPlay = false;

            enemyAttack();
        }
        else
        {


            if (attackingNro == 1)
            {
                if (tryChara2.GetComponent<FighterCharacterChanges>().canBeAttacked)
                {
                    charaChosen = tryChara2;
                    CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;
                    attack1.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[0], charaChosen);
                    attack2.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[1], charaChosen);
                    attack3.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[2], charaChosen);
                    Ougi.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[3], charaChosen);
                    //  Debug.Log("New chosen Character is " + chosenCharacter.chosenForm.formName);

                }
                else if (tryChara3.GetComponent<FighterCharacterChanges>().canBeAttacked)
                {
                    charaChosen = tryChara3;
                    CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;
                    attack1.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[0], charaChosen);
                    attack2.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[1], charaChosen);
                    attack3.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[2], charaChosen);
                    Ougi.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[3], charaChosen);

                    attackingNro += 1;
                }


            }
            else if (attackingNro == 2)
            {


                if (tryChara3.GetComponent<FighterCharacterChanges>().canBeAttacked)
                {
                    charaChosen = tryChara3;
                    CharacterFace.sprite = charaChosen.GetComponent<FighterCharacterChanges>().faceSprite;
                    attack1.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[0], charaChosen);
                    attack2.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[1], charaChosen);
                    attack3.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[2], charaChosen);
                    Ougi.GetComponent<TouchingAttack>().skillSet(charaChosen.GetComponent<FighterCharacterChanges>().skills[3], charaChosen);

                    
                }

            }

        }
    }


    public void battleEnd(int loseOwin)
    {

        canPlay = false;
        Debug.Log("comes to game end");

        StartCoroutine(endProg(1, loseOwin));

        

    }

    IEnumerator endProg(int sec, int loseORWin)
    {
        yield return new WaitForSecondsRealtime(sec);

        battleStuff(loseORWin);
    }

    public void battleStuff(int loseOwin)
    {

        if (loseOwin == 0)
        {

            Debug.Log("Player Wins, Game Over");
            winOrLose = 0;
            toNextB.gameObject.SetActive(true);
            toNextB.GetComponentInChildren<Text>().text = "Player Win";
        }
        else if (loseOwin == 1)
        {
            Debug.Log("Player Loses, Game Over");
            winOrLose = 1;

            toNextB.gameObject.SetActive(true);
            toNextB.GetComponentInChildren<Text>().text = "Player Lose";

        }
    }


    public void nextButtonPushed()
    {
        Debug.Log("Player Pushed Button");
       // playerOne.increasePhaseLevel();
       if(winOrLose == 0)
        {
            SceneManager.LoadScene(4);

        }
       if(winOrLose == 1)
        {
            SceneManager.LoadScene(8);

        }
    }




    // Update is called once per frame
    void Update()
    {

    }
}
