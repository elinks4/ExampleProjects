﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scenery : MonoBehaviour
{


    public Queue<string> sentences = new Queue<string>();

    public StoryBoard board;

    public bool Notready = true;

    public List<Dialogue> scene = new List<Dialogue>();
    public NewScene list = new NewScene();

    public List<SongValue> soundsTOCome = new List<SongValue>();

    public int theNumber;
    public int diaNumber;

    // Start is called before the first frame update
    void Start()
    {
        //sentences 
        //  Debug.Log("Sentences Created ");
        

        Notready = false;
    }




    public void giveScene(NewScene sceene)
    {
        theNumber = 0;
        diaNumber = 0;
        list = sceene;
        scene = list.diaList;
        soundsTOCome.Clear();
        soundsTOCome = sceene.soundChanges;


        startDialogue(scene[0]);
    }


  
    public void giveContinue(NewScene sceene, int staynum)
    {
        theNumber = staynum;
        list = sceene;
        scene = list.diaList;
        soundsTOCome.Clear();

        soundsTOCome = sceene.soundChanges;


        board.setDDto0();
        continueStory();
    }




    public void givingName()
    {

    }

    public void startDialogue(Dialogue dialogue)
    {
        Debug.Log("Starting dialogue with " + dialogue.name);

        sentences.Clear();
      

        foreach(string sentence in dialogue.sentences)
        {
            sentences.Enqueue(sentence);
        }

        board.setName(dialogue.name);
        board.setPic2(dialogue.charaNum, dialogue.picNum);
        board.setBGPic(dialogue.backGPic);
        board.checkSoundComings(theNumber, soundsTOCome);

        displayNextSentence();
    }

    public void displayNextSentence()
    {
        if(sentences.Count == 0)
        {
            endDialogue();
            return;
        }

      string sentence = sentences.Dequeue();
        Debug.Log(sentence);

        board.setSentence(sentence);

    }


    private void questionForPlayer()
    {
        if(list.PHR == 1)
        {
            board.openInputField();
        }
        else
        {
            board.makeQuestion(list.QString, list.Q1, list.Q2);
        }
      //

    }

    public void continueStory()
    {
        startDialogue(scene[theNumber]);
    }


    public void afterQue1()
    {
        if(list.PHR == 2)
        {
            board.stayNumber(theNumber);
        }
        if(list.PHR == 5)
        {
            Debug.Log("Chosen first Choice");
            board.afterChoosingRoute(1);
        }
    }

    public void afterQue2()
    {
        if (list.PHR == 2)
        {
            board.goOnWithStory();
        }
        if (list.PHR == 5)
        {
            Debug.Log("Chosen second Choice");
            board.afterChoosingRoute2(2);


        }
    }


    private void endDialogue()
    {
        Debug.Log("End of conversation ");
        theNumber += 1;

     
        
        if(theNumber == list.QNR)
        {
            questionForPlayer();
        }
        if(theNumber == list.hasbattle)
        {
            board.stayNumber(theNumber);
        }
        else if (scene.Count > theNumber)
        {
            Debug.Log("Number " + theNumber.ToString() + " diaNumber" + diaNumber.ToString());

            startDialogue(scene[theNumber]);
        }
        else
        {
            board.storyClear();

        }

    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
