﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class LevelingUp : MonoBehaviour
{




    public DontDestroyThis DdestroyThis;
    public Player playerOne;

    public List<Image> neededObjects = new List<Image>();
    public List<Button> levelupButtons = new List<Button>();

    public Image charaXdopeIma;
    public Text charaXdopeName;
    public Text charaLevelText;
    public Text dopeLevelText;

    public Text charaSkillLevelText1;
    public Text charaSkillLevelText2;
    public Text charaSkillLevelText3;

    public GameObject QuePanel;
    public GameObject CharaLVPanel;
    public GameObject SkillLVPanel;
    public GameObject DopePanel;

    public Spoils needed1;
    public Spoils needed2;
    public Spoils needed3;

    public bool haveIt1;
    public bool haveIt2;
    public bool haveIt3;

    public bool canLevelUp;

    public int charaId;

    public int dopeID;

    public Character charaLV;
    public Doping dopeLV;
    public int chosenSkill;

    public int skillLevelPart1;
    public int skillLevelPart2;
    public int skillLevelPart3;

    public int charaLevelPart;

    public Text playerGold;


    // Start is called before the first frame update
    void Start()
    {

        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;

        haveIt1 = false;
        haveIt2 = false;
        haveIt3 = false;
        canLevelUp = false;

        if (DdestroyThis.whichCorD == 1)
        {
            


            getCharaInfo();
        }
        else
        {
            getDopeInfo();
        }

        updateGoldText();

    }


    public void updateGoldText()
    {
        playerGold.text = playerOne.goldPlayerHas.ToString();
    }

    public void getCharaInfo()
    {


        charaId = DdestroyThis.charaScreenChara;

        Debug.Log("does player have this list anymore? " + playerOne.charactersPlayerHasList.Count);

        if(playerOne.charactersPlayerHasList.Count > 0)
        {
            for (int i = 0; i < playerOne.charactersPlayerHasList.Count; i++)
            {
                if (charaId == playerOne.charactersPlayerHasList[i]._charaID)
                {
                    charaLV = playerOne.charactersPlayerHasList[i];
                }
            }

            charaXdopeIma.sprite = charaLV.basicSprite;
            charaXdopeName.text = charaLV._name;

            QuePanel.SetActive(true);


           


        }
    }

    public void getDopeInfo()
    {
        dopeID = DdestroyThis.dopingScreenDope;

        if(playerOne.dopingsIDsPlayerHas.Count > 0)
        {
            for(int i = 0; i < playerOne.dopingsPlayerHas.Count; i++)
            {
                if(dopeID == playerOne.dopingsPlayerHas[i]._dopingID)
                {
                    dopeLV = playerOne.dopingsPlayerHas[i];
                }
            }
        }

        charaXdopeIma.sprite = dopeLV._sprite;
        charaXdopeName.text = dopeLV._name;

        DopePanel.gameObject.SetActive(true);

       // dopeLevelText.text = dopeLV._dope_level.ToString();
        int minorpart = new System.Version(dopeLV._dope_level.ToString()).Minor;

        dopeLevelText.text = minorpart.ToString();
        if (minorpart == 1)
        {
            dopeLevelText.text = "10";

        }
        checkDopes();
      
    }

    public void checkDopes()
    {
       int minorpart = new System.Version(dopeLV._dope_level.ToString()).Minor;

        if (dopeLevelText.text != "10")
        {

            if (dopeLV._dopingID >= 0 && dopeLV._dopingID < 3)
            {
                needed1 = DdestroyThis.bank.spoilsBank[0];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[1];

           //     Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                neededObjects[6].sprite = needed1._image;
                neededObjects[7].sprite = needed2._image;
                neededObjects[8].sprite = needed3._image;



            }

            neededObjects[6].gameObject.SetActive(true);
            neededObjects[7].gameObject.SetActive(true);
            neededObjects[8].gameObject.SetActive(true);



            if (playerOne.spoilsIDInventory.Count > 0)
            {
                for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
                {
                    if (needed1._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt1 = true;
                    }
                     if (needed2._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt2 = true;
                    }
                     if (needed3._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt3 = true;
                    }
                }
            }

            if (haveIt1 && haveIt2 && haveIt3)
            {
                canLevelUp = true;

            }

        }
        else
        {
            levelupButtons[2].GetComponentInChildren<Text>().text = "Level MAX";
            neededObjects[6].gameObject.SetActive(false);
            neededObjects[7].gameObject.SetActive(false);
            neededObjects[8].gameObject.SetActive(false);
            canLevelUp = false;
        }


    }


    public void levelUpDopes()
    {
        if (canLevelUp)
        {
            dopeLV.levelUpDOpeOnce();
            Debug.Log("comes to Dope level upping");

            for (int i = 0; i < playerOne.levelsDopingshave.Count; i++)
            {
                int majorpart = new System.Version(playerOne.levelsDopingshave[i].ToString()).Major;

                if (majorpart == dopeLV._dopingID)
                {
                   
                   // int majorpart = new System.Version(playerOne.levelsDopingshave[i].ToString()).Major;
                    int minorpart = new System.Version(playerOne.levelsDopingshave[i].ToString()).Minor;
                    int trye1 = minorpart + 1;

                    float trye2 = majorpart + ((float)trye1 / 100);
                    playerOne.levelsDopingshave[i] = trye2;
                   minorpart = new System.Version(playerOne.levelsDopingshave[i].ToString()).Minor;

                    dopeLevelText.text = minorpart.ToString();
                    Debug.Log("minorpart is " + minorpart.ToString());
                    if(minorpart == 1)
                    {
                        dopeLevelText.text = "10";

                    }

                }
            }

         //   takeOutSpoils();
            checkDopes();
        }
    }



    public void levelUpCharaLevel()
    {
           if (canLevelUp)
          {

        if (charaLV != null)
        {
            charaLV.levelUpOneLevel();



            playerOne.levelingUpCharaLevelList(charaId);


            charaLevelPart = new System.Version(charaLV._level.ToString()).Minor;

            float test1 = (float)charaLV._charaID + 0.1f;
            float test2 = (float)charaLV._charaID + 0.2f;
            float test3 = (float)charaLV._charaID + 0.3f;
            float test4 = (float)charaLV._charaID + 0.4f;
            float test5 = (float)charaLV._charaID + 0.5f;
            float test6 = (float)charaLV._charaID + 0.6f;
            float test7 = (float)charaLV._charaID + 0.7f;
            float test8 = (float)charaLV._charaID + 0.8f;



            if (charaLV._level == test1  || charaLV._level == test2 || charaLV._level == test3 || charaLV._level == test4 || charaLV._level == test5 || charaLV._level == test6 || charaLV._level == test7 || charaLV._level == test8)
            {
                charaLevelText.text = charaLevelPart.ToString() + "0";

            }
            else
            {
                charaLevelText.text = charaLevelPart.ToString();

            }

                playerOne.goldPlayerHas -= 50;

            checkingCharaLV();
            }

       }

    }





    public void choosingCharaLV()
    {
        QuePanel.SetActive(false);

        CharaLVPanel.SetActive(true);

        charaLevelPart = new System.Version(charaLV._level.ToString()).Minor;

        if (charaLevelPart == 20 || charaLevelPart == 30 || charaLevelPart == 40 || charaLevelPart == 50 || charaLevelPart == 60 || charaLevelPart == 70 || charaLevelPart == 80 || charaLevelPart == 90)
        {
            charaLevelText.text = charaLevelPart.ToString() + "0";

        }
        else
        {
            charaLevelText.text = charaLevelPart.ToString();

        }



        checkingCharaLV();

    }

    public void checkingCharaLV()
    {
    //    Debug.Log("Where does this go");

        if (charaLevelPart < 90)
        {

            //  Debug.Log("LV under 90");
            /*

              if (charaLV._charaID >= 0 && charaLV._charaID < 3)
              {
                  needed1 = DdestroyThis.bank.spoilsBank[1];
                  needed2 = DdestroyThis.bank.spoilsBank[0];
                  needed3 = DdestroyThis.bank.spoilsBank[1];

               //   Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                  neededObjects[0].sprite = needed1._image;
                  neededObjects[1].sprite = needed2._image;
                  neededObjects[2].sprite = needed3._image;

              }
              else if(charaLV._charaID >= 3 && charaLV._charaID < 7)
              {
                  needed1 = DdestroyThis.bank.spoilsBank[0];
                  needed2 = DdestroyThis.bank.spoilsBank[0];
                  needed3 = DdestroyThis.bank.spoilsBank[1];

             //     Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                  neededObjects[0].sprite = needed1._image;
                  neededObjects[1].sprite = needed2._image;
                  neededObjects[2].sprite = needed3._image;
              }

              neededObjects[0].gameObject.SetActive(true);
              neededObjects[1].gameObject.SetActive(true);
              neededObjects[2].gameObject.SetActive(true);


              if (playerOne.spoilsIDInventory.Count > 0)
              {
                  Debug.Log("spoils inventory has some");


                  for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
                  {
                      if (needed1._ID == playerOne.spoilsIDInventory[i])
                      {
                          haveIt1 = true;
                      }
                      else if (needed2._ID == playerOne.spoilsIDInventory[i])
                      {
                          haveIt2 = true;
                      }
                      else if (needed3._ID == playerOne.spoilsIDInventory[i])
                      {
                          haveIt3 = true;
                      }
                  }
              }

              if (haveIt1 && haveIt2 && haveIt3)
              {
                  canLevelUp = true;

              }

              */

            playerGold.gameObject.SetActive(true);


            updateGoldText();


            if (playerOne.goldPlayerHas >= 50)
            {
                canLevelUp = true;
            }
        }
        else
        {
            levelupButtons[0].GetComponentInChildren<Text>().text = "Level MAX";
            //  neededObjects[0].gameObject.SetActive(false);
            // neededObjects[1].gameObject.SetActive(false);
            //  neededObjects[2].gameObject.SetActive(false);
            playerGold.gameObject.SetActive(false);
            canLevelUp = false;
        }
    }

    public void choosingSkillLevel()
    {
        QuePanel.SetActive(false);
        SkillLVPanel.SetActive(true);

        float skillch1 = charaLV.chosenForm.skills[0]._skill_level * 10;

        skillLevelPart1 = new System.Version(skillch1.ToString()).Minor;

        charaSkillLevelText1.text = skillLevelPart1.ToString();


        float skillch2 = charaLV.chosenForm.skills[1]._skill_level * 10;

        skillLevelPart2 = new System.Version(skillch2.ToString()).Minor;

        charaSkillLevelText2.text = skillLevelPart2.ToString();


        float skillch3 = charaLV.chosenForm.skills[2]._skill_level * 10;

        skillLevelPart3 = new System.Version(skillch3.ToString()).Minor;

        charaSkillLevelText3.text = skillLevelPart3.ToString();


        pushedFirstSkill();
 


    }

    public void pushedFirstSkill()
    {
        chosenSkill = 1;
        levelupButtons[1].GetComponentInChildren<Text>().text = "Level UP";


        if (skillLevelPart1 < 9)
        {
            if (charaLV._charaID >= 0 && charaLV._charaID < 3)
            {
                needed1 = DdestroyThis.bank.spoilsBank[1];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[0];

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;

              //  Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);


            }
            else if (charaLV._charaID >= 3 && charaLV._charaID < 7)
            {
                needed1 = DdestroyThis.bank.spoilsBank[0];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[1];

           //     Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;
            }

            neededObjects[3].gameObject.SetActive(true);
            neededObjects[4].gameObject.SetActive(true);
            neededObjects[5].gameObject.SetActive(true);


            if (playerOne.spoilsIDInventory.Count > 0)
            {
                for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
                {
                    if (needed1._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt1 = true;
                    }
                     if (needed2._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt2 = true;
                    }
                     if (needed3._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt3 = true;
                    }
                }
            }

            if (haveIt1 && haveIt2 && haveIt3)
            {
                canLevelUp = true;

            }
        }

        else
        {
            levelupButtons[1].GetComponentInChildren<Text>().text = "Level MAX";
            neededObjects[3].gameObject.SetActive(false);
            neededObjects[4].gameObject.SetActive(false);
            neededObjects[5].gameObject.SetActive(false);
            canLevelUp = false;
        }



    }

    public void pushedSecondSkill()
    {
        chosenSkill = 2;
        levelupButtons[1].GetComponentInChildren<Text>().text = "Level UP";

        if (skillLevelPart2 < 9)
        {
            if (charaLV._charaID >= 0 && charaLV._charaID < 3)
            {
                needed1 = DdestroyThis.bank.spoilsBank[1];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[0];

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;


          //      Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

            }
            else if (charaLV._charaID >= 3 && charaLV._charaID < 7)
            {
                needed1 = DdestroyThis.bank.spoilsBank[0];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[1];

          //      Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;
            }
            neededObjects[3].gameObject.SetActive(true);
            neededObjects[4].gameObject.SetActive(true);
            neededObjects[5].gameObject.SetActive(true);

            if (playerOne.spoilsIDInventory.Count > 0)
            {
                for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
                {
                    if (needed1._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt1 = true;
                    }
                    else if (needed2._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt2 = true;
                    }
                    else if (needed3._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt3 = true;
                    }
                }
            }

            if (haveIt1 && haveIt2 && haveIt3)
            {
                canLevelUp = true;

            }
        }

        else
        {
            levelupButtons[1].GetComponentInChildren<Text>().text = "Level MAX";
            neededObjects[3].gameObject.SetActive(false);
            neededObjects[4].gameObject.SetActive(false);
            neededObjects[5].gameObject.SetActive(false);
            canLevelUp = false;

        }
    }

    public void pushedThirdSkill()
    {
        chosenSkill = 3;
        levelupButtons[1].GetComponentInChildren<Text>().text = "Level UP";


        if (skillLevelPart3 < 9)
        {
            if (charaLV._charaID >= 0 && charaLV._charaID < 3)
            {
                needed1 = DdestroyThis.bank.spoilsBank[1];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[0];

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;


          //      Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

            }
            else if (charaLV._charaID >= 3 && charaLV._charaID < 7)
            {
                needed1 = DdestroyThis.bank.spoilsBank[0];
                needed2 = DdestroyThis.bank.spoilsBank[0];
                needed3 = DdestroyThis.bank.spoilsBank[1];

         //       Debug.Log("needed 1 " + needed1._name + " needed 2 " + needed2._name + " needed 3 " + needed3._name);

                neededObjects[3].sprite = needed1._image;
                neededObjects[4].sprite = needed2._image;
                neededObjects[5].sprite = needed3._image;
            }

            neededObjects[3].gameObject.SetActive(true);
            neededObjects[4].gameObject.SetActive(true);
            neededObjects[5].gameObject.SetActive(true);

            if (playerOne.spoilsIDInventory.Count > 0)
            {
                for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
                {
                    if (needed1._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt1 = true;
                    }
                    else if (needed2._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt2 = true;
                    }
                    else if (needed3._ID == playerOne.spoilsIDInventory[i])
                    {
                        haveIt3 = true;
                    }
                }
            }

            if (haveIt1 && haveIt2 && haveIt3)
            {
                canLevelUp = true;

            }
        }

        else
        {
            levelupButtons[1].GetComponentInChildren<Text>().text = "Level MAX";
            neededObjects[3].gameObject.SetActive(false);
            neededObjects[4].gameObject.SetActive(false);
            neededObjects[5].gameObject.SetActive(false);
            canLevelUp = false;

        }
    }


    public void levelSkillUp()
    {
        if (canLevelUp)
        {
            if(chosenSkill == 1)
            {
            playerOne.levelUpSkillInfo(charaLV.chosenForm.skills[0]._skill_level);

            charaLV.chosenForm.skills[0].levelUPOnce();
            float om = charaLV.chosenForm.skills[0]._skill_level * 10;
            Debug.Log("om part is " + om.ToString());

            skillLevelPart1 = new System.Version(om.ToString()).Minor;
            Debug.Log("skill level part is " + skillLevelPart1.ToString());
                charaSkillLevelText1.text = skillLevelPart1.ToString();
                takeOutSpoils();
            pushedFirstSkill();

            }
            else if(chosenSkill == 2)
            {
            playerOne.levelUpSkillInfo(charaLV.chosenForm.skills[1]._skill_level);

            charaLV.chosenForm.skills[1].levelUPOnce();
            float om = charaLV.chosenForm.skills[1]._skill_level * 10;
            Debug.Log("om part is " + om.ToString());

            skillLevelPart2 = new System.Version(om.ToString()).Minor;

                charaSkillLevelText2.text = skillLevelPart2.ToString();
            Debug.Log("skill level part is " + skillLevelPart1.ToString());
                takeOutSpoils();

                pushedSecondSkill();

        }
        else if (chosenSkill == 3)
            {
            playerOne.levelUpSkillInfo(charaLV.chosenForm.skills[2]._skill_level);

            charaLV.chosenForm.skills[2].levelUPOnce();
            float om = charaLV.chosenForm.skills[2]._skill_level * 10;
            Debug.Log("om part is " + om.ToString());

            skillLevelPart3 = new System.Version(om.ToString()).Minor;

                charaSkillLevelText3.text = skillLevelPart3.ToString();
            Debug.Log("skill level part is " + skillLevelPart1.ToString());
                takeOutSpoils();

                pushedThirdSkill();
        }
      }
    }


    public void takeOutSpoils()
    {
        for (int i = 0; i < playerOne.spoilsIDInventory.Count; i++)
        {
            if (needed1._ID == playerOne.spoilsIDInventory[i])
            {
                playerOne.spoilsIDInventory.RemoveAt(i);
            }
            else if (needed2._ID == playerOne.spoilsIDInventory[i])
            {
                playerOne.spoilsIDInventory.RemoveAt(i);

            }
            else if (needed3._ID == playerOne.spoilsIDInventory[i])
            {
                playerOne.spoilsIDInventory.RemoveAt(i);

            }
        }
    }

    public void goBack()
    {
        QuePanel.gameObject.SetActive(false);
        CharaLVPanel.gameObject.SetActive(false);
        SkillLVPanel.gameObject.SetActive(false);
        DopePanel.gameObject.SetActive(false);

        DdestroyThis.charaScreenChara = -1;
        DdestroyThis.dopingScreenDope = -1;

        SceneManager.LoadScene(7);


    }



    // Update is called once per frame
    void Update()
    {
        
    }
}
