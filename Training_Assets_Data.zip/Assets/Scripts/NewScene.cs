﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class NewScene 
{

    public List<Dialogue> diaList = new List<Dialogue>();
    public List<SongValue> soundChanges = new List<SongValue>();


    public int QNR;

  public  int ANR;

    public int PHR;

    public int hasbattle;

  public  string QString;
    public string Q1;
    public string Q2;




}
