﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlaceButtonPresss : MonoBehaviour
{

    public MapBehaviour map;

    public int ID;

    public int StoryOrExtra;

    public Sprite storyUnclear;
    public Sprite extraUnclear;
    public Sprite storyClear;
    public Sprite extraClear;
    public Sprite CanGo;

    public bool firstTime = true;
    public bool canGoThere = true;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void changeToCanGo()
    {
        gameObject.GetComponent<Image>().sprite = CanGo;

    }

    public void changeSpriteToDone()
    {
        if(StoryOrExtra == 1)
        {
            gameObject.GetComponent<Image>().sprite = storyClear;

        }
        else
        {
            gameObject.GetComponent<Image>().sprite = extraClear;

        }

        firstTime = false;

    }


    public void pressButton()
    {
        map.pressButton(gameObject);
    }
}
