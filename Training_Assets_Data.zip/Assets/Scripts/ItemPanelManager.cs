﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class ItemPanelManager : MonoBehaviour
{

    public BattleProgram battle;
    public DontDestroyThis DdestroyThis;
    public Player playerOne;
    ChooseOne chooseOne;
    public int theNum;
    public Button prefabbutton;
    public GameObject panel;
    public Button[] Itembuttons;
    public List<Button> buttonsList = new List<Button>();
    public List<Button> toDestroyPrefabs = new List<Button>();
    public List<Item> items = new List<Item>();
    public GridLayoutGroup grid;
    public int ChosenItemNUM;

    public bool choosingAlready = false;

    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
        toDestroyPrefabs.Clear();
        items.Clear();
        items = DdestroyThis.bank.getItems(playerOne.itemIDInventory);
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    public void instantiateItemButton(int count)
    {
        theNum = count;
        panel.SetActive(true);




        for (int i = 0; i < items.Count; i++)
        {




            Button H = createB(items[i]._itemId,  i);

            destOrSave(H);
            itemNums();



        }
    }


    public void itemNums()
    {


        for(int i = 0; i < buttonsList.Count; i++)
        {
            int nr = 0;


            for(int j = 0; j < items.Count; j++)
            {
                if(items[j]._itemId == buttonsList[i].GetComponent<ThisIsItem>().chosenItem._itemId)
                {
                    nr += 1;
                }
            }

            buttonsList[i].GetComponent<ThisIsItem>().setNUM(nr);
        }



    }


    public void destOrSave(Button button)
    {

        int thing = 0;

        for (int i = 0; i < buttonsList.Count; i++)
        {
            

            if (button.GetComponent<ThisIsItem>().chosenItem._itemId == buttonsList[i].GetComponent<ThisIsItem>().chosenItem._itemId)
            {
               

                thing = 1;
            }
        }



        if (thing == 1)
        {

            Destroy(button.gameObject);
        }
        else
        {
            toDestroyPrefabs.Add(button);
            buttonsList.Add(button);
            //   Debug.Log("button has character " + button.GetComponent<ChooseOne>().chosenCharacter._name);

        }

    }



    public Button createB(int nro, int count)
    {
        Button newB = Instantiate(prefabbutton) as Button;
        newB.GetComponent<ThisIsItem>().itemID = nro;

        
        newB.GetComponent<ThisIsItem>().chosenItem = items[count];

        newB.GetComponent<ThisIsItem>().text.text = newB.GetComponent<ThisIsItem>().chosenItem.name;




        newB.transform.SetParent(grid.transform, false);

        return newB;

    }


    public void startFirstItemChoosing()
    {
        if (choosingAlready)
        {
            goBack();
        }
        else if(choosingAlready == false)
        {
            panel.gameObject.SetActive(true);
            instantiateItemButton(1);
            choosingAlready = true;
        }
     

    }


    public void pushedOneButton(GameObject button)
    {
    
            battle.usedItem(button.GetComponent<ThisIsItem>().chosenItem.effectNR, button.GetComponent<ThisIsItem>().chosenItem.effectValue);

        for (int i = 0; i < playerOne.itemIDInventory.Count; i++)
        {
            if (button.GetComponent<ThisIsItem>().chosenItem._itemId == playerOne.itemIDInventory[i])
            {
                playerOne.itemIDInventory.RemoveAt(i);
            }
        }

        items = DdestroyThis.bank.getItems(playerOne.itemIDInventory);

        choosingAlready = false;
        panel.gameObject.SetActive(false);
    }


    public void pushedLastButton(GameObject button)
    {
        battle.usedItem(button.GetComponent<ThisIsItem>().chosenItem.effectNR, button.GetComponent<ThisIsItem>().chosenItem.effectValue);

        for(int i = 0; i < playerOne.itemIDInventory.Count; i++)
        {
            if(button.GetComponent<ThisIsItem>().chosenItem._itemId == playerOne.itemIDInventory[i])
            {
                playerOne.itemIDInventory.RemoveAt(i);
            }
        }

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
            if (button.GetComponent<ThisIsItem>().chosenItem._itemId == toDestroyPrefabs[i].GetComponent<ThisIsItem>().chosenItem._itemId)
            { 
                    
                    Destroy(toDestroyPrefabs[i].gameObject);
                    toDestroyPrefabs.RemoveAt(i);
                     buttonsList.RemoveAt(i);

            }


        }

        items = DdestroyThis.bank.getItems(playerOne.itemIDInventory);

        choosingAlready = false;

        panel.gameObject.SetActive(false);

    }

    public void goBack()
    {

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {


            Destroy(toDestroyPrefabs[i].gameObject);


        }


        theNum = 0;

        toDestroyPrefabs.Clear();
        buttonsList.Clear();
        choosingAlready = false;

        panel.SetActive(false);

       


    }

}
