﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{


  
    public List<AudioClip> songList = new List<AudioClip>();

   

    public AudioClip getSong(int nro)
    {

     return  songList[nro];

    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
