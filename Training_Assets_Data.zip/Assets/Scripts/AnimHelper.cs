﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnimHelper : MonoBehaviour
{


    public Sprite[] animatedIma1;



    public Image animaOb1;
    public Image animaOb2;
    public Image animaOb3;


    public Image helpAni1;
    public Image helpAni2;
    public Image helpAni3;


   // public Image[] tryAnimList;


   // public Animator animator;



    public void startOneAttAnim( int nro)
    {



        if (nro == 1)
        {

              animaOb1.gameObject.SetActive(true);

        }
        if(nro == 2)
        {

            animaOb2.gameObject.SetActive(true);
        }
        if(nro == 3)
        {

            animaOb3.gameObject.SetActive(true);
        }

                setToFalse(1);

    }


    public void startThreeAttAnim()
    {

        animaOb1.gameObject.SetActive(true);
        animaOb2.gameObject.SetActive(true);
        animaOb3.gameObject.SetActive(true);

        setToFalse(1);

    }

    public void startOneHelpAnim(int nro)
    {
        if (nro == 1)
        {

            helpAni1.gameObject.SetActive(true);

        }
        if (nro == 2)
        {

            helpAni2.gameObject.SetActive(true);
        }
        if (nro == 3)
        {

            helpAni3.gameObject.SetActive(true);
        }

        setToFalse2(1);
    }


    public void startThreeHelpAnim()
    {

        helpAni1.gameObject.SetActive(true);
        helpAni2.gameObject.SetActive(true);
        helpAni3.gameObject.SetActive(true);

        setToFalse2(1);

    }


    public void setToFalse(int sec)
    {
        StartCoroutine(waiter2(sec));

    
    }

    public void setToFalse2(int sec)
    {
        StartCoroutine(waiter3(sec));


    }

    IEnumerator waiter(int sec)
    {
        bool quit = false;

        float waitTime = sec;
        float counter = 0;
        while (counter < waitTime)
        {
            //Increment Timer until counter >= waitTime
            counter += Time.deltaTime;
            Debug.Log("We have waited for: " + counter + " seconds");
            //Wait for a frame so that Unity doesn't freeze
            //Check if we want to quit this function
            if (quit)
            {
                //Quit function
                yield break;
            }
            yield return null;
        }

        animaOb1.gameObject.SetActive(false);
        animaOb2.gameObject.SetActive(false);
        animaOb3.gameObject.SetActive(false);

    }

    IEnumerator waiter2(int sec)
    {

        yield return new WaitForSecondsRealtime(sec);

        animaOb1.gameObject.SetActive(false);
        animaOb2.gameObject.SetActive(false);
        animaOb3.gameObject.SetActive(false);

    }


    IEnumerator waiter3(int sec)
    {

        yield return new WaitForSecondsRealtime(sec);

        helpAni1.gameObject.SetActive(false);
        helpAni2.gameObject.SetActive(false);
        helpAni3.gameObject.SetActive(false);

    }



    // Start is called before the first frame update
    void Start()
    {
        animaOb1.gameObject.SetActive(false);
        animaOb2.gameObject.SetActive(false);
        animaOb3.gameObject.SetActive(false);



    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
