﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{


   // public Dialogue dialogue;

    public List<NewScene> scene = new List<NewScene>();
    private int risingNum;

    private int x = 0;

    private int a = 1;
    private int a2 = 1;

    private int c = 2;
    private int c2 = 2;

    private int m = 3;
    private int m2 = 3;

    private int r = 9;
    private int r2 = 9;

    private int w = 8;
    private int w2 = 8;

    private List<SongValue> soundChangeList = new List<SongValue>();


    public void triggerDialogue(int num, int storyNRO)
    {
        scene.Clear();

        loadAll(storyNRO);


        Debug.Log("scene num " + (num - 1).ToString() + " and num is " + num.ToString());
           

       
                FindObjectOfType<Scenery>().giveScene(scene[num - 1]);


        



    }


    public void triggerContinue(int phase, int staynum, int storyRoute)
    {
        Debug.Log("Triggered Continue, phase is " + phase.ToString() + " staynum is " + staynum.ToString());
        scene.Clear();

        loadAll(storyRoute);

        
        FindObjectOfType<Scenery>().giveContinue(scene[phase - 1], staynum);

    }


    public void loadAll(int storyRoute)
    {

        scene.Clear();

        scene0M();

        scene1M();

        scene2M();

        scene3M();

        scene4M();

        routeLoader(storyRoute);
    }



    private void routeLoader(int nro)
    {
        if (nro != 0)
        {
            if (nro == 1)
            {
                scene5aM();
            }
            else if(nro == 2)
            {
                scene5bM();
            }
        }
    }



    //   nr0.diaList.Add(newDia(null, "", "", "", 10, 0, 0, 0));

    private void scene0M()
    {
        risingNum = 1;
        NewScene nr0 = new NewScene();

        List<int> placeNR = new List<int>();
        List<int> charaNR = new List<int>();
        List<int> picNR = new List<int>();

       // placeNR.Add(0, 0, 0);


        nr0.PHR = risingNum;
        nr0.hasbattle = 0;
       // nr0.soundChanges.Add(new SongValue(0, 1));
        nr0.soundChanges.Add(new SongValue(5, 3));

        Debug.Log("nr0 has soundChanges has count of " + nr0.soundChanges.Count.ToString());

        x = 10;

        nr0.diaList.Add(newDia(null, "Welcome, watcher from another world", "What is your name?", null, setList(0,0,0), setList(0, 0, 0), x));
        nr0.QNR = 1;
        nr0.QString = "name";



        scene.Add(nr0);



        nr0.diaList.Add(newDia(null, "Welcome friend", null, null, setList(0, 0, 0), setList(0, 0, 0), x));
        nr0.diaList.Add(newDia(null, "We have invited you to see", null, null, setList(0, 0, 0),  setList(0, 0, 0), x));

        nr0.diaList.Add(newDia(null, "different interesting happenings of our world of Aureiya", "And now that you are finally here", null, setList(0, 0, 0),  setList(0, 0, 0), x));
        nr0.diaList.Add(newDia(null, "we would like to begin with a small story of a young man called Allen,", "that like you came here from another world…", null, setList(0, 0, 0),  setList(0, 0, 0), x));
        x = 1;
           nr0.diaList.Add(newDia(null, "When Allen woke up, he was standing on a street of a city he had never seen before, ", "full of bright colored buildings with black roofs, surrounded by large walls all around. ", null, setList(0, 1, 0), setList(0, 0, 0), x));
           nr0.diaList.Add(newDia(null, "As Allen was looking around the city, he noticed something else ", "that was strange apart from the city he was in.", null, setList(0, 1, 0), setList(0, 0, 0), 0));
          nr0.diaList.Add(newDia(null, "When Allen looked at the different windows of the surrounding buildings", "the reflection that looked back at him was not the same he was used to.", "It was not his face that looked back.", setList(0, 1, 0), setList(0, 0, 0), x));


        // scene.Add(newDia("test2", "lets try it out wopoiuytrewqasdfghjklmnbvcxzzxcvbnmlkj", "wow", null, 10, 0, 0, 0));

    }




    private void scene1M()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 0;
      //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 0;
        nr0.QString = "test battle?";
        nr0.Q1 = "yes";
        nr0.Q2 = "no";

        nr0.soundChanges.Add(new SongValue(0, 3));


        scene.Add(nr0);

        nr0.diaList.Add(newDia(null, "While thinking about whether this was a dream or not, ", "something bumped into him and wrapped its hands around his arm.", null, setList(0, 1, 0), setList(0, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Allen, Allen, where have you been, ", "I have looked everywhere for you!", null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia(null, "It was a young lady, seemingly not so different in age than the body of Allen that he was now residing in. ", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "(Is this body’s name Allen? And who is this new person? Should I say something to her?)", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia(null, "While he was thinking of these things the person by his side, saw his distraction and asked him.", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Allen, are you okay?", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "Aah… sorry, I was just thinking about something. Yes, I am alright.", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "(Yes, I think it’s not the best idea to say I’m not the Allen she was looking for, at least not yet.)", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Well… if you say so… ", "But really, why did you just disappear like that! I know you wanted to see all the new things in the stores,  ", "but we really don’t have the money to buy anything.", setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Really, the money we made from selling our things is only enough to help the orphanage a little, ", "so we really should leave the city now before we use any of it. ", "And we have a pretty long way to go home.", setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "(Leave the city… orphanage… ", "Well, this does not seem to be my world, so I think its better to go with her for now than stay here alone)", null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "Okay, I have done enough window shopping already, so let’s go", null, null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Really! ", "Okay, then let’s go already!", null, setList(2, 1, 0), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia(null, "The young lady said leading Allen through the city.", "And so, the two people, one with a purpose, and one who was just going along left the city gates.", null, setList(2, 1, 0), setList(2, 0, 0), x));



        // nr0.diaList.Add(newDia(null, "That was battle", "How was it.", null, 10, 0, 0, 0));


    }





    private void scene2M()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 8;
        //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 0;
        nr0.QString = "test battle?";
        nr0.Q1 = "yes";
        nr0.Q2 = "no";
        nr0.soundChanges.Add(new SongValue(0, 4));

        scene.Add(nr0);

        x = 2;

        nr0.diaList.Add(newDia(null, "After leaving the city the two went over a clearing and into a forest. ", "As they walked on a forest road, the young lady suddenly, as if she had just remembered, said to Allen", null, setList(2,0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia("???:", "Although we have your magic, we should still be careful of monsters when going through the forest, so be ready for anything, okay?", null, null, setList(2, 0, 1), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("Allen:", "(Magic, can I use magic?!)", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia(null, "Allen thought and looked at his palm while trying to use any magic he might have.", "And at that second there became a small ball of light over his hand, and the next second the knowledge of magic using appeared inside Allen’s head.", null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia("Allen:", "(What was that?!)", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia(null, "Allen thought just as some monsters jumped onto the road from the woods around them.", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia("???:", "Allen", null, null, setList(2, 0, 1), setList(2, 0, 0), x));


        nr0.diaList.Add(newDia(null, "Allen nodded, as he took a fighting pose.", null, null, setList(2, 0, 1), setList(2, 0, 0), x));


        nr0.diaList.Add(newDia("???:", "Allen, we won, we won ", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia(null, "After the fight the lady seemed very pleased and happy, ", "and just as Allen was about to comment on it, ", "when out of nowhere the sky seemed to open and rain started to pour down.", setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia("???:", "Oh, no!", "Quick, hurry, were going to catch a cold if we stay in the rain", "You remember the house we stayed yesterday right, its just around here, so let’s take cover inside it.", setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia(null, "The two people ran through the forest...", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

    }


    private void scene3M()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 0;
        //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 0;
        nr0.QString = "test battle?";
        nr0.Q1 = "yes";
        nr0.Q2 = "no";

        nr0.soundChanges.Add(new SongValue(0, 4));
        nr0.soundChanges.Add(new SongValue(4, 8));

        scene.Add(nr0);

        x = 3;
        nr0.diaList.Add(newDia(null, "After running a while, the two people could finally see", " a big dark house mainly built with wood that blended well with the environment.", "The door to the house was open so the two quickly went inside.",  setList(2, 0, 1), setList(2, 0, 0), x));
      
        x = 4;

        nr0.diaList.Add(newDia(null, "To their surprise the house that had looked empty from outside was brightly lit inside.", null, null, setList(2, 0, 1), setList(2, 0, 0), x));

        nr0.diaList.Add(newDia("Allen:", "(What… There was no light in the windows… right?)", null, null, setList(2, 0, 1), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia(null, "As the door shut behind them, Allen felt a weird sensation, but before he could think more about it, ", "there came a voice to the entrance.", null, setList(2, 0, 1), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia("???:", "Who are you two", null, null, setList(2, 0, 1), setList(2, 0, 0), x));
        nr0.diaList.Add(newDia(null, "After the voice, a big man walked to see the newcomers at the entrance.", null, null, setList(2, 1, 3), setList(2, 0, 3), x));
        nr0.diaList.Add(newDia("???:", "I am Clarice, and this is Allen. ", "It started to rain in our way home, so we came here to wait it to pass… ", "but now that we are all wet, maybe we should stay here for the night again.", setList(2, 1, 3), setList(2, 0, 3), x));
        nr0.diaList.Add(newDia("Allen:", "(So, her name is Clarice)", null, null, setList(2, 1, 3), setList(2, 0, 3), x));
        nr0.diaList.Add(newDia("???:", "Okay, Clarice and Allen, I’m Rodney, a traveler that came here to stay the night.", "Including you there are now 5 people in this house, ", "but because its so big at least there is no worry about getting a room to sleep in.", setList(2, 1, 3), setList(2, 0, 3), x));
        x = 5;
        nr0.diaList.Add(newDia(null, "Rodney said as they all walked inside a large living room and came to stay in front of a fireplace.", null, null, setList(2, 1, 3), setList(2, 0, 3), x));
       
        nr0.diaList.Add(newDia("Rodney:", "Do you guys have any change of clothes?", null, null, setList(2, 1, 3), setList(2, 0, 3), 0));
        nr0.diaList.Add(newDia("Clarice:", "Not really, our village only about a one night away from the city so we didn’t want to bring so much luggage.", null, null, setList(2, 1, 3), setList(2, 0, 3), x));
        nr0.diaList.Add(newDia(null, "At those words Allen noticed the first time that he really didn’t have much anything with him,", "aside from a key and a couple of coins,", "and Clarice too only had a small bag with her.", setList(2, 1, 3), setList(2, 0, 3), x));

        nr0.diaList.Add(newDia(null, "While the two wet people were shivering in front of the fireplace, there came an unknown man’s voice from behind them.", null, null, setList(2, 1, 3), setList(2, 0, 3), x));

        nr0.diaList.Add(newDia("???:", "So, there are even more people here now?", null, null, setList(2, 1, 3), setList(2, 0, 3), x));

        nr0.diaList.Add(newDia(null, "As they turned around to look towards the voice, ", "they could see two people walking towards them with different kinds of food on their hands.", null, setList(r, 0, w), setList(r2, 0, w2), x));

        nr0.diaList.Add(newDia("???:", "We were just about to go eat at the dining room. ", "Do you want some?", null, setList(r, 0, w), setList(r2, 0, w2), x));

        nr0.diaList.Add(newDia(null, "The speaker of the unknown voice was a man with brown hair and a large sword on his waist.", null, null, setList(r, 0, w), setList(r2, 0, w2), x));

        nr0.diaList.Add(newDia("???:", "Or do you want to change to something dry first? ", "We found some in the room on the second floor, the stairs up are in the hallway.", null, setList(r, 0, w), setList(r2, 0, w2), x));

        x = 12;

        nr0.diaList.Add(newDia(null, "The second speaker was a woman with expensive looking brooch on her dress.", "Allen and Clarice took up on their offer and went upstairs to change and came back down ", "to eat with everyone at a large table in the dining room of the house.",  setList(c, 0, a), setList(c2, 0, a2), x));
        //in - dining", setList(c, 0, a), setList(c2, 0, a2), x));
        //in - dining

        nr0.diaList.Add(newDia(null, "The new people introduced themselves as Rixa and Jelica, who were also travelers that came to spend a night in the house.", null, null, setList(c, 0, a), setList(c2, 0, a2), x));


        nr0.diaList.Add(newDia("Jelica:", "But we were surprised, there was so much good food in the kitchen, so someone must have been here lately and left the food, ", "or it would have gone spoiled.", null, setList(0, w, 0), setList(0, w2, 0), x));

        nr0.diaList.Add(newDia("Rodney:", "Yes, we were very lucky", null, null, setList(w, 0, m), setList(w2, 0, m2), x));

        x = 3;

        nr0.diaList.Add(newDia(null, "Everyone made friendly conversation until the sun went down and they all decided to go to their chosen rooms and sleep.", null, null, setList(c, 0, a), setList(c2, 0, a2), x));


    }

    private void scene4M()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 0;
        //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 17;
        nr0.QString = "Where do you want to go";
        nr0.Q1 = "Go through portal";
        nr0.Q2 = "Go down the ladder";
        nr0.soundChanges.Add(new SongValue(0, 8));

        scene.Add(nr0);


        nr0.diaList.Add(newDia(null, "In the morning Allen woke up to the sun shining through a window, as the weather had seemingly changed through the night.", null, null, setList(0, a, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia(null, "After everyone ate breakfast together, Allen and Clarice decided to leave to continue their way home.", null, null, setList(c, 0, a), setList(c2, 0, a2), x));

        x = 4;
        nr0.diaList.Add(newDia(null,  "As Allen and Clarice said their goodbyes, and were just about to depart when trouble occurred…", "The front door would not open.", null, setList(c, 0, a), setList(c2, 0, a2), x));

        nr0.diaList.Add(newDia("Clarice:", "Are you sure it won’t open?", null, null, setList(c, 0, a), setList(c2, 0, a2), x));

        nr0.diaList.Add(newDia(null, "Clarice tried to open the door herself with the same result…", "The door would not budge.", null, setList(c, 0, a), setList(c2, 0, a2), x));

        nr0.diaList.Add(newDia("Others:", "The windows won’t open either!", null, null, setList(r, w, m), setList(r2, w2, m2), x));

        nr0.diaList.Add(newDia(null, "Said the other three people that had checked all the windows in the rooms close to the entrance.", null, null, setList(r, w, m), setList(r2, w2, m2), x));

        nr0.diaList.Add(newDia("Allen:", "Can’t you break them?", null, null, setList(c, 0, a), setList(c2, 0, a2), x));

        nr0.diaList.Add(newDia("Rodney:", "I will try", null, null, setList(0, m, 0), setList(0, m2, 0), x));

        nr0.diaList.Add(newDia(null, "Rodney said and lifted a nearby chair and swung it to a window with all his might.", null, null, setList(0, m, 0), setList(0, m2, 0), x));

        nr0.diaList.Add(newDia("Everyone:", "What?!", null, null, setList(0, m, 0), setList(0, m2, 0), x));

        nr0.diaList.Add(newDia("Jelica:", "How can that be?", null, null, setList(w, m, 0), setList(w2, m2, 0), x));
        nr0.diaList.Add(newDia("Rixa:", "It must be some kind of magic. ", "Let’s check if there is another way out, and if there is none, let’s search for anything that looks magical or could help us out of here.", null, setList(w, m, r), setList(w2, m2, r2), x));


        x = 3;
        nr0.diaList.Add(newDia(null, "On the first floor the group found a wooden trap door under the dining room table,", null, null, setList(0, 0, 0), setList(0, 0, 0), x));

        nr0.diaList.Add(newDia(null,  "and on the second floor they found a key to the front door from one of the rooms.", null, null, setList(0, 0, 0), setList(0, 0, 0), x));

        x = 7;
       
        nr0.diaList.Add(newDia(null, "Under the trap door there were ladder going down to darkness, ", "while opening the front door with the key revealed a magical portal leading to a place unknown.", null, setList(0, 0, 0), setList(0, 0, 0), x));
        x = 6;
        nr0.diaList.Add(newDia(null, "while opening the front door with the key revealed a magical portal leading to a place unknown.", null, null, setList(0, 0, 0), setList(0, 0, 0), x));

        x = 10; 
        nr0.diaList.Add(newDia(null, null, null, null, setList(0, 0, 0), setList(0, 0, 0), x));

    }



    private void scene5aM()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 18;
        //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 0;
        nr0.QString = "Where do you want to go";
        nr0.Q1 = "Go through portal";
        nr0.Q2 = "Go down the ladder";

        nr0.soundChanges.Add(new SongValue(0, 8));

        nr0.soundChanges.Add(new SongValue(7, 5));

        scene.Add(nr0);

        x = 10;

        nr0.diaList.Add(newDia(null, "The place where the portal led was a dark place, ", null, null, setList(0, 0, 0), setList(0, 0, 0), x));

        x = 9;

        nr0.diaList.Add(newDia(null, "and the group could not see anything until Allen remembered he could use magic to make light.", "With the light they could see they were in a circular room made from stone, ", "with many tables and bookshelves that seemed to be full of item and books related to magic.", setList(0, a, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia(null, "They also could find a one door that led to a spiral staircase going downwards.", null, null, setList(0, a, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia("Allen:", "What do we do? Do we search for some clues or try to leave this place?", null, null, setList(0, a, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia(null, "While the others looked troubled and indecisive, Rixa looked through couple of the books on the tables.", null, null, setList(0, 0, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia("Rixa:", "The only thing I could find in these books was that the portal was made here with magic ", "to connect these two places together for unknown reasons.", "Nothing more.", setList(0, r, 0), setList(0, r2, 0), x));
        //together -- for


        nr0.diaList.Add(newDia("Jelica:", "Then let’s just get out of here then.", null, null, setList(0, w, 0), setList(0, w2, 0), x));

        x = 11;

        nr0.diaList.Add(newDia(null, "The group went silently down the stairs without anything happening,", " but just as the last person was about to touch the floor on the first floor,", "the front door of the stone tower opened.", setList(0, 0, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia(null, "Inside the tower came a masked person that wore a dark cloak with dark red blotches looked like blood, ", "that concealed any traits the person had.", null, setList(0, 10, 0), setList(0, 10, 0), x));
        //traits -- the

        nr0.diaList.Add(newDia("Clarice:", "Who are you?!", null, null, setList(0, c, 0), setList(0, c2, 0), x));
        nr0.diaList.Add(newDia("Rodney:", "Where are we, can you tell us?", null, null, setList(0, c, m), setList(0, c2, m2), x));
        nr0.diaList.Add(newDia("Allen:", "Is that blood?!", null, null, setList(a, c, m), setList(a2, c2, m2), x));

        nr0.diaList.Add(newDia(null, "They many questions the group had only got silence as their answers.", null, null, setList(a, c, m), setList(a2, c2, m2), x));

        nr0.diaList.Add(newDia("Rixa:", "Are you our enemy?", null, null, setList(0, r, 0), setList(0, r2, 0), x));

        nr0.diaList.Add(newDia("???:", "Ha Ha Ha Ha Ha HA HA HAHAHAHAHA…", null, null, setList(0, 10, 0), setList(0, 10, 0), x));

        nr0.diaList.Add(newDia(null, "As to answer that one question the person began to laugh.", null, null, setList(0, 10, 0), setList(0, 10, 0), x));

        nr0.diaList.Add(newDia(null, "And he laughed...", "And laughed… ", "...And laughed… ", setList(0, 10, 0), setList(0, 10, 0), x));

        nr0.diaList.Add(newDia(null, "And attacked the group.", null, null, setList(0, 10, 0), setList(0, 10, 0), x));

        nr0.diaList.Add(newDia(null, "The crazed masked person fell to the floor and crumbled to ashes before the groups very eyes.", "The group looked at this sight for a long while, ", "and silently, ", setList(0, 0, 0), setList(0, r2, 0), x));
        nr0.diaList.Add(newDia(null, "very silently, ", "went around the pile of ash and through the front door.", null, setList(0, 0, 0), setList(0, r2, 0), x));


    }


    private void scene5bM()
    {
        risingNum++;

        NewScene nr0 = new NewScene();

        nr0.PHR = risingNum;
        nr0.hasbattle = 14;
        //  nr0.diaList.Add(newDia(null, "Friend from another world", "Do you want to test battle", null, 10, 0, 0, 0));
        nr0.QNR = 0;
        nr0.QString = "Where do you want to go";
        nr0.Q1 = "Go through portal";
        nr0.Q2 = "Go down the ladder";
        nr0.soundChanges.Add(new SongValue(1, 5));

        scene.Add(nr0);

        x = 10;
        nr0.diaList.Add(newDia(null, "The space that was under the dining room was so dark that they could not see anything, ", "until Allen remembered that he could use magic to make light.", "The Group fell silent at the scene before their eyes. ", setList(0, 0, 0), setList(0, 0, 0), x));

        x = 8;

        nr0.diaList.Add(newDia(null, "The room that had probably been used as a cellar was stained with big dark red stains everywhere, ", "and in the middle of the room was laying a dead body inside a big red magic circle. ", null, setList(0, 0, 0), setList(0, 0, 0), x));

        nr0.diaList.Add(newDia("Allen:", "There is no smell…", null, null, setList(0, a, 0), setList(0, a2, 0), x));

        nr0.diaList.Add(newDia(null, "Allen looked at the body and the blood but found the room straight from a horror movie almost dreamlike, ", "like it could not have been really there.", null, setList(0, a, 0), setList(0, a2, 0), x));

      
        nr0.diaList.Add(newDia("Clarice:", "Why… why, is there really no smell?", null, null, setList(c, a, 0), setList(c2, a2, 0), x));
        nr0.diaList.Add(newDia(null, "All of the group other than Rixa were staring at the body but were unwilling to get any closer. ", "Rixa scanned the room with his eyes.", null, setList(0, r, 0), setList(c2, r2, 0), x));

        nr0.diaList.Add(newDia("Rixa:", "It looks like there was some kind of sacrificial ritual here, ", "maybe the used magic made the smell go away…", null, setList(0, r, 0), setList(c2, r2, r2), x));

        nr0.diaList.Add(newDia(null, "Rixa went to a corner of the room and picked up something from the floor.", "It was a small leatherbound book that looked like it had been thrown into the wall and left where it had dropped. ", "After reading it a while, Rixa continued to speak", setList(0, r, 0), setList(0, r2, r2), x));

        nr0.diaList.Add(newDia("Rixa:", "Yes…", "It looks like someone was trying to make some kind of weird undead species… ", "And also used magic to keep trapped it in this house…", setList(0, r, 0), setList(c2, r2, r2), x));

        nr0.diaList.Add(newDia("Allen:", "Undead… ", "Do you mean that…", null, setList(a, r, 0), setList(a2, r2, r2), x));

        nr0.diaList.Add(newDia(null, "Allen started to ask, ", "when he heard a guttural scream from the center of the room…", null, setList(a, r, 0), setList(a2, r2, r2), x));

        x = 13;

        nr0.diaList.Add(newDia(null, "The body that had laid there just a few seconds ago was getting up. ", "And when it was standing in front of them it suddenly looked like its skin began to melt and change into a grayish substance.", "The group watched this disgusting sight without making a sound.", setList(0, 0, 0), setList(a2, r2, r2), x));

        nr0.diaList.Add(newDia(null, "After the transformation, ", "the monster in front of them did not look humane other than its body proportions. ", "As the group stared at the monster…", setList(0, 11, 0), setList(a2, 11, r2), x));

        nr0.diaList.Add(newDia(null, "The monster began slowly moving towards the group…", null, null, setList(0, 11, 0), setList(a2, 11, r2), x));

        nr0.diaList.Add(newDia(null, "The monster fell to the floor and suddenly started burning until nothing was left, but the fire spread to the floor.", null, null, setList(0, 0, 0), setList(a2, r2, r2), x));

        nr0.diaList.Add(newDia("Rixa:", "Run!!!", null, null, setList(0, r, 0), setList(c2, r2, r2), x));

        x = 3;
        nr0.diaList.Add(newDia(null, "The group run for their lives... ", "Up the ladders...", "Through the now burning house, and through the front door that now opened without any trouble… ", setList(0, 0, 0), setList(a2, r2, r2), x));

        x = 2;
        nr0.diaList.Add(newDia(null, "And on they went into the woods... ", null, null, setList(0, 0, 0), setList(a2, r2, r2), x));

    }




    private Dialogue newDia(string name, string sente1, string sente2, string sente3, List<int> charaN, List<int> picN, int backPic)
    {
        Dialogue dialogue = new Dialogue();

        if(name == null)
        {
            dialogue.name = " ";
        }
        else
        {
            dialogue.name = name;

        }

        dialogue.charaNum = charaN;
        dialogue.picNum = picN;
      //  dialogue.picPlace = charaN;
        dialogue.backGPic = backPic;
        if(sente2 == null && sente3 == null)
        {
            string[] test = new string[1];
            test[0] = sente1;
            dialogue.sentences = test;
        }
        else if(sente3 == null)
        {
            string[] test = new string[2];
            test[0] = sente1;
            test[1] = sente2;
            dialogue.sentences = test;

        }
        else
        {
            string[] test = new string[3];
            test[0] = sente1;
            test[1] = sente2;
            test[2] = sente3;
            dialogue.sentences = test;

        }

        return dialogue;

    }


    public List<int> setList(int i, int o, int j)
    {

        List<int> list = new List<int>();

        list.Add(i);
        list.Add(o);
        list.Add(j);


        return list;
    }

    // Start is called before the first frame update
    void Start()
    {
      


    }







    // Update is called once per frame
    void Update()
    {
        
    }
}
