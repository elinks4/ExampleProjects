﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ChooserMAnager : MonoBehaviour
{
    public DontDestroyThis DdestroyThis;
    public Player playerOne;
    ChooseOne chooseOne;
    public Character[] chosenCharactersList = new Character[3];
    public int[] chosenNumbersList = new int[3];
    public Doping[] chosenAlfaDoping = new Doping[3];
    public Doping[] chosenNeutralDoping = new Doping[3];

    public List<Button> toDestroyPrefabs = new List<Button>();

    public Button prefabbutton;
    public GameObject panel;

    public GridLayoutGroup grid;
    // public int charaNum;
    // public int AlfaNum;
    // public int NeutralNum;

    public int theNum;

    public Button[] Charabuttons;
    public Button[] AlfaButtons;
    public Button[] NeutralButtons;

    public Sprite nullSprite;

    public List<Button> buttonsList = new List<Button>();

    // Start is called before the first frame update
    void Start()
    {
        DdestroyThis = FindObjectOfType<DontDestroyThis>();
        playerOne = DdestroyThis.player;
        toDestroyPrefabs.Clear();
        //  test();
    }


    public void instantiateCharaButton(int num, int count)
    {
        theNum = count;
        panel.SetActive(true);




        for (int i = 0; i < playerOne.charactersPlayerHasList.Count; i++)
        {

            


                    Button H = createB(num, true, i);
                    destOrSave(H);
                  
                
                
            
        }
    }


    public void destOrSave(Button button)
    {
       
        int thing = 0;

        for(int i = 0; i < buttonsList.Count; i++)
        {
            if(button.GetComponent<ChooseOne>().chosenCharacter._charaID == buttonsList[i].GetComponent<ChooseOne>().chosenCharacter._charaID)
            {
        //           Debug.Log("Found another character " + button.GetComponent<ChooseOne>().chosenCharacter._name);

                thing = 1;
            }
        }

        for(int i = 0; i < chosenCharactersList.Length; i++)
        {
            if(chosenCharactersList[i] != null)
            {
                if (button.GetComponent<ChooseOne>().chosenCharacter._charaID == chosenCharactersList[i]._charaID)
                {
          //          Debug.Log("Found another character " + button.GetComponent<ChooseOne>().chosenCharacter._name);

                    thing = 1;
                }
            }
          
        }


        if(thing == 1)
        {
            Destroy(button.gameObject);
          //   Debug.Log("button has been destoyed ");

        }
        else if(thing != 1)
        {
        //    Debug.Log("Adds button " + button.GetComponent<ChooseOne>().chosenCharacter._name);

            toDestroyPrefabs.Add(button);
            buttonsList.Add(button);

        }

    }





    public void instantiateDopingButton(int num, int count, int whichNum)
    {
        if (whichNum == 0)
        {

            Debug.Log("comes to instantiate Alfa doping");

            theNum = num;
            for (int i = 0; i < playerOne.dopingsPlayerHas.Count; i++)
            {

                if (playerOne.dopingsPlayerHas[i]._Unnatural_Doping >= 1)
                {
                    Debug.Log("Unnatural doping num is " + playerOne.dopingsPlayerHas[i]._Unnatural_Doping.ToString());

                    Button H = createB(count, false, i);
                    toDestroyPrefabs.Add(H);
                }



            }

        }
        else if (whichNum == 1)
        {
            theNum = num;

            Debug.Log("comes to instantiate Neutral doping");


            for (int i = 0; i < playerOne.dopingsPlayerHas.Count; i++)
            {

                if (playerOne.dopingsPlayerHas[i]._Unnatural_Doping == 0)
                {
                    Debug.Log("Unnatural doping num is " + playerOne.dopingsPlayerHas[i]._Unnatural_Doping.ToString());

                    Button H = createB(count, false, i);
                    toDestroyPrefabs.Add(H);
                }



            }
        }

        panel.SetActive(true);




    }



    public Button createB(int nro, bool charaOrN, int count)
    {
        Button newB = Instantiate(prefabbutton) as Button;
        newB.GetComponent<ChooseOne>().choNr = nro;

        if (charaOrN)
        {
            newB.GetComponent<ChooseOne>().chosenCharacter = playerOne.charactersPlayerHasList[count];

        }
        else
        {
            newB.GetComponent<ChooseOne>().chosenDoping = playerOne.dopingsPlayerHas[count];

        }

        newB.GetComponent<ChooseOne>().charaOrNot = charaOrN;
        newB.transform.SetParent(grid.transform, false);

        return newB;

    }


    public void startFirstCharacterChoosing()
    {

        instantiateCharaButton(1, 1);

    }

    public void startSecondCharacterChoosing()
    {

        instantiateCharaButton(2, 2);

    }

    public void startThirdCharacterChoosing()
    {


        instantiateCharaButton(3, 3);


    }


    public void startFirstAlfaDopeChoosing()
    {

        instantiateDopingButton(4, 4, 0);


    }

    public void startSecondAlfaDopeChoosing()
    {
        instantiateDopingButton(5, 5, 0);




    }
    public void startThirdAlfaDopeChoosing()
    {





        instantiateDopingButton(6, 6, 0);


    }


    public void startFirstNeutralDopeChoosing()
    {

        instantiateDopingButton(7, 7, 1);

    }



    public void startSecondNeutralDopeChoosing()
    {

        instantiateDopingButton(8, 8, 1);



    }
    public void startThirdNeutralDopeChoosing()
    {


        instantiateDopingButton(9, 9, 1);



    }


    public void setChara(Character chara)
    {

          Debug.Log("Comes to set Character");


        if (theNum == 1)
        {
            chosenCharactersList[0] = chara;
            chosenNumbersList[0] = chara._charaID;
            Charabuttons[0].image.sprite = chara.basicSprite;

        }
        else if (theNum == 2)
        {
            chosenCharactersList[1] = chara;
            chosenNumbersList[1] = chara._charaID;
            Charabuttons[1].image.sprite = chara.basicSprite;


        }
        else if (theNum == 3)
        {
            chosenCharactersList[2] = chara;
            chosenNumbersList[2] = chara._charaID;
            Charabuttons[2].image.sprite = chara.basicSprite;


        }

        //  Button temp;

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
            // Debug.Log("Comes to destroyPrefs destroy");

            //   temp = toDestroyPrefabs[i];

               Debug.Log("Destroying " + toDestroyPrefabs[i].gameObject.GetComponent<ChooseOne>().chosenCharacter._name);

            Destroy(toDestroyPrefabs[i].gameObject);

            //   Debug.Log("toDes count is " + toDestroyPrefabs.Count.ToString());


            //   Destroy(temp.gameObject);
        }


        theNum = 0;

        toDestroyPrefabs.Clear();
        buttonsList.Clear();

        panel.SetActive(false);



    }

    public void setAlfaDope(Doping dope)
    {
        if (theNum == 4)
        {
            Debug.Log("alfa num is " + theNum.ToString() + " dope is " + dope._name);

            chosenAlfaDoping[0] = dope;
            AlfaButtons[0].image.sprite = dope._sprite;
            AlfaButtons[0].image.type = Image.Type.Simple;

        }
        else if (theNum == 5)
        {
            chosenAlfaDoping[1] = dope;
            AlfaButtons[1].image.sprite = dope._sprite;

        }
        else if (theNum == 6)
        {
            chosenAlfaDoping[2] = dope;
            AlfaButtons[2].image.sprite = dope._sprite;

        }

        //  Button temp;

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
            Destroy(toDestroyPrefabs[i].gameObject);
        }

        theNum = 0;

        toDestroyPrefabs.Clear();


        panel.SetActive(false);

    }
    public void setNeutralDope(Doping dope)
    {
        if (theNum == 7)
        {
            chosenNeutralDoping[0] = dope;
            NeutralButtons[0].image.sprite = dope._sprite;
        }
        else if (theNum == 8)
        {
            chosenNeutralDoping[1] = dope;
            NeutralButtons[1].image.sprite = dope._sprite;

        }
        else if (theNum == 9)
        {
            chosenNeutralDoping[2] = dope;
            NeutralButtons[2].image.sprite = dope._sprite;

        }

        // Button temp;

        for (int i = 0; i < toDestroyPrefabs.Count; i++)
        {
            Destroy(toDestroyPrefabs[i].gameObject);

        }

        theNum = 0;

        toDestroyPrefabs.Clear();


        panel.SetActive(false);

    }


    public void selectiveunEquip()
    {
        if (theNum == 1)
        {
            chosenCharactersList[0] = null;
            Charabuttons[0].gameObject.GetComponent<Image>().sprite = nullSprite;
            //  Charabuttons[0].image.sprite = nullSprite;
            Debug.Log("Comes to UNEQUIP");

            
        }
        if (theNum == 2)
        {
            chosenCharactersList[1] = null;
            Charabuttons[1].image.sprite = nullSprite;

           

        }
        if (theNum == 3)
        {
            chosenCharactersList[2] = null;
            Charabuttons[2].image.sprite = nullSprite;

           

        }
        if (theNum == 4)
        {
            chosenAlfaDoping[0] = null;
            AlfaButtons[0].image.sprite = nullSprite;

            
        }
        if (theNum == 5)
        {
            chosenAlfaDoping[1] = null;
            AlfaButtons[1].image.sprite = nullSprite;

           
        }
        if (theNum == 6)
        {
            chosenAlfaDoping[2] = null;
            AlfaButtons[2].image.sprite = nullSprite;

            
        }
        if (theNum == 7)
        {
            chosenNeutralDoping[0] = null;
            NeutralButtons[0].image.sprite = nullSprite;

            
        }
        if (theNum == 8)
        {
            chosenNeutralDoping[1] = null;
            NeutralButtons[1].image.sprite = nullSprite;

            
        }
        if (theNum == 9)
        {
            chosenNeutralDoping[2] = null;
            NeutralButtons[2].image.sprite = nullSprite;

           
        }

        toDestroyPrefabs.Clear();
        buttonsList.Clear();

        panel.SetActive(false);
    }


    public void toHome()
    {
        DdestroyThis.chL.Clear();
           
            //   Debug.Log("DD charas 1 " + DdestroyThis.chL[0].ToString());


            for (int i = 0; i < chosenAlfaDoping.Length; i++)
            {

                if (chosenAlfaDoping[i] != null)
                {
                    DdestroyThis.dopingsAlfaUsed[i] = chosenAlfaDoping[i]._dopingID;

                }
            }




            for (int i = 0; i < chosenNeutralDoping.Length; i++)
            {
                if (chosenNeutralDoping[i] != null)
                {
                    DdestroyThis.dopingsNeutralUsed[i] = chosenNeutralDoping[i]._dopingID;
                }
            }

            cleaning();
            buttonsList.Clear();
             toDestroyPrefabs.Clear();

        DdestroyThis.whereStoryStays -= 1;
       // playerOne.phaseLevel -= 1;


        SceneManager.LoadScene(6);

    }


    public void toBattle()
    {
        if (chosenCharactersList[0] != null && chosenCharactersList[1] != null && chosenCharactersList[2] != null)
        {
            DdestroyThis.chL.Clear();
            // DdestroyThis.dopingsAlfaUsed.Clear();
            // DdestroyThis.dopingsNeutralUsed.Clear();

            DdestroyThis.chL.Add(chosenCharactersList[0]._charaID);
            DdestroyThis.chL.Add(chosenCharactersList[1]._charaID);
            DdestroyThis.chL.Add(chosenCharactersList[2]._charaID);

            //   Debug.Log("DD charas 1 " + DdestroyThis.chL[0].ToString());


            for (int i = 0; i < chosenAlfaDoping.Length; i++)
            {

                if (chosenAlfaDoping[i] != null)
                {
                    DdestroyThis.dopingsAlfaUsed[i] = chosenAlfaDoping[i]._dopingID;

                }
            }




            for (int i = 0; i < chosenNeutralDoping.Length; i++)
            {
                if (chosenNeutralDoping[i] != null)
                {
                    DdestroyThis.dopingsNeutralUsed[i] = chosenNeutralDoping[i]._dopingID;
                }
            }




            cleaning();

            for (int i = 0; i < toDestroyPrefabs.Count; i++)
            {


                Destroy(toDestroyPrefabs[i].gameObject);


            }
            buttonsList.Clear();
            toDestroyPrefabs.Clear();


            SceneManager.LoadScene(3);


        }
    }


    public void cleaning()
    {
        for (int i = 0; i < chosenCharactersList.Length; i++)
        {
            chosenCharactersList[i] = null;
        }
        for (int i = 0; i < chosenAlfaDoping.Length; i++)
        {
            chosenAlfaDoping[i] = null;
        }
        for (int i = 0; i < chosenNeutralDoping.Length; i++)
        {
            chosenNeutralDoping[i] = null;
        }
        for (int i = 0; i < chosenNumbersList.Length; i++)
        {
            chosenNumbersList[i] = 0;
        }
    }


    public void xMArk()
    {
        for(int i = 0; i < toDestroyPrefabs.Count; i++)
        {
           Destroy(toDestroyPrefabs[i].gameObject);
       }

        buttonsList.Clear();
        toDestroyPrefabs.Clear();
        panel.SetActive(false);

    }



    // Update is called once per frame
    void Update()
    {

    }
}
