﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ThisIsItem : MonoBehaviour
{
    public ItemPanelManager manager;
    public int itemID;
    public Item chosenItem;
    public Text text;
    public Text howMany;
    public int numOfItems;

    public void chooseItemButton()
    {
        numOfItems -= 1;
        if(numOfItems <= 0)
        {
            manager.pushedLastButton(gameObject);
        }
        else
        {
            howMany.text = numOfItems.ToString();
            manager.pushedOneButton(gameObject);

        }
    }

    public void setNUM(int nu)
    {
        numOfItems = nu;
        howMany.text = nu.ToString();
    }


    // Start is called before the first frame update
    void Start()
    {
        manager = FindObjectOfType<ItemPanelManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
