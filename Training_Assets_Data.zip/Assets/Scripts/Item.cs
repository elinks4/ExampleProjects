﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item 
{
    public int _itemId;
    public string name;
    public string desc;
    public int effectNR;
    public int effectValue;
    public Sprite sprite;
    public Item(int id, string na, string de, Sprite sp)
    {
        _itemId = id;
        name = na;
        desc = de;
        sprite = sp;
    }

    public void setEffect(int eNR, int val)
    {
        effectNR = eNR;
        effectValue = val;
    }



    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
